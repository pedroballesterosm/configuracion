# Spatial Java - Backend de Generación de Documentos y PDFs

Backend desarrollado en **Java 25 / Spring Boot 4.0.8** para la creación, renderizado recursivo (Handlebars) y exportación a PDF de informes dinámicos.

---

## 🚀 Requisitos
* **Java 21+ / OpenJDK 25/26**
* **Maven 3.9+**
* **Podman** (o Docker) para la base de datos PostgreSQL

---

## 🗄️ Base de Datos con Podman

Para iniciar el contenedor de PostgreSQL con la configuración lista para la aplicación:

```bash
# Opción 1: Ejecutar el script incluido
bash scripts/start_db.sh

# Opción 2: Usar podman-compose
podman-compose up -d
```

La base de datos estará disponible en:
* **Host**: `localhost:5432`
* **Database**: `document_engine`
* **User**: `admin`
* **Password**: `password`

Las migraciones de esquema (Flyway) se ejecutarán automáticamente al iniciar la aplicación Spring Boot.

---

## ⚙️ Ejecución de la Aplicación

```bash
# Compilar y ejecutar tests
mvn clean test

# Iniciar el servidor Spring Boot (puerto 8080)
mvn spring-boot:run
```

---

## 📄 Endpoints REST Principales

| Método | Endpoint | Descripción |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Estado del servidor |
| `GET` | `/api/documents` | Listado de documentos |
| `POST` | `/api/documents` | Crear nuevo documento |
| `GET` | `/api/documents/{id}` | Obtener documento con su jerarquía completa |
| `DELETE` | `/api/documents/{id}` | Eliminar documento |
| `PUT` | `/api/documents/{id}` | Actualizar metadatos y template de documento |
| `GET` | `/api/documents/{id}/render` | Renderizar HTML compilado con Handlebars |
| `GET` | `/api/documents/{id}/pdf` | Generar y descargar informe en formato PDF |
| `POST` | `/api/documents/{id}/sections` | Añadir sección al documento |
| `POST` | `/api/sections/{id}/pages` | Añadir página a la sección |
| `POST` | `/api/pages/{id}/components` | Añadir componente a la página |
| `PUT` | `/api/sections/{id}` | Actualizar sección |
| `PUT` | `/api/pages/{id}` | Actualizar página |
| `PUT` | `/api/components/{id}` | Actualizar componente |
| `POST` | `/api/library/components` | Guardar componente en la librería |
| `POST` | `/api/library/instantiate/document/{libId}` | Instanciar documento desde plantilla |
| `POST` | `/api/library/instantiate/component/{libId}` | Instanciar componente en página |

---

## 📊 Generar Documento de Ejemplo (Banking Report)

Hemos incluido el script generador del informe bancario de ejemplo (+50 páginas con gráficos Chart.js, KPIs, tablas financieras y desgloses de activos):

### Opción A: Con Python 3 (Sin dependencias externas)
```bash
python3 scripts/create_banking_report.py
```

### Opción B: Con Node.js / TypeScript
```bash
npx tsx scripts/create_banking_report.ts
```

---

## 🔌 Integración con Frontend Angular (`luminary-interface`)

El archivo `proxy.conf.json` en `luminary-interface` está configurado para reenviar `/api` hacia `http://localhost:8080`.
Para arrancar el frontend:

```bash
cd ../luminary-interface
npm start
```
