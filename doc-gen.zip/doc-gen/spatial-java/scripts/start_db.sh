#!/bin/bash
set -e

CONTAINER_NAME="spatial_eclipse_db"
DB_USER="admin"
DB_PASSWORD="password"
DB_NAME="document_engine"

echo "Checking for container runtime..."
if command -v podman &> /dev/null; then
    RUNTIME="podman"
elif command -v docker &> /dev/null; then
    RUNTIME="docker"
else
    echo "Error: Neither podman nor docker found."
    exit 1
fi

echo "Using $RUNTIME..."

if $RUNTIME ps -a --format '{{.Names}}' | grep -Eq "^${CONTAINER_NAME}\$"; then
    if ! $RUNTIME ps --format '{{.Names}}' | grep -Eq "^${CONTAINER_NAME}\$"; then
        echo "Starting existing container $CONTAINER_NAME..."
        $RUNTIME start $CONTAINER_NAME
    else
        echo "Container $CONTAINER_NAME is already running."
    fi
else
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    $RUNTIME run -d \
        --name $CONTAINER_NAME \
        -e POSTGRES_USER=$DB_USER \
        -e POSTGRES_PASSWORD=$DB_PASSWORD \
        -e POSTGRES_DB=$DB_NAME \
        -v "$SCRIPT_DIR/init-db.sql:/docker-entrypoint-initdb.d/init-db.sql:ro" \
        -p 5432:5432 \
        postgres:16-alpine
fi

echo "PostgreSQL is ready at localhost:5432/$DB_NAME (user: $DB_USER)"
