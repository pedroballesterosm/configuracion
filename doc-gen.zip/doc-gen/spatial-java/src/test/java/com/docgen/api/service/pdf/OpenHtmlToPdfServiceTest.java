package com.docgen.api.service.pdf;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OpenHtmlToPdfServiceTest {

    @Test
    void testGenerateValidPdfFromHtml() {
        OpenHtmlToPdfService service = new OpenHtmlToPdfService();
        String html = "<!DOCTYPE html><html><head><title>Test</title></head><body><h1>Hello PDF</h1><p>Testing Java 25 PDF Generation</p></body></html>";

        byte[] pdfBytes = service.generatePdf(html, false);

        assertNotNull(pdfBytes);
        assertTrue(pdfBytes.length > 0);

        // Verify PDF Header signature (%PDF)
        String header = new String(pdfBytes, 0, Math.min(4, pdfBytes.length));
        assertEquals("%PDF", header);
    }
}
