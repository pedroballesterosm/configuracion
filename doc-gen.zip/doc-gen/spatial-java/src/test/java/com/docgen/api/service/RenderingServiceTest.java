package com.docgen.api.service;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.Page;
import com.docgen.api.domain.Section;
import com.docgen.api.domain.enums.DocumentStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class RenderingServiceTest {

    private RenderingService renderingService;

    @BeforeEach
    void setUp() {
        renderingService = new RenderingService(null, new ObjectMapper());
    }

    @Test
    void testRenderFullDocumentHierarchy() {
        Component comp1 = Component.builder()
                .componentType("text")
                .template("<h1>{{company}}</h1><p>Sales: ${{sales}}</p>")
                .data(Map.of("sales", 5000))
                .build();

        Component comp2 = Component.builder()
                .componentType("footer")
                .template("<footer>Page Footer - {{year}}</footer>")
                .data(Map.of("year", 2026))
                .build();

        Page page = Page.builder()
                .orderIndex(0)
                .template("<div class=\"page-container\">{{{components}}}</div>")
                .components(List.of(comp1, comp2))
                .build();

        Section section = Section.builder()
                .orderIndex(0)
                .template("<section class=\"report-section\">{{{pages}}}</section>")
                .pages(List.of(page))
                .build();

        Document doc = Document.builder()
                .id(UUID.randomUUID())
                .title("Annual Financial Report")
                .status(DocumentStatus.PUBLISHED)
                .globalContext(Map.of("company", "Acme Corp"))
                .template("<html><body><header>{{title}}</header>{{{sections}}}</body></html>")
                .sections(List.of(section))
                .build();

        String html = renderingService.renderDocument(doc);

        assertNotNull(html);
        assertTrue(html.contains("<header>Annual Financial Report</header>"));
        assertTrue(html.contains("<section class=\"report-section\">"));
        assertTrue(html.contains("<div class=\"page-container\">"));
        assertTrue(html.contains("<h1>Acme Corp</h1>"));
        assertTrue(html.contains("<p>Sales: $5000</p>"));
        assertTrue(html.contains("<footer>Page Footer - 2026</footer>"));
    }

    @Test
    void testJsonHelperInTemplate() {
        Document doc = Document.builder()
                .id(UUID.randomUUID())
                .title("Test JSON Helper")
                .globalContext(Map.of("stats", Map.of("users", 120, "active", true)))
                .template("<div>Data: {{json stats}}</div>")
                .build();

        String html = renderingService.renderDocument(doc);
        assertNotNull(html);
        assertTrue(html.contains("{\"users\":120,\"active\":true}") || html.contains("{\"active\":true,\"users\":120}"));
    }
}
