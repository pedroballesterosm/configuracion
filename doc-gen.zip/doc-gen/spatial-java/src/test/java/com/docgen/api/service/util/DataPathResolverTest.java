package com.docgen.api.service.util;

import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class DataPathResolverTest {

    @Test
    void testResolveSimpleProperty() {
        Map<String, Object> data = Map.of("name", "Report 2026", "author", "Alice");
        assertEquals("Report 2026", DataPathResolver.resolve(data, "name"));
        assertEquals("Alice", DataPathResolver.resolve(data, "author"));
    }

    @Test
    void testResolveNestedProperty() {
        Map<String, Object> user = Map.of("name", "Bob", "address", Map.of("city", "Madrid", "zip", "28001"));
        Map<String, Object> data = Map.of("user", user);

        assertEquals("Madrid", DataPathResolver.resolve(data, "user.address.city"));
        assertEquals("28001", DataPathResolver.resolve(data, "user.address.zip"));
    }

    @Test
    void testResolveListIndex() {
        Map<String, Object> item0 = Map.of("title", "Item 1", "amount", 100);
        Map<String, Object> item1 = Map.of("title", "Item 2", "amount", 250);
        Map<String, Object> data = Map.of("items", List.of(item0, item1));

        assertEquals("Item 1", DataPathResolver.resolve(data, "items[0].title"));
        assertEquals(250, DataPathResolver.resolve(data, "items[1].amount"));
    }

    @Test
    void testResolveInvalidPathReturnsNull() {
        Map<String, Object> data = Map.of("user", Map.of("name", "Carlos"));
        assertNull(DataPathResolver.resolve(data, "user.nonexistent"));
        assertNull(DataPathResolver.resolve(data, "items[5].title"));
        assertNull(DataPathResolver.resolve(null, "user.name"));
    }
}
