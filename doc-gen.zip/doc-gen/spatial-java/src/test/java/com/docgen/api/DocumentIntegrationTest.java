package com.docgen.api;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.Page;
import com.docgen.api.domain.Section;
import com.docgen.api.domain.enums.DocumentStatus;
import com.docgen.api.repository.DocumentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@ActiveProfiles("test")
class DocumentIntegrationTest {

    @Autowired
    private WebApplicationContext webApplicationContext;

    private MockMvc mockMvc;

    @Autowired
    private DocumentRepository documentRepository;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    }

    @Test
    void testHealthEndpoint() throws Exception {
        mockMvc.perform(get("/api/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ok"));
    }

    @Test
    void testCreateAndGetDocument() throws Exception {
        String jsonPayload = """
            {
                "title": "Integration Test Document",
                "status": "DRAFT",
                "template": "<h1>{{title}}</h1>{{{sections}}}"
            }
        """;

        mockMvc.perform(post("/api/documents")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonPayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").isNotEmpty())
                .andExpect(jsonPath("$.title").value("Integration Test Document"));
    }

    @Test
    void testRenderAndPdfEndpoints() throws Exception {
        Document doc = Document.builder()
                .title("Quarterly Report")
                .status(DocumentStatus.PUBLISHED)
                .template("<html><body><h1>{{title}}</h1>{{{sections}}}</body></html>")
                .build();

        Section section = Section.builder()
                .orderIndex(0)
                .template("<section>{{{pages}}}</section>")
                .build();

        Page page = Page.builder()
                .orderIndex(0)
                .template("<div>{{{components}}}</div>")
                .build();

        Component comp = Component.builder()
                .componentType("text")
                .template("<p>Revenue: ${{revenue}}</p>")
                .data(Map.of("revenue", 99000))
                .build();

        page.addComponent(comp);
        section.addPage(page);
        doc.addSection(section);

        Document savedDoc = documentRepository.save(doc);

        // Test HTML render
        mockMvc.perform(get("/api/documents/" + savedDoc.getId() + "/render"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.TEXT_HTML))
                .andExpect(content().string(containsString("Quarterly Report")))
                .andExpect(content().string(containsString("Revenue: $99000")));

        // Test PDF generation
        mockMvc.perform(get("/api/documents/" + savedDoc.getId() + "/pdf"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_PDF))
                .andExpect(header().string("Content-Disposition", containsString("document-" + savedDoc.getId() + ".pdf")));
    }
}
