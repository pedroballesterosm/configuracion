-- Create document_engine schema if not exists
CREATE SCHEMA IF NOT EXISTS document_engine;

-- Enable UUID extension (in public schema or available to all schemas)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;

-- Set search_path so all subsequent types, tables and indexes are created in document_engine schema
SET search_path TO document_engine, public;

-- ENUMS
DO $$ BEGIN
    CREATE TYPE document_status AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- ==========================================
-- LIBRARY TABLES (Templates / Masters)
-- ==========================================

CREATE TABLE IF NOT EXISTS document_engine.library_documents (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    template TEXT, -- Global layout template
    data JSONB DEFAULT '{}', -- Default data
    data_path TEXT, -- Default data path recommendation
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.library_sections (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    name TEXT NOT NULL,
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.library_pages (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    name TEXT NOT NULL,
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.library_components (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    name TEXT NOT NULL,
    component_type TEXT NOT NULL, -- e.g., 'text', 'image', 'chart'
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==========================================
-- INSTANCE TABLES (Live Documents)
-- ==========================================

CREATE TABLE IF NOT EXISTS document_engine.documents (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    title TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'DRAFT',
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    global_context JSONB DEFAULT '{}', -- Large JSON injected for the whole doc
    
    metadata JSONB DEFAULT '{}', -- Extra meta (author, dates)
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.sections (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    document_id UUID REFERENCES document_engine.documents(id) ON DELETE CASCADE,
    order_index INTEGER NOT NULL,
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.pages (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    section_id UUID REFERENCES document_engine.sections(id) ON DELETE CASCADE,
    order_index INTEGER NOT NULL,
    
    -- Layout properties
    width INTEGER,
    height INTEGER,
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS document_engine.components (
    id UUID PRIMARY KEY DEFAULT public.uuid_generate_v4(),
    page_id UUID REFERENCES document_engine.pages(id) ON DELETE CASCADE,
    
    -- Positioning
    x INTEGER,
    y INTEGER,
    width INTEGER,
    height INTEGER,
    z_index INTEGER DEFAULT 0,
    
    -- Type & Core Rendering Fields
    component_type TEXT NOT NULL,
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_sections_doc ON document_engine.sections(document_id);
CREATE INDEX IF NOT EXISTS idx_pages_section ON document_engine.pages(section_id);
CREATE INDEX IF NOT EXISTS idx_components_page ON document_engine.components(page_id);
