package com.docgen.api.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.*;

@Entity
@Table(name = "pages")
public class Page extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "section_id", nullable = false)
    @JsonBackReference
    private Section section;

    @Column(name = "order_index", nullable = false)
    private Integer orderIndex = 0;

    @Column(name = "width")
    private Integer width;

    @Column(name = "height")
    private Integer height;

    @Column(name = "template", columnDefinition = "TEXT")
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    @OneToMany(mappedBy = "page", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("zIndex ASC")
    @JsonManagedReference
    private List<Component> components = new ArrayList<>();

    public Page() {
    }

    public Page(Section section, Integer orderIndex, Integer width, Integer height, String template,
                Map<String, Object> data, String dataPath, List<Component> components) {
        this.section = section;
        this.orderIndex = orderIndex != null ? orderIndex : 0;
        this.width = width;
        this.height = height;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
        this.components = components != null ? components : new ArrayList<>();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private Section section;
        private Integer orderIndex = 0;
        private Integer width;
        private Integer height;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;
        private List<Component> components = new ArrayList<>();

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder section(Section section) { this.section = section; return this; }
        public Builder orderIndex(Integer orderIndex) { this.orderIndex = orderIndex; return this; }
        public Builder width(Integer width) { this.width = width; return this; }
        public Builder height(Integer height) { this.height = height; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }
        public Builder components(List<Component> components) { this.components = components; return this; }

        public Page build() {
            Page page = new Page(section, orderIndex, width, height, template, data, dataPath, components);
            if (id != null) page.setId(id);
            return page;
        }
    }

    @JsonProperty("sectionId")
    public UUID getSectionId() {
        return section != null ? section.getId() : null;
    }

    public void addComponent(Component component) {
        components.add(component);
        component.setPage(this);
    }

    public void removeComponent(Component component) {
        components.remove(component);
        component.setPage(null);
    }

    public Section getSection() { return section; }
    public void setSection(Section section) { this.section = section; }

    public Integer getOrderIndex() { return orderIndex; }
    public void setOrderIndex(Integer orderIndex) { this.orderIndex = orderIndex; }

    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }

    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }

    public List<Component> getComponents() { return components; }
    public void setComponents(List<Component> components) { this.components = components != null ? components : new ArrayList<>(); }
}
