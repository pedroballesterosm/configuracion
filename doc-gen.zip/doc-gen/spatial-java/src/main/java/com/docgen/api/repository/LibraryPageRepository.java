package com.docgen.api.repository;

import com.docgen.api.domain.LibraryPage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface LibraryPageRepository extends JpaRepository<LibraryPage, UUID> {
}
