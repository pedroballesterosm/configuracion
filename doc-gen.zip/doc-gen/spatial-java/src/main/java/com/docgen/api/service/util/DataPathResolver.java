package com.docgen.api.service.util;

import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DataPathResolver {

    private static final Pattern TOKEN_PATTERN = Pattern.compile("([^.\\[\\]]+)|\\[(\\d+)\\]");

    private DataPathResolver() {
    }

    /**
     * Safely navigates nested Maps/Lists using dot/bracket notation (e.g. "report.items[0].name")
     */
    @SuppressWarnings("unchecked")
    public static Object resolve(Object root, String path) {
        if (root == null || path == null || path.isBlank()) {
            return null;
        }

        Object current = root;
        Matcher matcher = TOKEN_PATTERN.matcher(path);

        while (matcher.find() && current != null) {
            String propName = matcher.group(1);
            String indexStr = matcher.group(2);

            if (propName != null) {
                if (current instanceof Map<?, ?> map) {
                    current = map.get(propName);
                } else {
                    return null;
                }
            } else if (indexStr != null) {
                int index = Integer.parseInt(indexStr);
                if (current instanceof List<?> list && index >= 0 && index < list.size()) {
                    current = list.get(index);
                } else {
                    return null;
                }
            }
        }

        return current;
    }
}
