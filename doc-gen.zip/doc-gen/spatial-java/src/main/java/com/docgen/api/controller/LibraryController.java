package com.docgen.api.controller;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.LibraryComponent;
import com.docgen.api.service.LibraryService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/library")
public class LibraryController {

    private final LibraryService libraryService;

    public LibraryController(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    @PostMapping("/components")
    public ResponseEntity<LibraryComponent> createLibraryComponent(@RequestBody LibraryComponent component) {
        return ResponseEntity.ok(libraryService.createLibraryComponent(component));
    }

    @PostMapping("/instantiate/document/{libId}")
    public ResponseEntity<Document> instantiateDocument(@PathVariable("libId") UUID libId) {
        return ResponseEntity.ok(libraryService.instantiateDocument(libId));
    }

    @PostMapping("/instantiate/component/{libId}")
    public ResponseEntity<?> instantiateComponent(
            @PathVariable("libId") UUID libId,
            @RequestBody InstantiateComponentRequest request) {

        if (request == null || request.getPageId() == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "pageId body param is required"));
        }

        Component comp = libraryService.instantiateComponent(libId, request.getPageId());
        return ResponseEntity.ok(comp);
    }

    public static class InstantiateComponentRequest {
        private UUID pageId;

        public InstantiateComponentRequest() {
        }

        public InstantiateComponentRequest(UUID pageId) {
            this.pageId = pageId;
        }

        public UUID getPageId() {
            return pageId;
        }

        public void setPageId(UUID pageId) {
            this.pageId = pageId;
        }
    }
}
