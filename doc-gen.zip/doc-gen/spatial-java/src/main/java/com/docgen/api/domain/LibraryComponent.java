package com.docgen.api.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "library_components")
public class LibraryComponent extends BaseEntity {

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "component_type", nullable = false)
    private String componentType;

    @Column(name = "template", columnDefinition = "TEXT", nullable = false)
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    public LibraryComponent() {
    }

    public LibraryComponent(String name, String componentType, String template, Map<String, Object> data, String dataPath) {
        this.name = name;
        this.componentType = componentType;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private String name;
        private String componentType;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder componentType(String componentType) { this.componentType = componentType; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }

        public LibraryComponent build() {
            LibraryComponent component = new LibraryComponent(name, componentType, template, data, dataPath);
            if (id != null) component.setId(id);
            return component;
        }
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getComponentType() { return componentType; }
    public void setComponentType(String componentType) { this.componentType = componentType; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }
}
