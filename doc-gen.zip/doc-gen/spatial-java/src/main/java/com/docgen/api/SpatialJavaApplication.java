package com.docgen.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpatialJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpatialJavaApplication.class, args);
    }
}
