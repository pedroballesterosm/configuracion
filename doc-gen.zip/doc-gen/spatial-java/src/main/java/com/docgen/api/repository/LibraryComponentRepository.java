package com.docgen.api.repository;

import com.docgen.api.domain.LibraryComponent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface LibraryComponentRepository extends JpaRepository<LibraryComponent, UUID> {
}
