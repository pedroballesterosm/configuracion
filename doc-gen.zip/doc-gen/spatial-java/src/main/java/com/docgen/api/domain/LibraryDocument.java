package com.docgen.api.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "library_documents")
public class LibraryDocument extends BaseEntity {

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "template", columnDefinition = "TEXT")
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    public LibraryDocument() {
    }

    public LibraryDocument(String name, String description, String template, Map<String, Object> data, String dataPath) {
        this.name = name;
        this.description = description;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private String name;
        private String description;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder description(String description) { this.description = description; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }

        public LibraryDocument build() {
            LibraryDocument doc = new LibraryDocument(name, description, template, data, dataPath);
            if (id != null) doc.setId(id);
            return doc;
        }
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }
}
