package com.docgen.api.controller;

import com.docgen.api.domain.Component;
import com.docgen.api.service.DocumentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/components")
public class ComponentController {

    private final DocumentService documentService;

    public ComponentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Component> updateComponent(@PathVariable("id") UUID id, @RequestBody Component component) {
        return ResponseEntity.ok(documentService.updateComponent(id, component));
    }
}
