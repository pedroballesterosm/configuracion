package com.docgen.api.controller;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Page;
import com.docgen.api.service.DocumentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/pages")
public class PageController {

    private final DocumentService documentService;

    public PageController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Page> updatePage(@PathVariable("id") UUID id, @RequestBody Page page) {
        return ResponseEntity.ok(documentService.updatePage(id, page));
    }

    @PostMapping("/{id}/components")
    public ResponseEntity<Component> addComponent(@PathVariable("id") UUID id, @RequestBody(required = false) Component component) {
        Component c = component != null ? component : Component.builder().componentType("text").build();
        return ResponseEntity.ok(documentService.addComponent(id, c));
    }
}
