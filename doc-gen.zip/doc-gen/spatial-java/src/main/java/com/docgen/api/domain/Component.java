package com.docgen.api.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "components")
public class Component extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "page_id", nullable = false)
    @JsonBackReference
    private Page page;

    @Column(name = "component_type", nullable = false)
    private String componentType = "text";

    @Column(name = "x")
    private Integer x;

    @Column(name = "y")
    private Integer y;

    @Column(name = "width")
    private Integer width;

    @Column(name = "height")
    private Integer height;

    @Column(name = "z_index")
    private Integer zIndex = 0;

    @Column(name = "template", columnDefinition = "TEXT")
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    public Component() {
    }

    public Component(Page page, String componentType, Integer x, Integer y, Integer width, Integer height,
                     Integer zIndex, String template, Map<String, Object> data, String dataPath) {
        this.page = page;
        this.componentType = componentType != null ? componentType : "text";
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.zIndex = zIndex != null ? zIndex : 0;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private Page page;
        private String componentType = "text";
        private Integer x;
        private Integer y;
        private Integer width;
        private Integer height;
        private Integer zIndex = 0;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder page(Page page) { this.page = page; return this; }
        public Builder componentType(String componentType) { this.componentType = componentType; return this; }
        public Builder x(Integer x) { this.x = x; return this; }
        public Builder y(Integer y) { this.y = y; return this; }
        public Builder width(Integer width) { this.width = width; return this; }
        public Builder height(Integer height) { this.height = height; return this; }
        public Builder zIndex(Integer zIndex) { this.zIndex = zIndex; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }

        public Component build() {
            Component c = new Component(page, componentType, x, y, width, height, zIndex, template, data, dataPath);
            if (id != null) c.setId(id);
            return c;
        }
    }

    @JsonProperty("pageId")
    public UUID getPageId() {
        return page != null ? page.getId() : null;
    }

    public Page getPage() { return page; }
    public void setPage(Page page) { this.page = page; }

    public String getComponentType() { return componentType; }
    public void setComponentType(String componentType) { this.componentType = componentType; }

    public Integer getX() { return x; }
    public void setX(Integer x) { this.x = x; }

    public Integer getY() { return y; }
    public void setY(Integer y) { this.y = y; }

    public Integer getWidth() { return width; }
    public void setWidth(Integer width) { this.width = width; }

    public Integer getHeight() { return height; }
    public void setHeight(Integer height) { this.height = height; }

    public Integer getZIndex() { return zIndex; }
    public void setZIndex(Integer zIndex) { this.zIndex = zIndex; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }
}
