package com.docgen.api.domain;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.*;

@Entity
@Table(name = "sections")
public class Section extends BaseEntity {

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "document_id", nullable = false)
    @JsonBackReference
    private Document document;

    @Column(name = "order_index", nullable = false)
    private Integer orderIndex = 0;

    @Column(name = "template", columnDefinition = "TEXT")
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    @OneToMany(mappedBy = "section", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("orderIndex ASC")
    @JsonManagedReference
    private List<Page> pages = new ArrayList<>();

    public Section() {
    }

    public Section(Document document, Integer orderIndex, String template, Map<String, Object> data, String dataPath, List<Page> pages) {
        this.document = document;
        this.orderIndex = orderIndex != null ? orderIndex : 0;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
        this.pages = pages != null ? pages : new ArrayList<>();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private Document document;
        private Integer orderIndex = 0;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;
        private List<Page> pages = new ArrayList<>();

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder document(Document document) { this.document = document; return this; }
        public Builder orderIndex(Integer orderIndex) { this.orderIndex = orderIndex; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }
        public Builder pages(List<Page> pages) { this.pages = pages; return this; }

        public Section build() {
            Section section = new Section(document, orderIndex, template, data, dataPath, pages);
            if (id != null) section.setId(id);
            return section;
        }
    }

    @JsonProperty("documentId")
    public UUID getDocumentId() {
        return document != null ? document.getId() : null;
    }

    public void addPage(Page page) {
        pages.add(page);
        page.setSection(this);
    }

    public void removePage(Page page) {
        pages.remove(page);
        page.setSection(null);
    }

    public Document getDocument() { return document; }
    public void setDocument(Document document) { this.document = document; }

    public Integer getOrderIndex() { return orderIndex; }
    public void setOrderIndex(Integer orderIndex) { this.orderIndex = orderIndex; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }

    public List<Page> getPages() { return pages; }
    public void setPages(List<Page> pages) { this.pages = pages != null ? pages : new ArrayList<>(); }
}
