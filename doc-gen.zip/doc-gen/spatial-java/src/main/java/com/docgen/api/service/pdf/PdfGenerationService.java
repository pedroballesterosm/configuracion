package com.docgen.api.service.pdf;

public interface PdfGenerationService {

    /**
     * Converts HTML string content to a PDF byte array.
     *
     * @param htmlContent the raw HTML string
     * @param landscape   true if landscape orientation, false if portrait
     * @return PDF content as byte array
     */
    byte[] generatePdf(String htmlContent, boolean landscape);
}
