package com.docgen.api.domain;

import com.docgen.api.domain.enums.DocumentStatus;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.util.*;

@Entity
@Table(name = "documents")
public class Document extends BaseEntity {

    @Column(name = "title", nullable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private DocumentStatus status = DocumentStatus.DRAFT;

    @Column(name = "template", columnDefinition = "TEXT")
    private String template;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "data", columnDefinition = "jsonb")
    private Map<String, Object> data = new HashMap<>();

    @Column(name = "data_path")
    private String dataPath;

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "global_context", columnDefinition = "jsonb")
    private Map<String, Object> globalContext = new HashMap<>();

    @JdbcTypeCode(SqlTypes.JSON)
    @Column(name = "metadata", columnDefinition = "jsonb")
    private Map<String, Object> metadata = new HashMap<>();

    @OneToMany(mappedBy = "document", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("orderIndex ASC")
    @JsonManagedReference
    private List<Section> sections = new ArrayList<>();

    public Document() {
    }

    public Document(String title, DocumentStatus status, String template, Map<String, Object> data,
                    String dataPath, Map<String, Object> globalContext, Map<String, Object> metadata,
                    List<Section> sections) {
        this.title = title;
        this.status = status != null ? status : DocumentStatus.DRAFT;
        this.template = template;
        this.data = data != null ? data : new HashMap<>();
        this.dataPath = dataPath;
        this.globalContext = globalContext != null ? globalContext : new HashMap<>();
        this.metadata = metadata != null ? metadata : new HashMap<>();
        this.sections = sections != null ? sections : new ArrayList<>();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private UUID id;
        private String title;
        private DocumentStatus status = DocumentStatus.DRAFT;
        private String template;
        private Map<String, Object> data = new HashMap<>();
        private String dataPath;
        private Map<String, Object> globalContext = new HashMap<>();
        private Map<String, Object> metadata = new HashMap<>();
        private List<Section> sections = new ArrayList<>();

        public Builder id(UUID id) { this.id = id; return this; }
        public Builder title(String title) { this.title = title; return this; }
        public Builder status(DocumentStatus status) { this.status = status; return this; }
        public Builder template(String template) { this.template = template; return this; }
        public Builder data(Map<String, Object> data) { this.data = data; return this; }
        public Builder dataPath(String dataPath) { this.dataPath = dataPath; return this; }
        public Builder globalContext(Map<String, Object> globalContext) { this.globalContext = globalContext; return this; }
        public Builder metadata(Map<String, Object> metadata) { this.metadata = metadata; return this; }
        public Builder sections(List<Section> sections) { this.sections = sections; return this; }

        public Document build() {
            Document doc = new Document(title, status, template, data, dataPath, globalContext, metadata, sections);
            if (id != null) doc.setId(id);
            return doc;
        }
    }

    public void addSection(Section section) {
        sections.add(section);
        section.setDocument(this);
    }

    public void removeSection(Section section) {
        sections.remove(section);
        section.setDocument(null);
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public DocumentStatus getStatus() { return status; }
    public void setStatus(DocumentStatus status) { this.status = status; }

    public String getTemplate() { return template; }
    public void setTemplate(String template) { this.template = template; }

    public Map<String, Object> getData() { return data; }
    public void setData(Map<String, Object> data) { this.data = data != null ? data : new HashMap<>(); }

    public String getDataPath() { return dataPath; }
    public void setDataPath(String dataPath) { this.dataPath = dataPath; }

    public Map<String, Object> getGlobalContext() { return globalContext; }
    public void setGlobalContext(Map<String, Object> globalContext) { this.globalContext = globalContext != null ? globalContext : new HashMap<>(); }

    public Map<String, Object> getMetadata() { return metadata; }
    public void setMetadata(Map<String, Object> metadata) { this.metadata = metadata != null ? metadata : new HashMap<>(); }

    public List<Section> getSections() { return sections; }
    public void setSections(List<Section> sections) { this.sections = sections != null ? sections : new ArrayList<>(); }
}
