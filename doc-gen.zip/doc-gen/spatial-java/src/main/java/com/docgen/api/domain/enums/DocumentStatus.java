package com.docgen.api.domain.enums;

public enum DocumentStatus {
    DRAFT,
    PUBLISHED,
    ARCHIVED
}
