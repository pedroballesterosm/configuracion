package com.docgen.api.service.pdf;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.Margin;
import com.microsoft.playwright.options.WaitUntilState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("playwrightPdfService")
@Primary
@ConditionalOnProperty(name = "pdf.engine", havingValue = "playwright", matchIfMissing = true)
public class PlaywrightPdfService implements PdfGenerationService {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightPdfService.class);

    @Override
    public byte[] generatePdf(String htmlContent, boolean landscape) {
        log.info("Generating PDF with Playwright (Chromium headless)... Landscape={}", landscape);

        try (Playwright playwright = Playwright.create()) {
            BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions()
                    .setHeadless(true)
                    .setArgs(List.of("--no-sandbox", "--disable-setuid-sandbox"));

            try (Browser browser = playwright.chromium().launch(launchOptions)) {
                Page page = browser.newPage();

                // Set HTML and wait for network idle to ensure CSS, fonts, images are ready
                page.setContent(htmlContent, new Page.SetContentOptions().setWaitUntil(WaitUntilState.NETWORKIDLE));

                Page.PdfOptions pdfOptions = new Page.PdfOptions()
                        .setFormat("A4")
                        .setLandscape(landscape)
                        .setPrintBackground(true)
                        .setMargin(new Margin().setTop("20px").setRight("20px").setBottom("20px").setLeft("20px"));

                byte[] pdfBytes = page.pdf(pdfOptions);
                log.info("PDF generated successfully via Playwright ({} bytes)", pdfBytes.length);
                return pdfBytes;
            }
        } catch (Exception e) {
            log.error("Failed to generate PDF with Playwright", e);
            throw new RuntimeException("PDF Generation Error: " + e.getMessage(), e);
        }
    }
}
