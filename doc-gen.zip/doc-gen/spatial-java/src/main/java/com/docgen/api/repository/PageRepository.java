package com.docgen.api.repository;

import com.docgen.api.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface PageRepository extends JpaRepository<Page, UUID> {
    List<Page> findBySection_IdOrderByOrderIndexAsc(UUID sectionId);
}
