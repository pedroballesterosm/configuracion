package com.docgen.api.controller;

import com.docgen.api.domain.Page;
import com.docgen.api.domain.Section;
import com.docgen.api.service.DocumentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/sections")
public class SectionController {

    private final DocumentService documentService;

    public SectionController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PutMapping("/{id}")
    public ResponseEntity<Section> updateSection(@PathVariable("id") UUID id, @RequestBody Section section) {
        return ResponseEntity.ok(documentService.updateSection(id, section));
    }

    @PostMapping("/{id}/pages")
    public ResponseEntity<Page> addPage(@PathVariable("id") UUID id, @RequestBody(required = false) Page page) {
        Page p = page != null ? page : new Page();
        return ResponseEntity.ok(documentService.addPage(id, p));
    }
}
