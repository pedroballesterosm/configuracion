package com.docgen.api.service;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.Page;
import com.docgen.api.domain.Section;
import com.docgen.api.service.util.DataPathResolver;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.jknack.handlebars.Handlebars;
import com.github.jknack.handlebars.Template;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class RenderingService {

    private static final Logger log = LoggerFactory.getLogger(RenderingService.class);

    private final DocumentService documentService;
    private final Handlebars handlebars;
    private final ObjectMapper objectMapper;

    public RenderingService(DocumentService documentService, ObjectMapper objectMapper) {
        this.documentService = documentService;
        this.objectMapper = objectMapper != null ? objectMapper : new ObjectMapper();
        this.handlebars = new Handlebars();

        // Register custom helpers
        this.handlebars.registerHelper("json", (context, options) -> {
            if (context == null) {
                return new Handlebars.SafeString("{}");
            }
            try {
                return new Handlebars.SafeString(objectMapper.writeValueAsString(context));
            } catch (Exception e) {
                log.error("Error serializing JSON in Handlebars helper", e);
                return new Handlebars.SafeString("{}");
            }
        });
    }

    /**
     * Main entry point: Renders a Document by its UUID to an HTML string.
     */
    public String renderDocument(UUID docId) {
        Document doc = documentService.getFullDocument(docId)
                .orElseThrow(() -> new IllegalArgumentException("Document not found: " + docId));

        return renderDocument(doc);
    }

    public String renderDocument(Document doc) {
        // 1. Render Sections recursively
        List<Section> sections = doc.getSections() != null ? doc.getSections() : Collections.emptyList();
        StringBuilder sectionsHtml = new StringBuilder();

        sections.stream()
                .sorted(Comparator.comparing(Section::getOrderIndex, Comparator.nullsLast(Comparator.naturalOrder())))
                .forEach(section -> {
                    String sectionHtml = renderSection(section, doc.getGlobalContext());
                    if (!sectionsHtml.isEmpty()) {
                        sectionsHtml.append("\n");
                    }
                    sectionsHtml.append(sectionHtml);
                });

        // 2. Resolve Document context (Global + Resolved DataPath + Local Data +
        // sections)
        Map<String, Object> context = resolveContext(doc.getData(), doc.getDataPath(), doc.getGlobalContext());
        context.put("id", doc.getId() != null ? doc.getId().toString() : "");
        context.put("title", doc.getTitle() != null ? doc.getTitle() : "");
        context.put("status", doc.getStatus() != null ? doc.getStatus().name() : "");
        context.put("createdAt", doc.getCreatedAt() != null ? doc.getCreatedAt().toString() : "");
        context.put("sections", sectionsHtml.toString());

        String templateStr = (doc.getTemplate() != null && !doc.getTemplate().isBlank())
                ? doc.getTemplate()
                : "{{{sections}}}";

        return compile(templateStr, context);
    }

    private String renderSection(Section section, Map<String, Object> globalContext) {
        List<Page> pages = section.getPages() != null ? section.getPages() : Collections.emptyList();
        StringBuilder pagesHtml = new StringBuilder();

        pages.stream()
                .sorted(Comparator.comparing(Page::getOrderIndex, Comparator.nullsLast(Comparator.naturalOrder())))
                .forEach(page -> {
                    String pageHtml = renderPage(page, globalContext);
                    if (!pagesHtml.isEmpty()) {
                        pagesHtml.append("\n");
                    }
                    pagesHtml.append(pageHtml);
                });

        Map<String, Object> context = resolveContext(section.getData(), section.getDataPath(), globalContext);
        context.put("id", section.getId() != null ? section.getId().toString() : "");
        context.put("pages", pagesHtml.toString());

        String templateStr = (section.getTemplate() != null && !section.getTemplate().isBlank())
                ? section.getTemplate()
                : "{{{pages}}}";

        return compile(templateStr, context);
    }

    private String renderPage(Page page, Map<String, Object> globalContext) {
        List<Component> components = page.getComponents() != null ? page.getComponents() : Collections.emptyList();
        StringBuilder componentsHtml = new StringBuilder();

        components.stream()
                .sorted(Comparator.comparing(Component::getZIndex, Comparator.nullsLast(Comparator.naturalOrder())))
                .forEach(comp -> {
                    String compHtml = renderComponent(comp, globalContext);
                    if (!componentsHtml.isEmpty()) {
                        componentsHtml.append("\n");
                    }
                    componentsHtml.append(compHtml);
                });

        Map<String, Object> context = resolveContext(page.getData(), page.getDataPath(), globalContext);
        context.put("id", page.getId() != null ? page.getId().toString() : "");
        context.put("width", page.getWidth());
        context.put("height", page.getHeight());
        context.put("components", componentsHtml.toString());

        String templateStr = (page.getTemplate() != null && !page.getTemplate().isBlank())
                ? page.getTemplate()
                : "<div class=\"page\">{{{components}}}</div>";

        return compile(templateStr, context);
    }

    private String renderComponent(Component comp, Map<String, Object> globalContext) {
        Map<String, Object> context = resolveContext(comp.getData(), comp.getDataPath(), globalContext);
        context.put("id", comp.getId() != null ? comp.getId().toString() : "");
        context.put("componentType", comp.getComponentType());
        context.put("x", comp.getX());
        context.put("y", comp.getY());
        context.put("width", comp.getWidth());
        context.put("height", comp.getHeight());

        String defaultTemplate = "<div class=\"component-" + comp.getComponentType() + "\">Component: "
                + comp.getComponentType() + "</div>";
        String templateStr = (comp.getTemplate() != null && !comp.getTemplate().isBlank())
                ? comp.getTemplate()
                : defaultTemplate;

        return compile(templateStr, context);
    }

    /**
     * Resolves the final data context for an entity:
     * Base: Global Context -> Resolved dataPath -> Local Data
     */
    @SuppressWarnings("unchecked")
    private Map<String, Object> resolveContext(Map<String, Object> localData, String dataPath,
            Map<String, Object> globalContext) {
        Map<String, Object> merged = new HashMap<>();
        if (globalContext != null) {
            merged.putAll(globalContext);
        }

        if (dataPath != null && !dataPath.isBlank() && globalContext != null) {
            Object resolved = DataPathResolver.resolve(globalContext, dataPath);
            if (resolved instanceof Map<?, ?> resolvedMap) {
                for (Map.Entry<?, ?> entry : resolvedMap.entrySet()) {
                    if (entry.getKey() != null) {
                        merged.put(entry.getKey().toString(), entry.getValue());
                    }
                }
            } else if (resolved != null) {
                merged.put("item", resolved);
            }
        }

        if (localData != null) {
            merged.putAll(localData);
        }

        return merged;
    }

    private String compile(String templateString, Map<String, Object> context) {
        try {
            Template template = handlebars.compileInline(templateString);
            return template.apply(context);
        } catch (IOException e) {
            log.error("Handlebars compile error", e);
            return "[Rendering Error: " + e.getMessage() + "]";
        }
    }
}
