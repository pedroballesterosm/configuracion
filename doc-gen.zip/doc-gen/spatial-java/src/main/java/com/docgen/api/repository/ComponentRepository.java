package com.docgen.api.repository;

import com.docgen.api.domain.Component;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ComponentRepository extends JpaRepository<Component, UUID> {

    @Query("SELECT c FROM Component c WHERE c.page.id = :pageId ORDER BY c.zIndex ASC")
    List<Component> findByPageIdOrdered(@Param("pageId") UUID pageId);
}
