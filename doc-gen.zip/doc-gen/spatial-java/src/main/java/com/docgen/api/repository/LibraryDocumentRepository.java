package com.docgen.api.repository;

import com.docgen.api.domain.LibraryDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface LibraryDocumentRepository extends JpaRepository<LibraryDocument, UUID> {
}
