package com.docgen.api.service;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.LibraryComponent;
import com.docgen.api.domain.LibraryDocument;
import com.docgen.api.domain.enums.DocumentStatus;
import com.docgen.api.repository.LibraryComponentRepository;
import com.docgen.api.repository.LibraryDocumentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.UUID;

@Service
public class LibraryService {

    private final LibraryDocumentRepository libraryDocumentRepository;
    private final LibraryComponentRepository libraryComponentRepository;
    private final DocumentService documentService;

    public LibraryService(LibraryDocumentRepository libraryDocumentRepository,
                          LibraryComponentRepository libraryComponentRepository,
                          DocumentService documentService) {
        this.libraryDocumentRepository = libraryDocumentRepository;
        this.libraryComponentRepository = libraryComponentRepository;
        this.documentService = documentService;
    }

    @Transactional
    public LibraryComponent createLibraryComponent(LibraryComponent comp) {
        return libraryComponentRepository.save(comp);
    }

    @Transactional
    public Document instantiateDocument(UUID libDocId) {
        LibraryDocument libDoc = libraryDocumentRepository.findById(libDocId)
                .orElseThrow(() -> new IllegalArgumentException("Library document not found: " + libDocId));

        Document doc = Document.builder()
                .title(libDoc.getName())
                .status(DocumentStatus.DRAFT)
                .template(libDoc.getTemplate())
                .data(libDoc.getData() != null ? new HashMap<>(libDoc.getData()) : new HashMap<>())
                .dataPath(libDoc.getDataPath())
                .globalContext(new HashMap<>())
                .metadata(new HashMap<>())
                .build();

        return documentService.createDocument(doc);
    }

    @Transactional
    public Component instantiateComponent(UUID libCompId, UUID pageId) {
        LibraryComponent libComp = libraryComponentRepository.findById(libCompId)
                .orElseThrow(() -> new IllegalArgumentException("Library component not found: " + libCompId));

        Component comp = Component.builder()
                .componentType(libComp.getComponentType())
                .template(libComp.getTemplate())
                .data(libComp.getData() != null ? new HashMap<>(libComp.getData()) : new HashMap<>())
                .dataPath(libComp.getDataPath())
                .build();

        return documentService.addComponent(pageId, comp);
    }
}
