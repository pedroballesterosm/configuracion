package com.docgen.api.service;

import com.docgen.api.domain.Component;
import com.docgen.api.domain.Document;
import com.docgen.api.domain.Page;
import com.docgen.api.domain.Section;
import com.docgen.api.domain.enums.DocumentStatus;
import com.docgen.api.repository.ComponentRepository;
import com.docgen.api.repository.DocumentRepository;
import com.docgen.api.repository.PageRepository;
import com.docgen.api.repository.SectionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class DocumentService {

  private static final Logger log = LoggerFactory.getLogger(DocumentService.class);

  private final DocumentRepository documentRepository;
  private final SectionRepository sectionRepository;
  private final PageRepository pageRepository;
  private final ComponentRepository componentRepository;

  public DocumentService(DocumentRepository documentRepository,
      SectionRepository sectionRepository,
      PageRepository pageRepository,
      ComponentRepository componentRepository) {
    this.documentRepository = documentRepository;
    this.sectionRepository = sectionRepository;
    this.pageRepository = pageRepository;
    this.componentRepository = componentRepository;
  }

  @Transactional(readOnly = true)
  public List<Document> getAllDocuments() {
    return documentRepository.findAllByOrderByCreatedAtDesc();
  }

  @Transactional(readOnly = true)
  public Optional<Document> getFullDocument(UUID id) {
    Optional<Document> docOpt = documentRepository.findById(id);
    if (docOpt.isEmpty()) {
      return Optional.empty();
    }

    Document doc = docOpt.get();
    List<Section> sections = sectionRepository.findByDocument_IdOrderByOrderIndexAsc(id);
    for (Section section : sections) {
      List<Page> pages = pageRepository.findBySection_IdOrderByOrderIndexAsc(section.getId());
      for (Page page : pages) {
        List<Component> components = componentRepository.findByPageIdOrdered(page.getId());
        page.setComponents(components);
      }
      section.setPages(pages);
    }
    doc.setSections(sections);
    return Optional.of(doc);
  }

  @Transactional
  public Document createDocument(Document document) {
    if (document.getTitle() == null || document.getTitle().isBlank()) {
      document.setTitle("New Untitled Document");
    }
    if (document.getStatus() == null) {
      document.setStatus(DocumentStatus.DRAFT);
    }
    return documentRepository.save(document);
  }

  @Transactional
  public boolean deleteDocument(UUID id) {
    if (documentRepository.existsById(id)) {
      documentRepository.deleteById(id);
      log.info("Successfully deleted document with ID: {}", id);
      return true;
    }
    log.warn("Failed to delete document with ID: {} - Not found", id);
    return false;
  }

  @Transactional
  public Section addSection(UUID documentId, Section section) {
    Document document = documentRepository.findById(documentId)
        .orElseThrow(() -> new IllegalArgumentException("Document not found: " + documentId));

    if (section.getOrderIndex() == null) {
      List<Section> existing = sectionRepository.findByDocument_IdOrderByOrderIndexAsc(documentId);
      section.setOrderIndex(existing.size());
    }
    section.setDocument(document);
    return sectionRepository.save(section);
  }

  @Transactional
  public Page addPage(UUID sectionId, Page page) {
    Section section = sectionRepository.findById(sectionId)
        .orElseThrow(() -> new IllegalArgumentException("Section not found: " + sectionId));

    if (page.getOrderIndex() == null) {
      List<Page> existing = pageRepository.findBySection_IdOrderByOrderIndexAsc(sectionId);
      page.setOrderIndex(existing.size());
    }
    page.setSection(section);
    return pageRepository.save(page);
  }

  @Transactional
  public Component addComponent(UUID pageId, Component component) {
    Page page = pageRepository.findById(pageId)
        .orElseThrow(() -> new IllegalArgumentException("Page not found: " + pageId));

    if (component.getZIndex() == null) {
      List<Component> existing = componentRepository.findByPageIdOrdered(pageId);
      component.setZIndex(existing.size() + 1);
    }
    if (component.getComponentType() == null || component.getComponentType().isBlank()) {
      component.setComponentType("text");
    }
    component.setPage(page);
    return componentRepository.save(component);
  }

  @Transactional
  public Document updateDocument(UUID id, Document patch) {
    Document doc = documentRepository.findById(id)
        .orElseThrow(() -> new IllegalArgumentException("Document not found: " + id));

    if (patch.getTitle() != null)
      doc.setTitle(patch.getTitle());
    if (patch.getStatus() != null)
      doc.setStatus(patch.getStatus());
    if (patch.getTemplate() != null)
      doc.setTemplate(patch.getTemplate());
    if (patch.getData() != null)
      doc.setData(patch.getData());
    if (patch.getDataPath() != null)
      doc.setDataPath(patch.getDataPath());
    if (patch.getGlobalContext() != null)
      doc.setGlobalContext(patch.getGlobalContext());
    if (patch.getMetadata() != null)
      doc.setMetadata(patch.getMetadata());

    return documentRepository.save(doc);
  }

  @Transactional
  public Section updateSection(UUID id, Section patch) {
    Section section = sectionRepository.findById(id)
        .orElseThrow(() -> new IllegalArgumentException("Section not found: " + id));

    if (patch.getOrderIndex() != null)
      section.setOrderIndex(patch.getOrderIndex());
    if (patch.getTemplate() != null)
      section.setTemplate(patch.getTemplate());
    if (patch.getData() != null)
      section.setData(patch.getData());
    if (patch.getDataPath() != null)
      section.setDataPath(patch.getDataPath());

    return sectionRepository.save(section);
  }

  @Transactional
  public Page updatePage(UUID id, Page patch) {
    Page page = pageRepository.findById(id)
        .orElseThrow(() -> new IllegalArgumentException("Page not found: " + id));

    if (patch.getOrderIndex() != null)
      page.setOrderIndex(patch.getOrderIndex());
    if (patch.getWidth() != null)
      page.setWidth(patch.getWidth());
    if (patch.getHeight() != null)
      page.setHeight(patch.getHeight());
    if (patch.getTemplate() != null)
      page.setTemplate(patch.getTemplate());
    if (patch.getData() != null)
      page.setData(patch.getData());
    if (patch.getDataPath() != null)
      page.setDataPath(patch.getDataPath());

    return pageRepository.save(page);
  }

  @Transactional
  public Component updateComponent(UUID id, Component patch) {
    Component component = componentRepository.findById(id)
        .orElseThrow(() -> new IllegalArgumentException("Component not found: " + id));

    if (patch.getComponentType() != null)
      component.setComponentType(patch.getComponentType());
    if (patch.getX() != null)
      component.setX(patch.getX());
    if (patch.getY() != null)
      component.setY(patch.getY());
    if (patch.getWidth() != null)
      component.setWidth(patch.getWidth());
    if (patch.getHeight() != null)
      component.setHeight(patch.getHeight());
    if (patch.getZIndex() != null)
      component.setZIndex(patch.getZIndex());
    if (patch.getTemplate() != null)
      component.setTemplate(patch.getTemplate());
    if (patch.getData() != null)
      component.setData(patch.getData());
    if (patch.getDataPath() != null)
      component.setDataPath(patch.getDataPath());

    return componentRepository.save(component);
  }
}
