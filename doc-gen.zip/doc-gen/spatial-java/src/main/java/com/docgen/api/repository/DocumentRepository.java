package com.docgen.api.repository;

import com.docgen.api.domain.Document;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface DocumentRepository extends JpaRepository<Document, UUID> {

    List<Document> findAllByOrderByCreatedAtDesc();

    @Query("SELECT DISTINCT d FROM Document d " +
           "LEFT JOIN FETCH d.sections s " +
           "LEFT JOIN FETCH s.pages p " +
           "LEFT JOIN FETCH p.components c " +
           "WHERE d.id = :id")
    Optional<Document> findByIdWithFullHierarchy(@Param("id") UUID id);
}
