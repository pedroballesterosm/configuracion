package com.docgen.api.service.pdf;

import com.openhtmltopdf.pdfboxout.PdfRendererBuilder;
import com.openhtmltopdf.svgsupport.BatikSVGDrawer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;

@Service("openHtmlToPdfService")
public class OpenHtmlToPdfService implements PdfGenerationService {

    private static final Logger log = LoggerFactory.getLogger(OpenHtmlToPdfService.class);

    @Override
    public byte[] generatePdf(String htmlContent, boolean landscape) {
        log.info("Generating PDF with OpenHTMLtoPDF (Native Pure Java)... Landscape={}", landscape);

        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            PdfRendererBuilder builder = new PdfRendererBuilder();
            builder.useFastMode();
            builder.useSVGDrawer(new BatikSVGDrawer());

            // Wrap or adjust HTML if landscape requested via page CSS
            String finalHtml = htmlContent;
            if (landscape && !htmlContent.contains("@page")) {
                finalHtml = "<style>@page { size: A4 landscape; margin: 20px; }</style>" + htmlContent;
            }

            builder.withHtmlContent(finalHtml, null);
            builder.toStream(os);
            builder.run();

            byte[] bytes = os.toByteArray();
            log.info("PDF generated successfully via OpenHTMLtoPDF ({} bytes)", bytes.length);
            return bytes;
        } catch (Exception e) {
            log.error("Failed to generate PDF with OpenHTMLtoPDF", e);
            throw new RuntimeException("OpenHTMLtoPDF Generation Error: " + e.getMessage(), e);
        }
    }
}
