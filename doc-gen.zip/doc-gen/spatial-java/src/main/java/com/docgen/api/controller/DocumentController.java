package com.docgen.api.controller;

import com.docgen.api.domain.Document;
import com.docgen.api.domain.Section;
import com.docgen.api.service.DocumentService;
import com.docgen.api.service.RenderingService;
import com.docgen.api.service.pdf.PdfGenerationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    private static final Logger log = LoggerFactory.getLogger(DocumentController.class);

    private final DocumentService documentService;
    private final RenderingService renderingService;
    private final PdfGenerationService pdfGenerationService;

    public DocumentController(DocumentService documentService,
                              RenderingService renderingService,
                              PdfGenerationService pdfGenerationService) {
        this.documentService = documentService;
        this.renderingService = renderingService;
        this.pdfGenerationService = pdfGenerationService;
    }

    @GetMapping
    public ResponseEntity<List<Document>> getAllDocuments() {
        return ResponseEntity.ok(documentService.getAllDocuments());
    }

    @PostMapping
    public ResponseEntity<Document> createDocument(@RequestBody Document document) {
        return ResponseEntity.ok(documentService.createDocument(document));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getDocumentById(@PathVariable("id") UUID id) {
        return documentService.getFullDocument(id)
                .<ResponseEntity<?>>map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of("error", "Document not found")));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteDocument(@PathVariable("id") UUID id) {
        boolean deleted = documentService.deleteDocument(id);
        if (!deleted) {
            return ResponseEntity.status(404).body(Map.of("error", "Document not found"));
        }
        return ResponseEntity.ok(Map.of("success", true));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Document> updateDocument(@PathVariable("id") UUID id, @RequestBody Document document) {
        return ResponseEntity.ok(documentService.updateDocument(id, document));
    }

    @GetMapping(value = "/{id}/render", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> renderDocument(@PathVariable("id") UUID id) {
        String html = renderingService.renderDocument(id);
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_HTML)
                .body(html);
    }

    @GetMapping(value = "/{id}/pdf", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<byte[]> generateDocumentPdf(@PathVariable("id") UUID id) {
        Document doc = documentService.getFullDocument(id)
                .orElseThrow(() -> new IllegalArgumentException("Document not found: " + id));

        String html = renderingService.renderDocument(doc);

        boolean isLandscape = false;
        if (doc.getMetadata() != null && Boolean.TRUE.equals(doc.getMetadata().get("landscape"))) {
            isLandscape = true;
        }

        byte[] pdfBytes = pdfGenerationService.generatePdf(html, isLandscape);

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"document-" + id + ".pdf\"")
                .body(pdfBytes);
    }

    @PostMapping("/{id}/sections")
    public ResponseEntity<Section> addSection(@PathVariable("id") UUID id, @RequestBody(required = false) Section section) {
        Section sec = section != null ? section : new Section();
        return ResponseEntity.ok(documentService.addSection(id, sec));
    }
}
