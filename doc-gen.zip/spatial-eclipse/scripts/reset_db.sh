#!/bin/bash

# Detect container runtime
if command -v podman &> /dev/null; then
    CMD="podman"
else
    CMD="docker"
fi

CONTAINER_NAME="spatial_eclipse_db"
DB_NAME="document_engine"
DB_USER="admin"

echo "Using runtime: $CMD"
echo "Target container: $CONTAINER_NAME"

# Check if container is running
if ! $CMD ps | grep -q $CONTAINER_NAME; then
    echo "Error: Container $CONTAINER_NAME is not running."
    exit 1
fi

echo "Terminating connections to $DB_NAME..."
$CMD exec -i $CONTAINER_NAME psql -U $DB_USER -d postgres -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = '$DB_NAME' AND pid <> pg_backend_pid();"

echo "Dropping database $DB_NAME..."
$CMD exec -i $CONTAINER_NAME psql -U $DB_USER -d postgres -c "DROP DATABASE IF EXISTS $DB_NAME;"

echo "Creating database $DB_NAME..."
$CMD exec -i $CONTAINER_NAME psql -U $DB_USER -d postgres -c "CREATE DATABASE $DB_NAME;"

echo "Applying migrations..."
$CMD exec -i $CONTAINER_NAME psql -U $DB_USER -d $DB_NAME -f /docker-entrypoint-initdb.d/01_init.sql

# Optional: Apply seed data if needed
# $CMD exec -i $CONTAINER_NAME psql -U $DB_USER -d $DB_NAME -f /docker-entrypoint-initdb.d/seed_data.sql

echo "Database $DB_NAME reset and initialized successfully."
