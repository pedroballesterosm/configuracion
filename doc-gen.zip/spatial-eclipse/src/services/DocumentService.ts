import {
    Document, Section, Page, Component, DocumentStatus
} from '../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository
} from '../core/repositories/interfaces';

export class DocumentService {
    constructor(
        private docRepo: IDocumentRepository,
        private sectionRepo: ISectionRepository,
        private pageRepo: IPageRepository,
        private compRepo: IComponentRepository
    ) { }

    async createDocument(data: Partial<Document>): Promise<Document> {
        const docData = {
            title: data.title || 'Untitled Document',
            status: DocumentStatus.DRAFT,
            template: data.template || '',
            data: data.data || {},
            globalContext: data.globalContext || {},
            metadata: data.metadata || {}
        };
        return this.docRepo.create(docData as any);
    }

    async getAllDocuments(): Promise<Document[]> {
        return this.docRepo.findAll();
    }

    async deleteDocument(id: string): Promise<boolean> {
        return this.docRepo.delete(id);
    }

    async getFullDocument(id: string): Promise<Document | null> {
        const doc = await this.docRepo.findById(id);
        if (!doc) return null;

        // Load Sections
        const sections = await this.sectionRepo.findByDocumentId(id);
        doc.sections = sections;

        // Load Pages for each Section
        for (const section of sections) {
            const pages = await this.pageRepo.findBySectionId(section.id);
            section.pages = pages;

            // Load Components for each Page
            for (const page of pages) {
                const components = await this.compRepo.findByPageId(page.id);
                page.components = components;
            }
        }

        return doc;
    }

    async addSection(docId: string, data: Partial<Section>): Promise<Section> {
        const sections = await this.sectionRepo.findByDocumentId(docId);
        const nextOrder = sections.length > 0 ? Math.max(...sections.map(s => s.orderIndex || 0)) + 1 : 0;

        return this.sectionRepo.create({
            orderIndex: data.orderIndex !== undefined ? data.orderIndex : nextOrder,
            template: data.template || '',
            data: data.data || {},
            dataPath: data.dataPath || '',
            documentId: docId,
            pages: []
        } as any);
    }

    async addPage(sectionId: string, data: Partial<Page>): Promise<Page> {
        const pages = await this.pageRepo.findBySectionId(sectionId);
        const nextOrder = pages.length > 0 ? Math.max(...pages.map(p => p.orderIndex || 0)) + 1 : 0;

        return this.pageRepo.create({
            orderIndex: data.orderIndex !== undefined ? data.orderIndex : nextOrder,
            template: data.template || '',
            data: data.data || {},
            dataPath: data.dataPath || '',
            width: data.width || 800,
            height: data.height || 600,
            sectionId: sectionId,
            components: []
        } as any);
    }

    async addComponent(pageId: string, data: Partial<Component>): Promise<Component> {
        const components = await this.compRepo.findByPageId(pageId);

        return this.compRepo.create({
            componentType: data.componentType || 'text',
            template: data.template || '',
            data: data.data || {},
            dataPath: data.dataPath || '',
            x: data.x || 0,
            y: data.y || 0,
            width: data.width || 200,
            height: data.height || 100,
            zIndex: data.zIndex || (components.length > 0 ? Math.max(...components.map(c => c.zIndex || 0)) + 1 : 1),
            pageId: pageId
        } as any);
    }

    async updateDocument(id: string, data: Partial<Document>): Promise<Document> {
        return this.docRepo.update(id, data);
    }

    async updateSection(id: string, data: Partial<Section>): Promise<Section> {
        return this.sectionRepo.update(id, data);
    }

    async updatePage(id: string, data: Partial<Page>): Promise<Page> {
        return this.pageRepo.update(id, data);
    }

    async updateComponent(id: string, data: Partial<Component>): Promise<Component> {
        return this.compRepo.update(id, data);
    }
}
