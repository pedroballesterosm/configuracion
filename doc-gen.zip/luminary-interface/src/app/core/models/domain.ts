export interface Document {
    id: string;
    title: string;
    status: 'DRAFT' | 'PUBLISHED' | 'ARCHIVED';
    template?: string;
    metadata?: Record<string, any>;
    globalContext?: any;
    createdAt?: string;
    updatedAt?: string;
    // Full structure for detailed view
    sections?: Section[];
}

export interface Section {
    id: string;
    documentId: string;
    orderIndex: number;
    template?: string;
    data?: any;
    pages?: Page[];
}

export interface Page {
    id: string;
    sectionId: string;
    orderIndex: number;
    template?: string;
    data?: any;
    components?: Component[];
}

export interface Component {
    id: string;
    pageId: string;
    componentType: string;
    template?: string;
    data?: any;
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    zIndex?: number;
}
