import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Document, Section, Page, Component as DocComponent } from '../models/domain';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {
  private http = inject(HttpClient);
  private apiUrl = '/api'; // Proxy or absolute URL if CORS enabled

  getDocuments(): Observable<Document[]> {
    return this.http.get<Document[]>(`${this.apiUrl}/documents`);
  }

  getDocumentById(id: string): Observable<Document> {
    return this.http.get<Document>(`${this.apiUrl}/documents/${id}`);
  }

  createDocument(doc: Partial<Document>): Observable<Document> {
    return this.http.post<Document>(`${this.apiUrl}/documents`, doc);
  }

  // Not implemented in backend yet, but good to have prepared
  deleteDocument(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/documents/${id}`);
  }

  addSection(documentId: string, section: Partial<Section> = {}): Observable<Section> {
    return this.http.post<Section>(`${this.apiUrl}/documents/${documentId}/sections`, section);
  }

  addPage(sectionId: string, page: Partial<Page> = {}): Observable<Page> {
    return this.http.post<Page>(`${this.apiUrl}/sections/${sectionId}/pages`, page);
  }

  addComponent(pageId: string, component: Partial<DocComponent> = { componentType: 'text' }): Observable<DocComponent> {
    return this.http.post<DocComponent>(`${this.apiUrl}/pages/${pageId}/components`, component);
  }

  updateDocument(id: string, document: Partial<Document>): Observable<Document> {
    return this.http.put<Document>(`${this.apiUrl}/documents/${id}`, document);
  }

  updateSection(id: string, section: Partial<Section>): Observable<Section> {
    return this.http.put<Section>(`${this.apiUrl}/sections/${id}`, section);
  }

  updatePage(id: string, page: Partial<Page>): Observable<Page> {
    return this.http.put<Page>(`${this.apiUrl}/pages/${id}`, page);
  }

  updateComponent(id: string, component: Partial<DocComponent>): Observable<DocComponent> {
    return this.http.put<DocComponent>(`${this.apiUrl}/components/${id}`, component);
  }
}
