import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { DocumentService } from '../../core/services/document';
import { toSignal } from '@angular/core/rxjs-interop';
import { BehaviorSubject, switchMap } from 'rxjs';

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './documents.html',
  styleUrl: './documents.css'
})
export class DocumentsComponent {
  private documentService = inject(DocumentService);
  private refresh$ = new BehaviorSubject<void>(undefined);

  // Reactively fetch documents whenever refresh$ emits
  documents = toSignal(
    this.refresh$.pipe(switchMap(() => this.documentService.getDocuments())),
    { initialValue: [] }
  );

  createDocument() {
    const newDoc = {
      title: 'New Untitled Document',
      status: 'DRAFT' as const,
      metadata: { author: 'User' }
    };
    this.documentService.createDocument(newDoc).subscribe(() => {
      this.refresh$.next();
    });
  }

  deleteDocument(id: string, event: Event) {
    event.stopPropagation(); // Prevent card click
    if (confirm('Are you sure you want to delete this document?')) {
      this.documentService.deleteDocument(id).subscribe(() => {
        this.refresh$.next();
      });
    }
  }

  previewDocument(id: string, event: Event) {
    event.stopPropagation();
    window.open(`/api/documents/${id}/render`, '_blank');
  }
}
