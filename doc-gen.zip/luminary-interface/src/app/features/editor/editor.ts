import { Component, inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Observable, forkJoin } from 'rxjs';
import { MonacoEditorModule } from 'ngx-monaco-editor-v2';
import { DocumentService } from '../../core/services/document';
import { Document, Section, Page, Component as DocComponent } from '../../core/models/domain';

@Component({
    selector: 'app-document-editor',
    standalone: true,
    imports: [CommonModule, RouterModule, FormsModule, MonacoEditorModule],
    templateUrl: './editor.html',
    styleUrl: './editor.css'
})
export class DocumentEditorComponent implements OnInit {
    editorOptions = { theme: 'vs-dark', language: 'html', minimap: { enabled: false } };
    jsonEditorOptions = { theme: 'vs-dark', language: 'json', minimap: { enabled: false } };

    private route = inject(ActivatedRoute);
    private documentService = inject(DocumentService);
    private cdr = inject(ChangeDetectorRef);

    document: Document | null = null;
    loading = true;
    error: string | null = null;
    isSaving = false;

    // Selected elements for detail view
    selectedSection: Section | null = null;
    selectedPage: Page | null = null;
    selectedComponent: DocComponent | null = null;

    ngOnInit() {
        console.log('[Editor] ngOnInit called');
        this.route.paramMap.subscribe(params => {
            const id = params.get('id');
            console.log('[Editor] Route params changed, id:', id);
            if (id) {
                this.loadDocument(id);
            } else {
                this.error = 'No document ID provided in URL.';
                this.loading = false;
                this.cdr.detectChanges();
            }
        });
    }

    loadDocument(id: string) {
        console.log('[Editor] loadDocument started for id:', id);
        this.loading = true;
        this.error = null;
        this.documentService.getDocumentById(id).subscribe({
            next: (doc) => {
                console.log('[Editor] Document loaded successfully:', doc);
                this.document = doc;
                this.loading = false;

                // Auto-select first elements if they exist
                if (this.document.sections && this.document.sections.length > 0) {
                    this.selectedSection = this.document.sections[0];
                    if (this.selectedSection.pages && this.selectedSection.pages.length > 0) {
                        this.selectedPage = this.selectedSection.pages[0];
                    }
                }

                try {
                    this.cdr.detectChanges();
                    console.log('[Editor] Change detection completed');
                } catch (e) {
                    console.error('[Editor] Template Render Error:', e);
                    this.error = 'Runtime error during render: ' + String(e);
                    this.loading = false;
                }
            },
            error: (err) => {
                console.log('[Editor] Error loading document:', err);
                this.error = 'Failed to load document. It may not exist or the server is down.';
                console.error(err);
                this.loading = false;
                this.cdr.detectChanges();
            }
        });
    }

    selectSection(section: Section) {
        this.selectedSection = section;
        this.selectedPage = null;
        this.selectedComponent = null;
    }

    selectPage(page: Page) {
        this.selectedPage = page;
        this.selectedComponent = null;
    }

    selectComponent(comp: DocComponent) {
        this.selectedComponent = comp;
    }

    clearSelection() {
        this.selectedSection = null;
        this.selectedPage = null;
        this.selectedComponent = null;
    }

    previewDocument() {
        if (this.document) {
            window.open(`/api/documents/${this.document.id}/render`, '_blank');
        }
    }

    addSection() {
        if (!this.document) return;
        this.documentService.addSection(this.document.id).subscribe({
            next: (section) => {
                this.document!.sections = this.document!.sections || [];
                this.document!.sections.push(section);
                this.selectSection(section);
                this.cdr.detectChanges();
            },
            error: (err) => console.error('Failed to add section', err)
        });
    }

    addPage(section: Section, event: Event) {
        event.stopPropagation();
        this.documentService.addPage(section.id).subscribe({
            next: (page) => {
                section.pages = section.pages || [];
                section.pages.push(page);
                this.selectPage(page);
                this.cdr.detectChanges();
            },
            error: (err) => console.error('Failed to add page', err)
        });
    }

    addComponent(page: Page, event: Event) {
        event.stopPropagation();
        this.documentService.addComponent(page.id, { componentType: 'text' }).subscribe({
            next: (comp) => {
                page.components = page.components || [];
                page.components.push(comp);
                this.selectComponent(comp);
                this.cdr.detectChanges();
            },
            error: (err) => console.error('Failed to add component', err)
        });
    }

    saveChanges() {
        if (!this.document) return;
        this.isSaving = true;

        const calls: Observable<any>[] = [];

        // 1. Save Document properties
        calls.push(this.documentService.updateDocument(this.document.id, {
            title: this.document.title,
            status: this.document.status,
            template: this.document.template,
            globalContext: this.document.globalContext
        }));

        // 2. Save Sections
        this.document.sections?.forEach((sec, sIdx) => {
            calls.push(this.documentService.updateSection(sec.id, {
                orderIndex: sIdx, // Just in case they moved
                template: sec.template,
                data: sec.data
            }));

            // 3. Save Pages
            sec.pages?.forEach((page, pIdx) => {
                calls.push(this.documentService.updatePage(page.id, {
                    orderIndex: pIdx,
                    template: page.template,
                    data: page.data
                }));

                // 4. Save Components
                page.components?.forEach((comp, cIdx) => {
                    calls.push(this.documentService.updateComponent(comp.id, {
                        zIndex: cIdx + 1,
                        template: comp.template,
                        data: comp.data
                    }));
                });
            });
        });

        forkJoin(calls).subscribe({
            next: () => {
                this.isSaving = false;
                this.cdr.detectChanges();
                // We could add a toast notification system here in the future
                console.log('Document saved successfully!');
            },
            error: (err) => {
                this.isSaving = false;
                this.cdr.detectChanges();
                console.error('Failed to save document', err);
                alert('Save failed. See console for details.');
            }
        });
    }

    getJsonString(obj: any): string {
        try {
            return JSON.stringify(obj || {}, null, 2);
        } catch (e) {
            return '{}';
        }
    }

    updateJsonObj(obj: any, field: string, event: Event) {
        try {
            const value = (event.target as HTMLTextAreaElement).value;
            obj[field] = JSON.parse(value);
        } catch (e) {
            // Ignore parse errors while typing
        }
    }

    updateJsonObjMonaco(obj: any, field: string, value: string) {
        try {
            obj[field] = JSON.parse(value);
        } catch (e) {
            // Ignore parse errors while typing
        }
    }
}
