import { Routes } from '@angular/router';
import { LayoutComponent } from './features/layout';
import { DashboardComponent } from './features/dashboard/dashboard';

export const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
            { path: 'dashboard', component: DashboardComponent },
            { path: 'documents', loadComponent: () => import('./features/documents/documents').then(m => m.DocumentsComponent) },
            { path: 'documents/:id/edit', loadComponent: () => import('./features/editor/editor').then(m => m.DocumentEditorComponent) }
        ]
    },
    { path: '**', redirectTo: 'dashboard' }
];
