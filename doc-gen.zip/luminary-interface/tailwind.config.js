/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        "./src/**/*.{html,ts}",
    ],
    theme: {
        extend: {
            colors: {
                // "Cosmic Glass" Palette
                primary: '#3b82f6', // blue-500
                secondary: '#8b5cf6', // violet-500
                accent: '#e67e22', // orange-500 (from previous theme)
                dark: {
                    900: '#0f172a', // slate-900
                    800: '#1e293b', // slate-800
                    700: '#334155', // slate-700
                },
                glass: {
                    light: 'rgba(255, 255, 255, 0.1)',
                    dark: 'rgba(15, 23, 42, 0.6)',
                }
            },
            fontFamily: {
                sans: ['Inter', 'sans-serif'],
            }
        },
    },
    plugins: [],
}
