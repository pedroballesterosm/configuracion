# Skill de Devin: `actualizar-contexto`

Esta skill permite mantener sincronizado el contexto técnico, el contrato de APIs/DTOs y el progreso de desarrollo entre distintas sesiones de **Devin** o entre varios compañeros de equipo trabajando sobre **repositorios separados** (Angular, Java o Node).

---

## Contenido del paquete

```text
skill-actualizar-contexto/
├── README.md
└── .agents/
    └── skills/
        └── actualizar-contexto/
            └── SKILL.md
```

---

## Instalación

Puedes instalar esta skill de dos formas según las necesidades de tu equipo:

### Opción A: A nivel de organización/equipo (Recomendada para múltiples repos)
1. Entra en la interfaz web de Devin y ve a **Customize → Skills → Create Skill**.
2. Abre el archivo `.agents/skills/actualizar-contexto/SKILL.md` de este paquete y copia todo su contenido.
3. Pégalo en el editor de Devin y guarda la skill (Devin detectará automáticamente el nombre `actualizar-contexto` y su descripción).
4. A partir de ese momento estará disponible en **todos** vuestros repositorios sin necesidad de copiar archivos en cada proyecto.

### Opción B: Dentro de un repositorio concreto
1. Descomprime este paquete y copia la carpeta `.agents/` en la raíz de tu repositorio (junto a `package.json`, `pom.xml`, etc.).
2. Haz commit y push de `.agents/skills/actualizar-contexto/SKILL.md` a tu rama principal (`main` o `develop`).

---

## Guía de uso en el día a día

### 1. Inicializar el contexto en un proyecto
La primera vez que uses la skill en un repositorio (ya sea frontend Angular o backend Java/Node), abre Devin y pídele:

> *"Ejecuta `@skills:actualizar-contexto` para analizar el repositorio y crear `AGENTS.md` y `ESTADO_PROYECTO.md`."*

Devin generará en la raíz del proyecto:
- **`AGENTS.md`**: Arquitectura, comandos reales de compilación/test, tabla de endpoints/DTOs y la regla obligatoria de leer el estado antes de empezar a programar. Devin lee este archivo automáticamente al iniciar cualquier sesión.
- **`ESTADO_PROYECTO.md`**: Memoria viva con lo completado, tareas en curso, decisiones técnicas y próximos pasos.

### 2. Guardar progreso antes de cerrar sesión o hacer relevo
Cuando termines una funcionalidad, vayas a cerrar el chat o quieras pasarle el relevo a otro compañero, pídele a Devin:

> *"Ejecuta `@skills:actualizar-contexto` y haz commit de `AGENTS.md` y `ESTADO_PROYECTO.md`."*

Al finalizar, Devin actualizará ambos archivos y te mostrará en el chat un **mensaje de relevo** listo para copiar y pegar en Slack o Microsoft Teams.

### 3. Retomar el trabajo tras perder sesión o cambiar de persona
Cuando tú o un compañero abráis una sesión nueva en Devin sobre ese repositorio:
1. Devin leerá `AGENTS.md` de forma automática.
2. Solo tenéis que decirle:
   > *"Revisa `ESTADO_PROYECTO.md` y continúa con el primer punto de los próximos pasos."*

---

## Consejos para trabajo en equipo con Git
- **Evitar conflictos de merge:** Si dos personas trabajan en ramas diferentes al mismo tiempo, cada rama actualizará su propio `ESTADO_PROYECTO.md`. Al fusionar ramas en `develop` o `main`, si surge conflicto en ese archivo, pídele a Devin: *"Resuelve el conflicto en `ESTADO_PROYECTO.md` combinando el progreso de ambas ramas"*.
- **Límite de tamaño:** `AGENTS.md` está configurado para mantenerse por debajo de 12 KB para aprovechar siempre la carga automática de Devin (límite de 16 KiB).
