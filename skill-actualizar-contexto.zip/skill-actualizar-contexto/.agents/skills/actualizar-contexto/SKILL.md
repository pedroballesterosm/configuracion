---
name: actualizar-contexto
description: Genera o actualiza AGENTS.md y ESTADO_PROYECTO.md en repositorios separados (Angular, Java o Node) documentando arquitectura, contrato de APIs/DTOs, progreso y mensaje de relevo para el equipo. Usar al iniciar un proyecto, antes de cerrar sesión o al pasar el relevo a un compañero.
---

# Sincronización de Contexto y Relevo de Equipo

Tu objetivo es mantener actualizado el estado de este repositorio para que cualquier compañero o nueva sesión de Devin pueda retomar el trabajo sin perder contexto ni romper la integración con otros repositorios.

## Pasos a seguir

### 1. Analizar el repositorio
- Identifica el stack y revisa archivos clave:
  - **Frontend (Angular):** `angular.json`, `package.json`, `src/app/` (rutas, servicios HTTP, interceptores, modelos/interfaces).
  - **Backend (Java):** `pom.xml` o `build.gradle`, `src/main/java/`, controladores REST, DTOs, seguridad, `application.yml`/`properties` y configuración OpenAPI/Swagger si existe.
  - **Backend (Node):** `package.json`, `tsconfig.json`, rutas/controladores, middlewares, DTOs/esquemas (Zod/class-validator/Prisma/TypeORM) y OpenAPI/Swagger si existe.
- Revisa `git log -n 10 --oneline`, `git branch --show-current` y `git status` para detectar los últimos cambios.

### 2. Crear o actualizar `AGENTS.md` (Reglas estables, máx. 12 KB)
- Si no existe, créalo en la raíz. Si ya existe, actualiza solo cambios estructurales sin borrar reglas del equipo.
- Incluye estas secciones:
  1. **Rol del repositorio:** Qué parte del sistema es (ej. *Frontend Web Angular*, *API Core Java/Spring*, *Microservicio Node*) y su responsabilidad principal.
  2. **Stack y comandos reales:** Versiones clave y comandos exactos para instalar, arrancar en local, compilar y pasar tests/linters.
  3. **Arquitectura y convenciones:** Estructura de carpetas, gestión de errores, validación y estándares del equipo.
  4. **Contrato de integración (APIs y DTOs):** Usa estrictamente esta tabla y formato:
     - **Autenticación:** Cómo se envía o valida (ej. `Header Authorization: Bearer <JWT>`, interceptor HTTP, etc.).
     - **Especificación OpenAPI/Swagger:** Ruta del archivo o endpoint de docs si existe (ej. `/v3/api-docs` o `openapi.yaml`).
     - **Tabla de Endpoints clave (expuestos en Backend / consumidos en Frontend):**

       | Método | Ruta | Request DTO / Params | Response DTO (200/201) | Estado (Real / Mock) |
       | :--- | :--- | :--- | :--- | :--- |
       | `POST` | `/api/ejemplo` | `{ campo: string }` | `{ id: number }` | Real |
     - **Ubicación de modelos/DTOs:** Ruta exacta en el repo donde viven las interfaces o clases de transferencia.
  5. **Protocolo de continuidad (Obligatorio):** Regla explícita indicando que al iniciar cualquier tarea se debe leer `ESTADO_PROYECTO.md` antes de modificar código.

### 3. Actualizar `ESTADO_PROYECTO.md` (Memoria viva de sesión)
- Actualiza este archivo en la raíz usando exactamente estas secciones:
  - **Última actualización:** Fecha, rama actual y resumen en 2 líneas de lo último realizado.
  - **Completado en este repo:** Componentes, pantallas, servicios o endpoints terminados y verificados.
  - **En curso / Pendiente de integración:** Tareas a medias, endpoints aún mockeados en Angular o cambios de DTO pendientes de sincronizar con el otro repo.
  - **Decisiones técnicas:** Librerías elegidas, cambios de arquitectura o acuerdos tomados.
  - **Próximos pasos:** Lista priorizada de las siguientes tareas inmediatas.

### 4. Generar mensaje de relevo (Handoff) en el chat
Al terminar de actualizar los archivos, muestra al final de tu respuesta un bloque de código listo para copiar y pegar en Slack o Microsoft Teams con este formato exacto:

```text
🔄 *Relevo Devin — [Nombre del Repo]* (`[rama-actual]`)
✅ *Hecho:* [Resumen en 1-2 puntos de lo completado]
🚧 *Pendiente / En curso:* [Qué queda a medias o si hay mocks/cambios de API que afecten al otro repo]
➡️ *Siguiente paso:* [Primera tarea que debe abordar la siguiente persona o sesión]
📄 *Contexto actualizado en:* `ESTADO_PROYECTO.md` y `AGENTS.md`
```

## Restricciones
- **No inventes** rutas, endpoints, DTOs ni comandos que no hayas verificado en el código.
- **No incluyas secretos**, tokens, contraseñas ni URLs internas con credenciales (usa nombres de variables de entorno como `API_BASE_URL`).
- Mantén `AGENTS.md` por debajo de **12 KB** para no saturar el límite de carga automática de Devin (16 KiB).
