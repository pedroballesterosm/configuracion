import {
    Document, Section, Page, Component, DocumentStatus
} from '../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository
} from '../core/repositories/interfaces';

export class DocumentService {
    constructor(
        private docRepo: IDocumentRepository,
        private sectionRepo: ISectionRepository,
        private pageRepo: IPageRepository,
        private compRepo: IComponentRepository
    ) { }

    async createDocument(data: Partial<Document>): Promise<Document> {
        const docData = {
            title: data.title || 'Untitled Document',
            status: DocumentStatus.DRAFT,
            template: data.template || '',
            data: data.data || {},
            globalContext: data.globalContext || {},
            metadata: data.metadata || {}
        };
        return this.docRepo.create(docData as any);
    }

    async getAllDocuments(): Promise<Document[]> {
        return this.docRepo.findAll();
    }

    async getFullDocument(id: string): Promise<Document | null> {
        const doc = await this.docRepo.findById(id);
        if (!doc) return null;

        // Load Sections
        const sections = await this.sectionRepo.findByDocumentId(id);
        doc.sections = sections;

        // Load Pages for each Section
        for (const section of sections) {
            const pages = await this.pageRepo.findBySectionId(section.id);
            section.pages = pages;

            // Load Components for each Page
            for (const page of pages) {
                const components = await this.compRepo.findByPageId(page.id);
                page.components = components;
            }
        }

        return doc;
    }

    async addSection(docId: string, data: Partial<Section>): Promise<Section> {
        return this.sectionRepo.create({
            ...data,
            documentId: docId,
            pages: [] // init empty
        } as any);
    }

    async addPage(sectionId: string, data: Partial<Page>): Promise<Page> {
        return this.pageRepo.create({
            ...data,
            sectionId: sectionId,
            components: [] // init empty
        } as any);
    }

    async addComponent(pageId: string, data: Partial<Component>): Promise<Component> {
        return this.compRepo.create({
            ...data,
            pageId: pageId
        } as any);
    }
}
