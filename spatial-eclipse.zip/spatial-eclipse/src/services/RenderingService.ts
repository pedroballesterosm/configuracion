import Handlebars from 'handlebars';

import { Document, Section, Page, Component } from '../core/entities/domain';
import { DocumentService } from './DocumentService';

export class RenderingService {
    constructor(private documentService: DocumentService) {
        Handlebars.registerHelper('json', (context) => JSON.stringify(context));
    }

    /**
     * Main entry point: Renders a Document ID to an HTML string.
     */
    async renderDocument(docId: string): Promise<string> {
        const doc = await this.documentService.getFullDocument(docId);
        if (!doc) throw new Error(`Document ${docId} not found`);

        // 1. Render Sections recursively
        const sectionsHtmlPromises = doc.sections
            .sort((a, b) => a.orderIndex - b.orderIndex)
            .map(section => this.renderSection(section, doc.globalContext));

        const sectionsHtml = (await Promise.all(sectionsHtmlPromises)).join('\n');

        // 2. Resolve Document context (Global + Local)
        const context = this.resolveContext(doc, doc.globalContext);

        // 3. Compile Document Template
        // Inject rendered sections into the special variable 'sections'
        const finalContext = { ...context, sections: sectionsHtml };
        return this.compile(doc.template || '{{{sections}}}', finalContext);
    }

    private async renderSection(section: Section, globalContext: any): Promise<string> {
        // 1. Render Pages recursively
        const pagesHtmlPromises = section.pages
            .sort((a, b) => a.orderIndex - b.orderIndex)
            .map(page => this.renderPage(page, globalContext));

        const pagesHtml = (await Promise.all(pagesHtmlPromises)).join('\n');

        // 2. Resolve Context
        const context = this.resolveContext(section, globalContext);
        const finalContext = { ...context, pages: pagesHtml };

        // 3. Compile
        return this.compile(section.template || '<section>{{{pages}}}</section>', finalContext);
    }

    private async renderPage(page: Page, globalContext: any): Promise<string> {
        // 1. Render Components recursively
        const componentsHtmlPromises = page.components
            // .sort((a, b) => a.zIndex - b.zIndex) // Contextual sort
            .map(comp => this.renderComponent(comp, globalContext));

        const componentsHtml = (await Promise.all(componentsHtmlPromises)).join('\n');

        // 2. Resolve Context
        const context = this.resolveContext(page, globalContext);
        const finalContext = { ...context, components: componentsHtml };

        // 3. Compile
        return this.compile(page.template || '<div class="page">{{{components}}}</div>', finalContext);
    }

    private async renderComponent(component: Component, globalContext: any): Promise<string> {
        const context = this.resolveContext(component, globalContext);
        const defaultTemplate = `<div class="component-${component.componentType}">Component: ${component.componentType}</div>`;
        return this.compile(component.template || defaultTemplate, context);
    }

    // ==========================================
    // Helper Methods
    // ==========================================

    /**
     * Resolves the final data context for an entity.
     * Logic: (GlobalContext @ dataPath) + LocalData
     */
    private resolveContext(entity: { data: any, dataPath?: string }, globalContext: any): any {
        let resolvedGlobalData = {};

        if (entity.dataPath) {
            // Use lodash.get to safely access nested properties
            // e.g. "invoice.items[0]"
            resolvedGlobalData = get(globalContext, entity.dataPath, {});
        }

        // Merge: Global Context is base, then Resolved Path, then Local Data
        return { ...globalContext, ...resolvedGlobalData, ...entity.data };
    }

    private compile(template: string, context: any): string {
        try {
            const compiled = Handlebars.compile(template);
            return compiled(context);
        } catch (err) {
            console.error('Handlebars compile error:', err);
            return `[Rendering Error: ${(err as Error).message}]`;
        }
    }
}

// Simple implementation of lodash.get to avoid extra huge dependency if we want light
function get(object: any, path: string, defaultValue: any): any {
    const result = path.split(/[\.\[\]\'\"]/).filter(p => p).reduce((o, p) => (o ? o[p] : undefined), object);
    return result === undefined ? defaultValue : result;
}
