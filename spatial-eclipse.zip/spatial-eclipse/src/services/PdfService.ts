import puppeteer from 'puppeteer';

export class PdfService {
    async generatePdf(htmlContent: string, options: { landscape?: boolean } = {}): Promise<Buffer> {
        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox'] // Critical for running in some containerized envs
        });

        try {
            const page = await browser.newPage();

            // We set content and wait for network idle to ensure assets (images/fonts) would load if we had them
            await page.setContent(htmlContent, {
                waitUntil: 'networkidle0'
            });

            const pdfBuffer = await page.pdf({
                format: 'A4',
                landscape: options.landscape || false, // Dynamic orientation
                printBackground: true,
                margin: {
                    top: '20px',
                    right: '20px',
                    bottom: '20px',
                    left: '20px'
                }
            });

            return Buffer.from(pdfBuffer);
        } finally {
            await browser.close();
        }
    }
}
