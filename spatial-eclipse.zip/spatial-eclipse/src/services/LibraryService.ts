import {
    Document, Section, Page, Component,
    LibraryDocument, LibrarySection, LibraryPage, LibraryComponent
} from '../core/entities/domain';
import {
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository,
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository
} from '../core/repositories/interfaces';

export class LibraryService {
    constructor(
        private libDocRepo: ILibraryDocumentRepository,
        private libSectionRepo: ILibrarySectionRepository,
        private libPageRepo: ILibraryPageRepository,
        private libCompRepo: ILibraryComponentRepository,

        private docRepo: IDocumentRepository,
        private sectionRepo: ISectionRepository,
        private pageRepo: IPageRepository,
        private compRepo: IComponentRepository
    ) { }

    async instantiateDocument(libraryId: string): Promise<Document> {
        const template = await this.libDocRepo.findById(libraryId);
        if (!template) throw new Error('Library Document not found');

        return this.docRepo.create({
            title: `${template.name} (Copy)`,
            status: 'DRAFT' as any,
            template: template.template,
            data: JSON.parse(JSON.stringify(template.data)),
            dataPath: template.dataPath,
            globalContext: {},
            metadata: {}
        } as any);
    }

    async instantiateSection(libraryId: string, targetDocId: string): Promise<Section> {
        const template = await this.libSectionRepo.findById(libraryId);
        if (!template) throw new Error('Library Section not found');

        return this.sectionRepo.create({
            documentId: targetDocId,
            orderIndex: 0,
            template: template.template,
            data: JSON.parse(JSON.stringify(template.data)),
            dataPath: template.dataPath,
            pages: []
        } as any);
    }

    async instantiatePage(libraryId: string, targetSectionId: string): Promise<Page> {
        const template = await this.libPageRepo.findById(libraryId);
        if (!template) throw new Error('Library Page not found');

        return this.pageRepo.create({
            sectionId: targetSectionId,
            orderIndex: 0,
            template: template.template,
            data: JSON.parse(JSON.stringify(template.data)),
            dataPath: template.dataPath,
            components: []
        } as any);
    }

    async instantiateComponent(libraryId: string, targetPageId: string): Promise<Component> {
        const template = await this.libCompRepo.findById(libraryId);
        if (!template) throw new Error('Library Component not found');

        return this.compRepo.create({
            pageId: targetPageId,
            componentType: template.componentType,
            template: template.template,
            data: JSON.parse(JSON.stringify(template.data)),
            dataPath: template.dataPath
        } as any);
    }

    async createLibraryComponent(data: Partial<LibraryComponent>): Promise<LibraryComponent> {
        return this.libCompRepo.create(data as any);
    }
}
