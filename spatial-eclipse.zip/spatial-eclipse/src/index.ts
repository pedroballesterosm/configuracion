import fastify, { FastifyInstance } from 'fastify';
import {
    HttpDocumentRepository,
    HttpSectionRepository,
    HttpPageRepository,
    HttpComponentRepository,
    HttpLibraryDocumentRepository,
    HttpLibrarySectionRepository,
    HttpLibraryPageRepository,
    HttpLibraryComponentRepository
} from './infrastructure/http/HttpRepositories';
import {
    StaticDocumentRepository,
    StaticSectionRepository,
    StaticPageRepository,
    StaticComponentRepository,
    StaticLibraryDocumentRepository,
    StaticLibrarySectionRepository,
    StaticLibraryPageRepository,
    StaticLibraryComponentRepository
} from './infrastructure/static/StaticRepositories';
import {
    DatabaseDocumentRepository,
    DatabaseSectionRepository,
    DatabasePageRepository,
    DatabaseComponentRepository,
    DatabaseLibraryDocumentRepository,
    DatabaseLibrarySectionRepository,
    DatabaseLibraryPageRepository,
    DatabaseLibraryComponentRepository
} from './infrastructure/database/DatabaseRepositories';
import { getClient } from './infrastructure/database/db';
import { DocumentService } from './services/DocumentService';
import { LibraryService } from './services/LibraryService';
import { RenderingService } from './services/RenderingService';
import { PdfService } from './services/PdfService';
import {
    IDocumentRepository, ISectionRepository, IPageRepository, IComponentRepository,
    ILibraryDocumentRepository, ILibrarySectionRepository, ILibraryPageRepository, ILibraryComponentRepository
} from './core/repositories/interfaces';

const server: FastifyInstance = fastify({ logger: true });

// REPOSITORY FACTORY
const REPO_TYPE = process.env.REPO_TYPE || 'STATIC'; // Default to STATIC as requested

let docRepo: IDocumentRepository;
let sectionRepo: ISectionRepository;
let pageRepo: IPageRepository;
let compRepo: IComponentRepository;

let libDocRepo: ILibraryDocumentRepository;
let libSectionRepo: ILibrarySectionRepository;
let libPageRepo: ILibraryPageRepository;
let libCompRepo: ILibraryComponentRepository;

if (REPO_TYPE === 'HTTP') {
    server.log.info('Using HTTP Repositories (Java Backend)');
    docRepo = new HttpDocumentRepository();
    sectionRepo = new HttpSectionRepository();
    pageRepo = new HttpPageRepository();
    compRepo = new HttpComponentRepository();

    libDocRepo = new HttpLibraryDocumentRepository();
    libSectionRepo = new HttpLibrarySectionRepository();
    libPageRepo = new HttpLibraryPageRepository();
    libCompRepo = new HttpLibraryComponentRepository();
    libPageRepo = new HttpLibraryPageRepository();
    libCompRepo = new HttpLibraryComponentRepository();
} else if (REPO_TYPE === 'DATABASE') {
    server.log.info('Using DATABASE Repositories (PostgreSQL)');
    docRepo = new DatabaseDocumentRepository();
    sectionRepo = new DatabaseSectionRepository();
    pageRepo = new DatabasePageRepository();
    compRepo = new DatabaseComponentRepository();

    libDocRepo = new DatabaseLibraryDocumentRepository();
    libSectionRepo = new DatabaseLibrarySectionRepository();
    libPageRepo = new DatabaseLibraryPageRepository();
    libCompRepo = new DatabaseLibraryComponentRepository();
} else {
    server.log.info('Using STATIC Repositories (In-Memory)');
    docRepo = new StaticDocumentRepository();
    sectionRepo = new StaticSectionRepository();
    pageRepo = new StaticPageRepository();
    compRepo = new StaticComponentRepository();

    libDocRepo = new StaticLibraryDocumentRepository();
    libSectionRepo = new StaticLibrarySectionRepository();
    libPageRepo = new StaticLibraryPageRepository();
    libCompRepo = new StaticLibraryComponentRepository();
}

const documentService = new DocumentService(
    docRepo,
    sectionRepo,
    pageRepo,
    compRepo
);

const renderingService = new RenderingService(documentService);
const pdfService = new PdfService();

const libraryService = new LibraryService(
    libDocRepo,
    libSectionRepo,
    libPageRepo,
    libCompRepo,
    docRepo,
    sectionRepo,
    pageRepo,
    compRepo
);

// Routes
server.get('/api/health', async () => {
    return { status: 'ok' };
});

// ==========================================
// Document Routes & Rendering
// ==========================================

server.get('/api/documents', async (request, reply) => {
    return documentService.getAllDocuments();
});

server.post('/api/documents', async (request, reply) => {
    const doc = await documentService.createDocument(request.body as any);
    return doc;
});

server.get('/api/documents/:id', async (request, reply) => {
    const { id } = request.params as { id: string };
    const doc = await documentService.getFullDocument(id);
    if (!doc) {
        reply.code(404);
        return { error: 'Document not found' };
    }
    return doc;
});

server.get('/api/documents/:id/render', async (request, reply) => {
    const { id } = request.params as { id: string };
    try {
        const html = await renderingService.renderDocument(id);
        reply.type('text/html');
        return html;
    } catch (err: any) {
        reply.code(500);
        return { error: err.message };
    }
});

server.get('/api/documents/:id/pdf', async (request, reply) => {
    const { id } = request.params as { id: string };
    try {
        // 1. Get Document Data (to check metadata)
        const doc = await documentService.getFullDocument(id);
        if (!doc) {
            reply.code(404);
            return { error: 'Document not found' };
        }

        // 2. Get HTML
        const html = await renderingService.renderDocument(id);

        // 3. Convert to PDF (passing landscape option if present in metadata)
        const isLandscape = doc.metadata && doc.metadata.landscape === true;
        const buffer = await pdfService.generatePdf(html, { landscape: isLandscape });

        // 4. Send Stream
        reply.header('Content-Type', 'application/pdf');
        reply.header('Content-Disposition', `attachment; filename="document-${id}.pdf"`);
        return buffer;
    } catch (err: any) {
        request.log.error(err);
        reply.code(500);
        return { error: err.message };
    }
});

server.post('/api/documents/:id/sections', async (request, reply) => {
    const { id } = request.params as { id: string };
    const section = await documentService.addSection(id, request.body as any);
    return section;
});

server.post('/api/sections/:id/pages', async (request, reply) => {
    const { id } = request.params as { id: string };
    const page = await documentService.addPage(id, request.body as any);
    return page;
});

server.post('/api/pages/:id/components', async (request, reply) => {
    const { id } = request.params as { id: string };
    const component = await documentService.addComponent(id, request.body as any);
    return component;
});

// ==========================================
// Library Routes
// ==========================================

server.post('/api/library/components', async (request, reply) => {
    return libraryService.createLibraryComponent(request.body as any);
});

// Instantiation Routes
server.post('/api/library/instantiate/document/:libId', async (request, reply) => {
    const { libId } = request.params as { libId: string };
    try {
        return await libraryService.instantiateDocument(libId);
    } catch (err: any) {
        reply.code(404);
        return { error: err.message };
    }
});

server.post('/api/library/instantiate/component/:libId', async (request, reply) => {
    const { libId } = request.params as { libId: string };
    const body = request.body as { pageId: string };

    if (!body || !body.pageId) {
        reply.code(400);
        return { error: 'pageId body param is required' };
    }
    try {
        return await libraryService.instantiateComponent(libId, body.pageId);
    } catch (err: any) {
        reply.code(404);
        return { error: err.message };
    }
});

// Start server
const start = async () => {
    try {
        await server.listen({ port: 3000 });
    } catch (err) {
        server.log.error(err);
        process.exit(1);
    }
};

start();
