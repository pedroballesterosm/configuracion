export type UUID = string;

// ==========================================
// Base Interfaces
// ==========================================

export interface BaseEntity {
    id: UUID;
    createdAt: Date;
    updatedAt?: Date;
}

/**
 * Interface common to all renderable elements (Library or Instance)
 */
export interface Renderable {
    template: string; // HTML Handlebars template
    data: Record<string, any>; // Local data context
    dataPath?: string; // Pointer to global data context
}

export enum DocumentStatus {
    DRAFT = 'DRAFT',
    PUBLISHED = 'PUBLISHED',
    ARCHIVED = 'ARCHIVED'
}

// ==========================================
// Domain Entities (Instances)
// ==========================================

export interface Component extends BaseEntity, Renderable {
    pageId: UUID;
    componentType: string; // 'text', 'image', 'chart', etc.

    // Positioning
    x?: number;
    y?: number;
    width?: number;
    height?: number;
    zIndex?: number;
}

export interface Page extends BaseEntity, Renderable {
    sectionId: UUID;
    orderIndex: number;
    width?: number;
    height?: number;

    components: Component[]; // Loaded children
}

export interface Section extends BaseEntity, Renderable {
    documentId: UUID;
    orderIndex: number;

    pages: Page[]; // Loaded children
}

export interface Document extends BaseEntity, Renderable {
    title: string;
    status: DocumentStatus;
    metadata: Record<string, any>;
    globalContext: Record<string, any>; // The big JSON injected

    sections: Section[]; // Loaded children
}

// ==========================================
// Library Entities (Templates)
// ==========================================

export interface LibraryItem extends BaseEntity, Renderable {
    name: string;
    description?: string;
}

export interface LibraryDocument extends LibraryItem { }
export interface LibrarySection extends LibraryItem { }
export interface LibraryPage extends LibraryItem { }
export interface LibraryComponent extends LibraryItem {
    componentType: string;
}
