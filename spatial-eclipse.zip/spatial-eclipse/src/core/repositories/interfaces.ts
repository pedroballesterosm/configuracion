import { Document, Section, Page, Component, LibraryDocument, LibrarySection, LibraryPage, LibraryComponent } from '../entities/domain';

export interface IRepository<T> {
    create(data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<T>;
    findById(id: string): Promise<T | null>;
    update(id: string, data: Partial<T>): Promise<T>;
    delete(id: string): Promise<boolean>;
    findAll(): Promise<T[]>;
}

export interface IDocumentRepository extends IRepository<Document> { }
export interface ISectionRepository extends IRepository<Section> {
    findByDocumentId(docId: string): Promise<Section[]>;
}
export interface IPageRepository extends IRepository<Page> {
    findBySectionId(sectionId: string): Promise<Page[]>;
}
export interface IComponentRepository extends IRepository<Component> {
    findByPageId(pageId: string): Promise<Component[]>;
}

// Library Repositories
export interface ILibraryDocumentRepository extends IRepository<LibraryDocument> { }
export interface ILibrarySectionRepository extends IRepository<LibrarySection> { }
export interface ILibraryPageRepository extends IRepository<LibraryPage> { }
export interface ILibraryComponentRepository extends IRepository<LibraryComponent> { }
