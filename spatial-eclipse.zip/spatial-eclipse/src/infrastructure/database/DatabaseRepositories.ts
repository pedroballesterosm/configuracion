import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository,
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository
} from '../../core/repositories/interfaces';
import {
    Document, Section, Page, Component,
    LibraryDocument, LibrarySection, LibraryPage, LibraryComponent,
    DocumentStatus
} from '../../core/entities/domain';
import { query } from './db';

// --- HELPER TO MAP DB ROWS TO DOMAIN ENTITIES ---

const mapDocument = (row: any): Document => ({
    id: row.id,
    title: row.title,
    status: row.status as DocumentStatus,
    template: row.template,
    data: row.data || {},
    globalContext: row.global_context || {},
    metadata: row.metadata || {},
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    sections: [] // Populated separately if needed usually
});

const mapSection = (row: any): Section => ({
    id: row.id,
    documentId: row.document_id,
    orderIndex: row.order_index,
    template: row.template,
    data: row.data || {},
    createdAt: new Date(), // DB doesn't have created_at for sections in schema provided, defaulting to now
    pages: []
});

const mapPage = (row: any): Page => ({
    id: row.id,
    sectionId: row.section_id,
    orderIndex: row.order_index,
    template: row.template,
    data: row.data || {},
    createdAt: new Date(), // DB doesn't have created_at for pages in schema provided
    components: []
});

const mapComponent = (row: any): Component => ({
    id: row.id,
    pageId: row.page_id,
    orderIndex: 0, // Schema doesn't have order_index for components? Checking schema...
    // Schema has x, y, z_index. Domain has orderIndex. 
    // Wait, let me check the schema provided in 01_init.sql again.
    // 01_init.sql for components: id, page_id, x, y, width, height, z_index, component_type, template, data...
    // Interface Component: id, pageId, componentType, template, data, orderIndex...
    // I should probably map z_index to orderIndex or just 0 if not applicable.
    // Let's assume z_index is used for ordering or just default to 0.
    componentType: row.component_type,
    template: row.template,
    data: row.data || {},
    createdAt: new Date()
});

// Since the schema for components has x, y but domain Component might be list-based (orderIndex),
// we might need to adjust or just map what we have.
// The interface says "orderIndex". The previous static implementation used it.
// I will start by mapping z_index to orderIndex if present, or 0.

// --- REPOSITORIES ---

export class DatabaseDocumentRepository implements IDocumentRepository {
    async create(data: Omit<Document, "id" | "createdAt" | "updatedAt">): Promise<Document> {
        const sql = `
            INSERT INTO documents (title, status, template, data, global_context, metadata)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *;
        `;
        const params = [
            data.title,
            data.status,
            data.template,
            data.data,
            data.globalContext,
            data.metadata
        ];
        const res = await query(sql, params);
        return mapDocument(res.rows[0]);
    }

    async findById(id: string): Promise<Document | null> {
        const res = await query('SELECT * FROM documents WHERE id = $1', [id]);
        if (res.rows.length === 0) return null;
        return mapDocument(res.rows[0]);
    }

    async update(id: string, data: Partial<Document>): Promise<Document> {
        // dynamic update
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.title !== undefined) { fields.push(`title = $${idx++}`); values.push(data.title); }
        if (data.status !== undefined) { fields.push(`status = $${idx++}`); values.push(data.status); }
        if (data.template !== undefined) { fields.push(`template = $${idx++}`); values.push(data.template); }
        if (data.data !== undefined) { fields.push(`data = $${idx++}`); values.push(data.data); }
        if (data.globalContext !== undefined) { fields.push(`global_context = $${idx++}`); values.push(data.globalContext); }
        if (data.metadata !== undefined) { fields.push(`metadata = $${idx++}`); values.push(data.metadata); }

        fields.push(`updated_at = NOW()`);

        if (fields.length === 1) { // only updated_at
            return (await this.findById(id))!;
        }

        const sql = `UPDATE documents SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
        values.push(id);
        const res = await query(sql, values);
        if (res.rows.length === 0) throw new Error("Document not found");
        return mapDocument(res.rows[0]);
    }

    async delete(id: string): Promise<boolean> {
        const res = await query('DELETE FROM documents WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }

    async findAll(): Promise<Document[]> {
        const res = await query('SELECT * FROM documents ORDER BY created_at DESC');
        return res.rows.map(mapDocument);
    }
}

export class DatabaseSectionRepository implements ISectionRepository {
    async create(data: Omit<Section, "id" | "createdAt" | "updatedAt">): Promise<Section> {
        const sql = `
            INSERT INTO sections (document_id, order_index, template, data)
            VALUES ($1, $2, $3, $4)
            RETURNING *;
        `;
        const params = [data.documentId, data.orderIndex, data.template, data.data];
        const res = await query(sql, params);
        return mapSection(res.rows[0]);
    }

    async findById(id: string): Promise<Section | null> {
        const res = await query('SELECT * FROM sections WHERE id = $1', [id]);
        return res.rows[0] ? mapSection(res.rows[0]) : null;
    }

    async update(id: string, data: Partial<Section>): Promise<Section> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.orderIndex !== undefined) { fields.push(`order_index = $${idx++}`); values.push(data.orderIndex); }
        if (data.template !== undefined) { fields.push(`template = $${idx++}`); values.push(data.template); }
        if (data.data !== undefined) { fields.push(`data = $${idx++}`); values.push(data.data); }

        if (fields.length === 0) return (await this.findById(id))!;

        const sql = `UPDATE sections SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
        values.push(id);
        const res = await query(sql, values);
        return mapSection(res.rows[0]);
    }

    async delete(id: string): Promise<boolean> {
        const res = await query('DELETE FROM sections WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }

    async findAll(): Promise<Section[]> {
        const res = await query('SELECT * FROM sections');
        return res.rows.map(mapSection);
    }

    async findByDocumentId(docId: string): Promise<Section[]> {
        const res = await query('SELECT * FROM sections WHERE document_id = $1 ORDER BY order_index ASC', [docId]);
        return res.rows.map(mapSection);
    }
}

export class DatabasePageRepository implements IPageRepository {
    async create(data: Omit<Page, "id" | "createdAt" | "updatedAt">): Promise<Page> {
        const sql = `
            INSERT INTO pages (section_id, order_index, template, data)
            VALUES ($1, $2, $3, $4)
            RETURNING *;
        `;
        const params = [data.sectionId, data.orderIndex, data.template, data.data];
        const res = await query(sql, params);
        return mapPage(res.rows[0]);
    }

    async findById(id: string): Promise<Page | null> {
        const res = await query('SELECT * FROM pages WHERE id = $1', [id]);
        return res.rows[0] ? mapPage(res.rows[0]) : null;
    }

    async update(id: string, data: Partial<Page>): Promise<Page> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;
        if (data.orderIndex !== undefined) { fields.push(`order_index = $${idx++}`); values.push(data.orderIndex); }
        if (data.template !== undefined) { fields.push(`template = $${idx++}`); values.push(data.template); }
        if (data.data !== undefined) { fields.push(`data = $${idx++}`); values.push(data.data); }

        if (fields.length === 0) return (await this.findById(id))!;

        const sql = `UPDATE pages SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
        values.push(id);
        const res = await query(sql, values);
        return mapPage(res.rows[0]);
    }

    async delete(id: string): Promise<boolean> {
        const res = await query('DELETE FROM pages WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }

    async findAll(): Promise<Page[]> {
        const res = await query('SELECT * FROM pages');
        return res.rows.map(mapPage);
    }

    async findBySectionId(sectionId: string): Promise<Page[]> {
        const res = await query('SELECT * FROM pages WHERE section_id = $1 ORDER BY order_index ASC', [sectionId]);
        return res.rows.map(mapPage);
    }
}

export class DatabaseComponentRepository implements IComponentRepository {
    async create(data: Omit<Component, "id" | "createdAt" | "updatedAt">): Promise<Component> {
        // We use z_index as orderIndex for now, or just ignore orderIndex if not in schema.
        // The schema has: page_id, x, y, width, height, z_index, component_type, template, data
        const sql = `
            INSERT INTO components (page_id, component_type, template, data, z_index)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING *;
        `;
        const params = [data.pageId, data.componentType, data.template, data.data, data.orderIndex || 0];
        const res = await query(sql, params);
        return { ...mapComponent(res.rows[0]), orderIndex: res.rows[0].z_index };
    }

    async findById(id: string): Promise<Component | null> {
        const res = await query('SELECT * FROM components WHERE id = $1', [id]);
        if (!res.rows[0]) return null;
        return { ...mapComponent(res.rows[0]), orderIndex: res.rows[0].z_index };
    }

    async update(id: string, data: Partial<Component>): Promise<Component> {
        const fields: string[] = [];
        const values: any[] = [];
        let idx = 1;

        if (data.template !== undefined) { fields.push(`template = $${idx++}`); values.push(data.template); }
        if (data.data !== undefined) { fields.push(`data = $${idx++}`); values.push(data.data); }
        if (data.orderIndex !== undefined) { fields.push(`z_index = $${idx++}`); values.push(data.orderIndex); }

        if (fields.length === 0) return (await this.findById(id))!;

        const sql = `UPDATE components SET ${fields.join(', ')} WHERE id = $${idx} RETURNING *`;
        values.push(id);
        const res = await query(sql, values);
        return { ...mapComponent(res.rows[0]), orderIndex: res.rows[0].z_index };
    }

    async delete(id: string): Promise<boolean> {
        const res = await query('DELETE FROM components WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }

    async findAll(): Promise<Component[]> {
        const res = await query('SELECT * FROM components');
        return res.rows.map(row => ({ ...mapComponent(row), orderIndex: row.z_index }));
    }

    async findByPageId(pageId: string): Promise<Component[]> {
        const res = await query('SELECT * FROM components WHERE page_id = $1 ORDER BY z_index ASC', [pageId]);
        return res.rows.map(row => ({ ...mapComponent(row), orderIndex: row.z_index }));
    }
}

// --- LIBRARY REPOSITORIES (Basic Implementation) ---

export class DatabaseLibraryDocumentRepository implements ILibraryDocumentRepository {
    async create(data: Omit<LibraryDocument, "id" | "createdAt" | "updatedAt">): Promise<LibraryDocument> {
        const res = await query(
            'INSERT INTO library_documents (name, description, template, data) VALUES ($1, $2, $3, $4) RETURNING *',
            [data.name, data.description, data.template, data.data]
        );
        return res.rows[0];
    }
    async findById(id: string): Promise<LibraryDocument | null> {
        const res = await query('SELECT * FROM library_documents WHERE id = $1', [id]);
        return res.rows[0] || null;
    }
    async update(id: string, data: Partial<LibraryDocument>): Promise<LibraryDocument> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<LibraryDocument[]> {
        const res = await query('SELECT * FROM library_documents');
        return res.rows;
    }
}

export class DatabaseLibrarySectionRepository implements ILibrarySectionRepository {
    async create(data: Omit<LibrarySection, "id" | "createdAt" | "updatedAt">): Promise<LibrarySection> {
        const res = await query(
            'INSERT INTO library_sections (name, template, data) VALUES ($1, $2, $3) RETURNING *',
            [data.name, data.template, data.data]
        );
        return res.rows[0];
    }
    async findById(id: string): Promise<LibrarySection | null> {
        const res = await query('SELECT * FROM library_sections WHERE id = $1', [id]);
        return res.rows[0] || null;
    }
    async update(id: string, data: Partial<LibrarySection>): Promise<LibrarySection> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<LibrarySection[]> {
        const res = await query('SELECT * FROM library_sections');
        return res.rows;
    }
}

export class DatabaseLibraryPageRepository implements ILibraryPageRepository {
    async create(data: Omit<LibraryPage, "id" | "createdAt" | "updatedAt">): Promise<LibraryPage> {
        const res = await query(
            'INSERT INTO library_pages (name, template, data) VALUES ($1, $2, $3) RETURNING *',
            [data.name, data.template, data.data]
        );
        return res.rows[0];
    }
    async findById(id: string): Promise<LibraryPage | null> {
        const res = await query('SELECT * FROM library_pages WHERE id = $1', [id]);
        return res.rows[0] || null;
    }
    async update(id: string, data: Partial<LibraryPage>): Promise<LibraryPage> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<LibraryPage[]> {
        const res = await query('SELECT * FROM library_pages');
        return res.rows;
    }
}

export class DatabaseLibraryComponentRepository implements ILibraryComponentRepository {
    async create(data: Omit<LibraryComponent, "id" | "createdAt" | "updatedAt">): Promise<LibraryComponent> {
        const res = await query(
            'INSERT INTO library_components (name, component_type, template, data) VALUES ($1, $2, $3, $4) RETURNING *',
            [data.name, data.componentType, data.template, data.data]
        );
        return res.rows[0]; // Need to map camelCase if needed, but keeping simple for now
    }
    async findById(id: string): Promise<LibraryComponent | null> {
        const res = await query('SELECT * FROM library_components WHERE id = $1', [id]);
        // Map properties back
        if (!res.rows[0]) return null;
        const r = res.rows[0];
        return { ...r, componentType: r.component_type };
    }
    async update(id: string, data: Partial<LibraryComponent>): Promise<LibraryComponent> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<LibraryComponent[]> {
        const res = await query('SELECT * FROM library_components');
        return res.rows.map(r => ({ ...r, componentType: r.component_type }));
    }
}
