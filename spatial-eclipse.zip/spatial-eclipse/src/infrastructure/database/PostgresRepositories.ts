import { Pool } from 'pg';
import {
    Document, Section, Page, Component,
    LibraryDocument, LibrarySection, LibraryPage, LibraryComponent
} from '../../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository,
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository
} from '../../core/repositories/interfaces';

// DB Configuration
const pool = new Pool({
    connectionString: 'postgresql://admin:password@localhost:5432/document_engine'
});

// Helper to map snake_case DB fields to camelCase entities
const mapDoc = (row: any): Document => ({
    id: row.id,
    title: row.title,
    status: row.status,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    globalContext: row.global_context,
    metadata: row.metadata,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    sections: []
});

const mapSection = (row: any): Section => ({
    id: row.id,
    documentId: row.document_id,
    orderIndex: row.order_index,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at,
    pages: []
});

const mapPage = (row: any): Page => ({
    id: row.id,
    sectionId: row.section_id,
    orderIndex: row.order_index,
    width: row.width,
    height: row.height,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at,
    components: []
});

const mapComponent = (row: any): Component => ({
    id: row.id,
    pageId: row.page_id,
    x: row.x,
    y: row.y,
    width: row.width,
    height: row.height,
    zIndex: row.z_index,
    componentType: row.component_type,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at
});

// =====================================
// Repository Implementations
// =====================================

export class PgDocumentRepository implements IDocumentRepository {
    async create(data: Omit<Document, "id" | "createdAt" | "updatedAt">): Promise<Document> {
        const res = await pool.query(
            `INSERT INTO documents (title, status, template, data, data_path, global_context, metadata) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
            [data.title, data.status, data.template, data.data, data.dataPath, data.globalContext, data.metadata]
        );
        return mapDoc(res.rows[0]);
    }

    async findById(id: string): Promise<Document | null> {
        const res = await pool.query('SELECT * FROM documents WHERE id = $1', [id]);
        return res.rows.length ? mapDoc(res.rows[0]) : null;
    }

    async update(id: string, data: Partial<Document>): Promise<Document> {
        // Simplified update (full dynamic update would require building query string)
        // For now assuming we mostly update title/status or data
        // TODO: Implement proper dynamic update builder
        throw new Error("Method not fully implemented in demo");
    }

    async delete(id: string): Promise<boolean> {
        const res = await pool.query('DELETE FROM documents WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }

    async findAll(): Promise<Document[]> {
        const res = await pool.query('SELECT * FROM documents ORDER BY created_at DESC');
        return res.rows.map(mapDoc);
    }
}

export class PgSectionRepository implements ISectionRepository {
    async create(data: Omit<Section, "id" | "createdAt" | "updatedAt">): Promise<Section> {
        const res = await pool.query(
            `INSERT INTO sections (document_id, order_index, template, data, data_path) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [data.documentId, data.orderIndex, data.template, data.data, data.dataPath]
        );
        return mapSection(res.rows[0]);
    }

    async findById(id: string): Promise<Section | null> {
        const res = await pool.query('SELECT * FROM sections WHERE id = $1', [id]);
        return res.rows.length ? mapSection(res.rows[0]) : null;
    }
    async update(id: string, data: Partial<Section>): Promise<Section> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<Section[]> { throw new Error("Method not implemented."); }

    async findByDocumentId(docId: string): Promise<Section[]> {
        const res = await pool.query('SELECT * FROM sections WHERE document_id = $1 ORDER BY order_index ASC', [docId]);
        return res.rows.map(mapSection);
    }
}

export class PgPageRepository implements IPageRepository {
    async create(data: Omit<Page, "id" | "createdAt" | "updatedAt">): Promise<Page> {
        const res = await pool.query(
            `INSERT INTO pages (section_id, order_index, width, height, template, data, data_path) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING *`,
            [data.sectionId, data.orderIndex, data.width || 0, data.height || 0, data.template, data.data, data.dataPath]
        );
        return mapPage(res.rows[0]);
    }

    async findById(id: string): Promise<Page | null> {
        const res = await pool.query('SELECT * FROM pages WHERE id = $1', [id]);
        return res.rows.length ? mapPage(res.rows[0]) : null;
    }
    async update(id: string, data: Partial<Page>): Promise<Page> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<Page[]> { throw new Error("Method not implemented."); }

    async findBySectionId(sectionId: string): Promise<Page[]> {
        const res = await pool.query('SELECT * FROM pages WHERE section_id = $1 ORDER BY order_index ASC', [sectionId]);
        return res.rows.map(mapPage);
    }
}

export class PgComponentRepository implements IComponentRepository {
    async create(data: Omit<Component, "id" | "createdAt" | "updatedAt">): Promise<Component> {
        const res = await pool.query(
            `INSERT INTO components (page_id, x, y, width, height, z_index, component_type, template, data, data_path) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
            [data.pageId, data.x, data.y, data.width, data.height, data.zIndex, data.componentType, data.template, data.data, data.dataPath]
        );
        return mapComponent(res.rows[0]);
    }

    async findById(id: string): Promise<Component | null> {
        const res = await pool.query('SELECT * FROM components WHERE id = $1', [id]);
        return res.rows.length ? mapComponent(res.rows[0]) : null;
    }
    async update(id: string, data: Partial<Component>): Promise<Component> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented."); }
    async findAll(): Promise<Component[]> { throw new Error("Method not implemented."); }

    async findByPageId(pageId: string): Promise<Component[]> {
        const res = await pool.query('SELECT * FROM components WHERE page_id = $1', [pageId]);
        return res.rows.map(mapComponent);
    }
}

// =====================================
// Library Mappers
// =====================================

const mapLibDoc = (row: any): LibraryDocument => ({
    id: row.id,
    name: row.name,
    description: row.description,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at,
    updatedAt: row.updated_at
});

const mapLibSection = (row: any): LibrarySection => ({
    id: row.id,
    name: row.name,
    description: row.description,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at
});

const mapLibPage = (row: any): LibraryPage => ({
    id: row.id,
    name: row.name,
    description: row.description, // Although domain might not currently expose description on all, DB has it or BaseEntity-like structure
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at
});

const mapLibComponent = (row: any): LibraryComponent => ({
    id: row.id,
    name: row.name,
    description: row.description,
    componentType: row.component_type,
    template: row.template,
    data: row.data,
    dataPath: row.data_path,
    createdAt: row.created_at
});

// =====================================
// Library Repositories Implementation
// =====================================

export class PgLibraryDocumentRepository implements ILibraryDocumentRepository {
    async create(data: Omit<LibraryDocument, "id" | "createdAt" | "updatedAt">): Promise<LibraryDocument> {
        const res = await pool.query(
            `INSERT INTO library_documents (name, description, template, data, data_path) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [data.name, data.description, data.template, data.data, data.dataPath]
        );
        return mapLibDoc(res.rows[0]);
    }

    async findById(id: string): Promise<LibraryDocument | null> {
        const res = await pool.query('SELECT * FROM library_documents WHERE id = $1', [id]);
        return res.rows.length ? mapLibDoc(res.rows[0]) : null;
    }

    async findAll(): Promise<LibraryDocument[]> {
        const res = await pool.query('SELECT * FROM library_documents ORDER BY created_at DESC');
        return res.rows.map(mapLibDoc);
    }

    async update(id: string, data: Partial<LibraryDocument>): Promise<LibraryDocument> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> {
        const res = await pool.query('DELETE FROM library_documents WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }
}

export class PgLibrarySectionRepository implements ILibrarySectionRepository {
    async create(data: Omit<LibrarySection, "id" | "createdAt" | "updatedAt">): Promise<LibrarySection> {
        const res = await pool.query(
            `INSERT INTO library_sections (name, template, data, data_path) 
       VALUES ($1, $2, $3, $4) RETURNING *`,
            [data.name, data.template, data.data, data.dataPath]
        );
        return mapLibSection(res.rows[0]);
    }

    async findById(id: string): Promise<LibrarySection | null> {
        const res = await pool.query('SELECT * FROM library_sections WHERE id = $1', [id]);
        return res.rows.length ? mapLibSection(res.rows[0]) : null;
    }

    async findAll(): Promise<LibrarySection[]> {
        const res = await pool.query('SELECT * FROM library_sections ORDER BY created_at DESC');
        return res.rows.map(mapLibSection);
    }
    async update(id: string, data: Partial<LibrarySection>): Promise<LibrarySection> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> {
        const res = await pool.query('DELETE FROM library_sections WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }
}

export class PgLibraryPageRepository implements ILibraryPageRepository {
    async create(data: Omit<LibraryPage, "id" | "createdAt" | "updatedAt">): Promise<LibraryPage> {
        const res = await pool.query(
            `INSERT INTO library_pages (name, template, data, data_path) 
       VALUES ($1, $2, $3, $4) RETURNING *`,
            [data.name, data.template, data.data, data.dataPath]
        );
        return mapLibPage(res.rows[0]);
    }

    async findById(id: string): Promise<LibraryPage | null> {
        const res = await pool.query('SELECT * FROM library_pages WHERE id = $1', [id]);
        return res.rows.length ? mapLibPage(res.rows[0]) : null;
    }

    async findAll(): Promise<LibraryPage[]> {
        const res = await pool.query('SELECT * FROM library_pages ORDER BY created_at DESC');
        return res.rows.map(mapLibPage);
    }
    async update(id: string, data: Partial<LibraryPage>): Promise<LibraryPage> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> {
        const res = await pool.query('DELETE FROM library_pages WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }
}

export class PgLibraryComponentRepository implements ILibraryComponentRepository {
    async create(data: Omit<LibraryComponent, "id" | "createdAt" | "updatedAt">): Promise<LibraryComponent> {
        const res = await pool.query(
            `INSERT INTO library_components (name, component_type, template, data, data_path) 
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
            [data.name, data.componentType, data.template, data.data, data.dataPath]
        );
        return mapLibComponent(res.rows[0]);
    }

    async findById(id: string): Promise<LibraryComponent | null> {
        const res = await pool.query('SELECT * FROM library_components WHERE id = $1', [id]);
        return res.rows.length ? mapLibComponent(res.rows[0]) : null;
    }

    async findAll(): Promise<LibraryComponent[]> {
        const res = await pool.query('SELECT * FROM library_components ORDER BY created_at DESC');
        return res.rows.map(mapLibComponent);
    }
    async update(id: string, data: Partial<LibraryComponent>): Promise<LibraryComponent> { throw new Error("Method not implemented."); }
    async delete(id: string): Promise<boolean> {
        const res = await pool.query('DELETE FROM library_components WHERE id = $1', [id]);
        return (res.rowCount || 0) > 0;
    }
}
