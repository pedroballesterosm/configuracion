import { promises as fs } from 'fs';
import * as path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { BaseEntity } from '../../core/entities/domain';
import { IRepository } from '../../core/repositories/interfaces';

export abstract class FileSystemRepository<T extends BaseEntity> implements IRepository<T> {
    protected filePath: string;
    protected data: T[] = [];
    protected initialized: boolean = false;

    constructor(entityName: string) {
        const dataDir = path.join(process.cwd(), 'data');
        this.filePath = path.join(dataDir, `${entityName}.json`);
        this.ensureDir(dataDir);
    }

    private async ensureDir(dir: string) {
        try {
            await fs.access(dir);
        } catch {
            await fs.mkdir(dir, { recursive: true });
        }
    }

    protected async load(): Promise<void> {
        if (this.initialized) return;
        try {
            const content = await fs.readFile(this.filePath, 'utf-8');
            this.data = JSON.parse(content);
        } catch (error) {
            // If file doesn't exist, assume empty array
            this.data = [];
        }
        this.initialized = true;
    }

    protected async save(): Promise<void> {
        await fs.writeFile(this.filePath, JSON.stringify(this.data, null, 2));
    }

    async findAll(): Promise<T[]> {
        await this.load();
        return [...this.data];
    }

    async findById(id: string): Promise<T | null> {
        await this.load();
        return this.data.find(item => item.id === id) || null;
    }

    async create(itemData: Omit<T, 'id' | 'createdAt' | 'updatedAt'>): Promise<T> {
        await this.load();
        const newItem = {
            ...itemData,
            id: uuidv4(),
            createdAt: new Date(),
            updatedAt: new Date()
        } as unknown as T; // Type cast needed because we are constructing the full object

        this.data.push(newItem);
        await this.save();
        return newItem;
    }

    async update(id: string, updates: Partial<T>): Promise<T> {
        await this.load();
        const index = this.data.findIndex(item => item.id === id);
        if (index === -1) throw new Error(`Entity with id ${id} not found`);

        const currentItem = this.data[index];
        const updatedItem = {
            ...currentItem,
            ...updates,
            updatedAt: new Date()
        };

        this.data[index] = updatedItem;
        await this.save();
        return updatedItem;
    }

    async delete(id: string): Promise<boolean> {
        await this.load();
        const index = this.data.findIndex(item => item.id === id);
        if (index === -1) return false;

        this.data.splice(index, 1);
        await this.save();
        return true;
    }
}
