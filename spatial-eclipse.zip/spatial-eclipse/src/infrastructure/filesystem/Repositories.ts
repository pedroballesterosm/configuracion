import { Document, Section, Page, Component } from '../../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository
} from '../../core/repositories/interfaces';
import { FileSystemRepository } from './BaseFileSystemRepository';

export class FsDocumentRepository extends FileSystemRepository<Document> implements IDocumentRepository {
    constructor() {
        super('documents');
    }
}

export class FsSectionRepository extends FileSystemRepository<Section> implements ISectionRepository {
    constructor() {
        super('sections');
    }

    async findByDocumentId(docId: string): Promise<Section[]> {
        await this.load();
        return this.data.filter(section => section.documentId === docId)
            .sort((a, b) => a.orderIndex - b.orderIndex);
    }
}

export class FsPageRepository extends FileSystemRepository<Page> implements IPageRepository {
    constructor() {
        super('pages');
    }

    async findBySectionId(sectionId: string): Promise<Page[]> {
        await this.load();
        return this.data.filter(page => page.sectionId === sectionId)
            .sort((a, b) => a.orderIndex - b.orderIndex);
    }
}

export class FsComponentRepository extends FileSystemRepository<Component> implements IComponentRepository {
    constructor() {
        super('components');
    }

    async findByPageId(pageId: string): Promise<Component[]> {
        await this.load();
        return this.data.filter(component => component.pageId === pageId);
        // TODO: Sort by zIndex or visual order if needed
    }
}
