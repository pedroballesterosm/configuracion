import { LibraryDocument, LibrarySection, LibraryPage, LibraryComponent } from '../../core/entities/domain';
import {
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository
} from '../../core/repositories/interfaces';
import { FileSystemRepository } from './BaseFileSystemRepository';

export class FsLibraryDocumentRepository extends FileSystemRepository<LibraryDocument> implements ILibraryDocumentRepository {
    constructor() {
        super('library_documents');
    }
}

export class FsLibrarySectionRepository extends FileSystemRepository<LibrarySection> implements ILibrarySectionRepository {
    constructor() {
        super('library_sections');
    }
}

export class FsLibraryPageRepository extends FileSystemRepository<LibraryPage> implements ILibraryPageRepository {
    constructor() {
        super('library_pages');
    }
}

export class FsLibraryComponentRepository extends FileSystemRepository<LibraryComponent> implements ILibraryComponentRepository {
    constructor() {
        super('library_components');
    }
}
