import axios, { AxiosInstance } from 'axios';
import {
    Document, Section, Page, Component,
    LibraryDocument, LibrarySection, LibraryPage, LibraryComponent,
    DocumentStatus
} from '../../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository,
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository
} from '../../core/repositories/interfaces';

const API_URL = process.env.JAVA_API_URL || 'http://localhost:8080/api';

const client: AxiosInstance = axios.create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});

// Helper to parse JSON strings from Java entities
const parseJavaEntity = <T>(entity: any): T => {
    const parsed = { ...entity };
    if (typeof parsed.data === 'string') {
        try { parsed.data = JSON.parse(parsed.data); } catch (e) { parsed.data = {}; }
    }
    if (typeof parsed.metadata === 'string') {
        try { parsed.metadata = JSON.parse(parsed.metadata); } catch (e) { parsed.metadata = {}; }
    }
    if (typeof parsed.globalContext === 'string') {
        try { parsed.globalContext = JSON.parse(parsed.globalContext); } catch (e) { parsed.globalContext = {}; }
    }
    if (typeof parsed.template === 'string') {
        // Template is usually just a string (HTML), but check if it got double encoded?
        // Usually template is just text, so we leave it.
    }
    // Dates
    if (parsed.createdAt) parsed.createdAt = new Date(parsed.createdAt);
    if (parsed.updatedAt) parsed.updatedAt = new Date(parsed.updatedAt);

    // Arrays - Java might return null for empty lists
    if (!parsed.sections) parsed.sections = [];
    if (!parsed.pages) parsed.pages = [];
    if (!parsed.components) parsed.components = [];

    return parsed as T;
};

// Helper to stringify objects for Java entities
const prepareForJava = (data: any): any => {
    const prepared = { ...data };
    if (prepared.data && typeof prepared.data !== 'string') {
        prepared.data = JSON.stringify(prepared.data);
    }
    if (prepared.metadata && typeof prepared.metadata !== 'string') {
        prepared.metadata = JSON.stringify(prepared.metadata);
    }
    if (prepared.globalContext && typeof prepared.globalContext !== 'string') {
        prepared.globalContext = JSON.stringify(prepared.globalContext);
    }
    return prepared;
};

export class HttpDocumentRepository implements IDocumentRepository {
    async create(data: Omit<Document, "id" | "createdAt" | "updatedAt">): Promise<Document> {
        const payload = prepareForJava(data);
        const res = await client.post('/documents', payload);
        return parseJavaEntity<Document>(res.data);
    }

    async findById(id: string): Promise<Document | null> {
        try {
            const res = await client.get(`/documents/${id}`);
            return parseJavaEntity<Document>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async update(id: string, data: Partial<Document>): Promise<Document> {
        // Java side usually expects full object for "save", or we need a PATCH endpoint.
        // The Java controller has createDocument (POST). It doesn't seem to have explicit update (PUT/PATCH).
        // Standard Spring Data "save" updates if ID exists.
        // So we need to fetch, merge, and save.
        // OR, if the user implemented a PUT, we'd use that.
        // The plan didn't specify changing Java controller to support PATCH. 
        // I'll assume I can just POST to /documents with the ID included to update?
        // Java Controller: createDocument(@RequestBody Document document) -> service.save(document).
        // If I send ID, it updates.

        // But `data` here is Partial. So I definitely need to fetch first if I want to be safe, 
        // or just send the Partial with ID and hope Java side uses dynamic update (it won't, it will nullify missing fields if not careful).
        // Spring Data JPA `save` overwrites the entity.
        // So I MUST fetch first.
        const existing = await this.findById(id);
        if (!existing) throw new Error(`Document ${id} not found`);

        const merged = { ...existing, ...data };
        const payload = prepareForJava(merged);
        // Note: Payload MUST include the ID for it to be an update.
        // existing already has ID.

        const res = await client.post('/documents', payload);
        return parseJavaEntity<Document>(res.data);
    }

    async delete(id: string): Promise<boolean> {
        await client.delete(`/documents/${id}`);
        return true;
    }

    async findAll(): Promise<Document[]> {
        const res = await client.get('/documents');
        return res.data.map((d: any) => parseJavaEntity<Document>(d));
    }
}

export class HttpSectionRepository implements ISectionRepository {
    async create(data: Omit<Section, "id" | "createdAt" | "updatedAt">): Promise<Section> {
        const payload = prepareForJava(data);
        // URL: /documents/{documentId}/sections
        const res = await client.post(`/documents/${data.documentId}/sections`, payload);
        return parseJavaEntity<Section>(res.data);
    }

    async findById(id: string): Promise<Section | null> {
        try {
            const res = await client.get(`/sections/${id}`);
            return parseJavaEntity<Section>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async update(id: string, data: Partial<Section>): Promise<Section> {
        // Same logic as Document
        const existing = await this.findById(id);
        if (!existing) throw new Error(`Section ${id} not found`);
        const merged = { ...existing, ...data };
        const payload = prepareForJava(merged);
        // Java SectionController createSection is: POST /documents/{docId}/sections
        // But that might create a NEW one if ID is not handled correctly or if it forces new UUID.
        // Wait, SectionController:
        // createSection(@PathVariable UUID documentId, @RequestBody Section section) -> service.createSection(documentId, section)

        // If I want to update, I might need a general SAVE endpoint or use the create endpoint if it handles ID.
        // Usually `save` handles ID.
        // But the URL structure implies "add to collection".
        // Let's check SectionController again... 
        // It has `getSectionById` (GET /sections/{id}).
        // It does NOT have a top level PUT/POST /sections for arbitrary update.
        // It only has create via parent.

        // Assuming for now I can't easily update without a specific endpoint. 
        // I'll throw error for now or implement a workaround if critical.
        // The Postgres repo threw Error("Method not implemented") too.
        throw new Error("Method not implemented in HTTP repo (Backend limitation)");
    }

    async delete(id: string): Promise<boolean> {
        // Controller doesn't have delete for Section? 
        // checking...
        // SectionController only has create and get.
        throw new Error("Method not implemented in HTTP repo (Backend limitation)");
    }

    async findAll(): Promise<Section[]> {
        throw new Error("Method not implemented (No getAll sections endpoint)");
    }

    async findByDocumentId(docId: string): Promise<Section[]> {
        const res = await client.get(`/documents/${docId}/sections`);
        return res.data.map((s: any) => parseJavaEntity<Section>(s));
    }
}

export class HttpPageRepository implements IPageRepository {
    async create(data: Omit<Page, "id" | "createdAt" | "updatedAt">): Promise<Page> {
        const payload = prepareForJava(data);
        const res = await client.post(`/sections/${data.sectionId}/pages`, payload);
        return parseJavaEntity<Page>(res.data);
    }

    async findById(id: string): Promise<Page | null> {
        try {
            const res = await client.get(`/pages/${id}`);
            return parseJavaEntity<Page>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async update(id: string, data: Partial<Page>): Promise<Page> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented"); }
    async findAll(): Promise<Page[]> { throw new Error("Method not implemented"); }

    async findBySectionId(sectionId: string): Promise<Page[]> {
        const res = await client.get(`/sections/${sectionId}/pages`);
        return res.data.map((p: any) => parseJavaEntity<Page>(p));
    }
}

export class HttpComponentRepository implements IComponentRepository {
    async create(data: Omit<Component, "id" | "createdAt" | "updatedAt">): Promise<Component> {
        const payload = prepareForJava(data);
        const res = await client.post(`/pages/${data.pageId}/components`, payload);
        return parseJavaEntity<Component>(res.data);
    }

    async findById(id: string): Promise<Component | null> {
        try {
            const res = await client.get(`/components/${id}`);
            return parseJavaEntity<Component>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async update(id: string, data: Partial<Component>): Promise<Component> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> { throw new Error("Method not implemented"); }
    async findAll(): Promise<Component[]> { throw new Error("Method not implemented"); }

    async findByPageId(pageId: string): Promise<Component[]> {
        const res = await client.get(`/pages/${pageId}/components`);
        return res.data.map((c: any) => parseJavaEntity<Component>(c));
    }
}

// =====================================
// Library Repositories
// =====================================

export class HttpLibraryDocumentRepository implements ILibraryDocumentRepository {
    async create(data: Omit<LibraryDocument, "id" | "createdAt" | "updatedAt">): Promise<LibraryDocument> {
        const payload = prepareForJava(data);
        const res = await client.post('/library/documents', payload);
        return parseJavaEntity<LibraryDocument>(res.data);
    }

    async findById(id: string): Promise<LibraryDocument | null> {
        try {
            const res = await client.get(`/library/documents/${id}`);
            return parseJavaEntity<LibraryDocument>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async findAll(): Promise<LibraryDocument[]> {
        const res = await client.get('/library/documents');
        return res.data.map((d: any) => parseJavaEntity<LibraryDocument>(d));
    }

    async update(id: string, data: Partial<LibraryDocument>): Promise<LibraryDocument> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> {
        await client.delete(`/library/documents/${id}`);
        return true;
    }
}

export class HttpLibrarySectionRepository implements ILibrarySectionRepository {
    async create(data: Omit<LibrarySection, "id" | "createdAt" | "updatedAt">): Promise<LibrarySection> {
        const payload = prepareForJava(data);
        const res = await client.post('/library/sections', payload);
        return parseJavaEntity<LibrarySection>(res.data);
    }

    async findById(id: string): Promise<LibrarySection | null> {
        try {
            const res = await client.get(`/library/sections/${id}`);
            return parseJavaEntity<LibrarySection>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async findAll(): Promise<LibrarySection[]> {
        const res = await client.get('/library/sections');
        return res.data.map((d: any) => parseJavaEntity<LibrarySection>(d));
    }

    async update(id: string, data: Partial<LibrarySection>): Promise<LibrarySection> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> {
        await client.delete(`/library/sections/${id}`);
        return true;
    }
}

export class HttpLibraryPageRepository implements ILibraryPageRepository {
    async create(data: Omit<LibraryPage, "id" | "createdAt" | "updatedAt">): Promise<LibraryPage> {
        const payload = prepareForJava(data);
        const res = await client.post('/library/pages', payload);
        return parseJavaEntity<LibraryPage>(res.data);
    }

    async findById(id: string): Promise<LibraryPage | null> {
        try {
            const res = await client.get(`/library/pages/${id}`);
            return parseJavaEntity<LibraryPage>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async findAll(): Promise<LibraryPage[]> {
        const res = await client.get('/library/pages');
        return res.data.map((d: any) => parseJavaEntity<LibraryPage>(d));
    }

    async update(id: string, data: Partial<LibraryPage>): Promise<LibraryPage> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> {
        await client.delete(`/library/pages/${id}`);
        return true;
    }
}

export class HttpLibraryComponentRepository implements ILibraryComponentRepository {
    async create(data: Omit<LibraryComponent, "id" | "createdAt" | "updatedAt">): Promise<LibraryComponent> {
        const payload = prepareForJava(data);
        const res = await client.post('/library/components', payload);
        return parseJavaEntity<LibraryComponent>(res.data);
    }

    async findById(id: string): Promise<LibraryComponent | null> {
        try {
            const res = await client.get(`/library/components/${id}`);
            return parseJavaEntity<LibraryComponent>(res.data);
        } catch (error: any) {
            if (error.response?.status === 404) return null;
            throw error;
        }
    }

    async findAll(): Promise<LibraryComponent[]> {
        const res = await client.get('/library/components');
        return res.data.map((d: any) => parseJavaEntity<LibraryComponent>(d));
    }

    async update(id: string, data: Partial<LibraryComponent>): Promise<LibraryComponent> { throw new Error("Method not implemented"); }
    async delete(id: string): Promise<boolean> {
        await client.delete(`/library/components/${id}`);
        return true;
    }
}
