import { v4 as uuidv4 } from 'uuid';
import {
    Document, Section, Page, Component,
    LibraryDocument, LibrarySection, LibraryPage, LibraryComponent
} from '../../core/entities/domain';
import {
    IDocumentRepository,
    ISectionRepository,
    IPageRepository,
    IComponentRepository,
    ILibraryDocumentRepository,
    ILibrarySectionRepository,
    ILibraryPageRepository,
    ILibraryComponentRepository
} from '../../core/repositories/interfaces';

import { db } from './StaticData';

// --- DATA FROM SCRIPT (Now in StaticData.ts) ---

// REPOSITORIES

export class StaticDocumentRepository implements IDocumentRepository {
    async create(data: Omit<Document, "id" | "createdAt" | "updatedAt">): Promise<Document> {
        const doc = { ...data, id: uuidv4(), createdAt: new Date(), updatedAt: new Date(), sections: [] } as Document;
        db.documents.push(doc);
        return doc;
    }
    async findById(id: string): Promise<Document | null> {
        const doc = db.documents.find(d => d.id === id);
        return doc || null;
    }
    async update(id: string, data: Partial<Document>): Promise<Document> {
        const doc = await this.findById(id);
        if (!doc) throw new Error("Document not found");
        Object.assign(doc, data);
        doc.updatedAt = new Date();
        return doc;
    }
    async delete(id: string): Promise<boolean> {
        const index = db.documents.findIndex(d => d.id === id);
        if (index > -1) {
            db.documents.splice(index, 1);
            return true;
        }
        return false;
    }
    async findAll(): Promise<Document[]> {
        return db.documents;
    }
}

export class StaticSectionRepository implements ISectionRepository {
    async create(data: Omit<Section, "id" | "createdAt" | "updatedAt">): Promise<Section> {
        const section = { ...data, id: uuidv4(), createdAt: new Date(), pages: [] } as Section;
        db.sections.push(section);
        return section;
    }
    async findById(id: string): Promise<Section | null> {
        return db.sections.find(s => s.id === id) || null;
    }
    async update(id: string, data: Partial<Section>): Promise<Section> {
        const s = await this.findById(id);
        if (!s) throw new Error("Section not found");
        Object.assign(s, data);
        return s;
    }
    async delete(id: string): Promise<boolean> {
        const idx = db.sections.findIndex(s => s.id === id);
        if (idx > -1) { db.sections.splice(idx, 1); return true; }
        return false;
    }
    async findAll(): Promise<Section[]> { return db.sections; }

    async findByDocumentId(docId: string): Promise<Section[]> {
        return db.sections.filter(s => s.documentId === docId).sort((a, b) => a.orderIndex - b.orderIndex);
    }
}

export class StaticPageRepository implements IPageRepository {
    async create(data: Omit<Page, "id" | "createdAt" | "updatedAt">): Promise<Page> {
        const page = { ...data, id: uuidv4(), createdAt: new Date(), components: [] } as Page;
        db.pages.push(page);
        return page;
    }
    async findById(id: string): Promise<Page | null> {
        return db.pages.find(p => p.id === id) || null;
    }
    async update(id: string, data: Partial<Page>): Promise<Page> {
        const p = await this.findById(id);
        if (!p) throw new Error("Page not found");
        Object.assign(p, data);
        return p;
    }
    async delete(id: string): Promise<boolean> {
        const idx = db.pages.findIndex(p => p.id === id);
        if (idx > -1) { db.pages.splice(idx, 1); return true; }
        return false;
    }
    async findAll(): Promise<Page[]> { return db.pages; }

    async findBySectionId(sectionId: string): Promise<Page[]> {
        return db.pages.filter(p => p.sectionId === sectionId).sort((a, b) => a.orderIndex - b.orderIndex);
    }
}

export class StaticComponentRepository implements IComponentRepository {
    async create(data: Omit<Component, "id" | "createdAt" | "updatedAt">): Promise<Component> {
        const comp = { ...data, id: uuidv4(), createdAt: new Date() } as Component;
        db.components.push(comp);
        return comp;
    }
    async findById(id: string): Promise<Component | null> {
        return db.components.find(c => c.id === id) || null;
    }
    async update(id: string, data: Partial<Component>): Promise<Component> {
        const c = await this.findById(id);
        if (!c) throw new Error("Component not found");
        Object.assign(c, data);
        return c;
    }
    async delete(id: string): Promise<boolean> {
        const idx = db.components.findIndex(c => c.id === id);
        if (idx > -1) { db.components.splice(idx, 1); return true; }
        return false;
    }
    async findAll(): Promise<Component[]> { return db.components; }

    async findByPageId(pageId: string): Promise<Component[]> {
        return db.components.filter(c => c.pageId === pageId).sort((a, b) => (a.orderIndex || 0) - (b.orderIndex || 0));
    }
}

// LIBRARY REPOSITORIES (Mocked for now)
export class StaticLibraryDocumentRepository implements ILibraryDocumentRepository {
    async create(data: Omit<LibraryDocument, "id" | "createdAt">): Promise<LibraryDocument> {
        throw new Error("Method not implemented.");
    }
    async findById(id: string): Promise<LibraryDocument | null> {
        return null; // Mock
    }
    async findAll(): Promise<LibraryDocument[]> {
        return [];
    }
    async update(id: string, data: Partial<LibraryDocument>): Promise<LibraryDocument> {
        throw new Error("Method not implemented.");
    }
    async delete(id: string): Promise<boolean> {
        return false;
    }
}

export class StaticLibrarySectionRepository implements ILibrarySectionRepository {
    async create(data: Omit<LibrarySection, "id" | "createdAt">): Promise<LibrarySection> {
        throw new Error("Method not implemented.");
    }
    async findById(id: string): Promise<LibrarySection | null> { return null; }
    async findAll(): Promise<LibrarySection[]> { return []; }
    async update(id: string, data: Partial<LibrarySection>): Promise<LibrarySection> {
        throw new Error("Method not implemented.");
    }
    async delete(id: string): Promise<boolean> {
        return false;
    }
}

export class StaticLibraryPageRepository implements ILibraryPageRepository {
    async create(data: Omit<LibraryPage, "id" | "createdAt">): Promise<LibraryPage> {
        throw new Error("Method not implemented.");
    }
    async findById(id: string): Promise<LibraryPage | null> { return null; }
    async findAll(): Promise<LibraryPage[]> { return []; }
    async update(id: string, data: Partial<LibraryPage>): Promise<LibraryPage> {
        throw new Error("Method not implemented.");
    }
    async delete(id: string): Promise<boolean> {
        return false;
    }
}

export class StaticLibraryComponentRepository implements ILibraryComponentRepository {
    async create(data: Omit<LibraryComponent, "id" | "createdAt">): Promise<LibraryComponent> {
        throw new Error("Method not implemented.");
    }
    async findById(id: string): Promise<LibraryComponent | null> { return null; }
    async findAll(): Promise<LibraryComponent[]> { return []; }
    async update(id: string, data: Partial<LibraryComponent>): Promise<LibraryComponent> {
        throw new Error("Method not implemented.");
    }
    async delete(id: string): Promise<boolean> {
        return false;
    }
}
