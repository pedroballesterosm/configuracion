-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ENUMS
CREATE TYPE document_status AS ENUM ('DRAFT', 'PUBLISHED', 'ARCHIVED');

-- ==========================================
-- LIBRARY TABLES (Templates / Masters)
-- ==========================================

CREATE TABLE library_documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT,
    template TEXT, -- Global layout template
    data JSONB DEFAULT '{}', -- Default data
    data_path TEXT, -- Default data path recommendation
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE library_sections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE library_pages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE library_components (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    component_type TEXT NOT NULL, -- e.g., 'text', 'image', 'chart'
    template TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ==========================================
-- INSTANCE TABLES (Live Documents)
-- ==========================================

CREATE TABLE documents (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title TEXT NOT NULL,
    status document_status DEFAULT 'DRAFT',
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT,
    global_context JSONB DEFAULT '{}', -- Large JSON injected for the whole doc
    
    metadata JSONB DEFAULT '{}', -- Extra meta (author, dates)
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE sections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    document_id UUID REFERENCES documents(id) ON DELETE CASCADE,
    order_index INTEGER NOT NULL,
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT
);

CREATE TABLE pages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    order_index INTEGER NOT NULL,
    
    -- Layout properties
    width INTEGER,
    height INTEGER,
    
    -- Core Rendering Fields
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT
);

CREATE TABLE components (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    page_id UUID REFERENCES pages(id) ON DELETE CASCADE,
    
    -- Positioning
    x INTEGER,
    y INTEGER,
    width INTEGER,
    height INTEGER,
    z_index INTEGER DEFAULT 0,
    
    -- Type & Core Rendering Fields
    component_type TEXT NOT NULL,
    template TEXT,
    data JSONB DEFAULT '{}',
    data_path TEXT
);

-- Indexes for performance
CREATE INDEX idx_sections_doc ON sections(document_id);
CREATE INDEX idx_pages_section ON pages(section_id);
CREATE INDEX idx_components_page ON components(page_id);
