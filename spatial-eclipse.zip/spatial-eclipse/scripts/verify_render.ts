import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

async function run() {
    try {
        // 1. Create Document
        console.log('Creating Document...');
        const docRes = await axios.post(`${API_URL}/documents`, {
            title: "Render Test",
            template: "<html><h1>{{title}}</h1>{{{sections}}}</html>",
            data: { title: "Hello World" }
        });
        const docId = docRes.data.id;
        console.log('Document ID:', docId);

        // 2. Add Section
        console.log('Adding Section...');
        const secRes = await axios.post(`${API_URL}/documents/${docId}/sections`, {
            template: "<section><h2>Section 1</h2>{{{pages}}}</section>"
        });
        const secId = secRes.data.id;

        // 3. Add Page
        console.log('Adding Page...');
        const pageRes = await axios.post(`${API_URL}/sections/${secId}/pages`, {
            template: "<div class='page'>{{{components}}}</div>"
        });
        const pageId = pageRes.data.id;

        // 4. Add Component
        console.log('Adding Component...');
        await axios.post(`${API_URL}/pages/${pageId}/components`, {
            componentType: "text",
            template: "<p style='color:blue'>{{content}}</p>",
            data: { content: "It works!" }
        });

        // 5. Render
        console.log('Rendering...');
        const renderRes = await axios.get(`${API_URL}/documents/${docId}/render`);

        console.log('--- RENDER OUTPUT ---');
        console.log(renderRes.data);
        console.log('---------------------');

        if (renderRes.data.includes('It works!')) {
            console.log('✅ TEST PASSED');
        } else {
            console.log('❌ TEST FAILED');
        }

    } catch (error: any) {
        console.error('Error:', error.response ? error.response.data : error.message);
    }
}

run();
