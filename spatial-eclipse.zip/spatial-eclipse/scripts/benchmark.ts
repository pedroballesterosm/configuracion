import axios from 'axios';
import fs from 'fs';
import path from 'path';

const API_URL = 'http://localhost:3000/api';

// Reutilizamos la lógica de generación del informe bancario para crear un documento "pesado"
// Pero modificada para ser síncrona y rápida en creación de datos, para centrarnos en medir el RENDER

const generateTransactions = (count: number) => {
    return Array.from({ length: count }).map((_, i) => ({
        date: '2025-01-01', type: 'Compra', description: `Transacción benchmark #${i}`, amount: '$100.00', balance: '$1000.00', isNegative: false
    }));
};

const run = async () => {
    try {
        console.log('🏁 Iniciando Benchmark de Rendimiento...');
        const startSetup = performance.now();

        // 1. Crear Documento Base
        const docRes = await axios.post(`${API_URL}/documents`, {
            title: "Benchmark Doc 60 Pages",
            template: "<html><body>{{{sections}}}</body></html>",
            data: {},
            globalContext: { clientName: "Benchmark User" },
            metadata: { landscape: true }
        });
        const docId = docRes.data.id;

        // 2. Crear Sección
        const sectionRes = await axios.post(`${API_URL}/documents/${docId}/sections`, {
            orderIndex: 0, template: "{{{pages}}}", data: {}
        });
        const sectionId = sectionRes.data.id;

        // 3. Rellenar 60 Páginas con Datos (Simulando carga real)
        const pagesToCreate = 60;
        const itemsPerPage = 20; // Tabla mediana
        const transactions = generateTransactions(itemsPerPage);

        const pagePromises = [];
        for (let i = 0; i < pagesToCreate; i++) {
            pagePromises.push((async () => {
                const pRes = await axios.post(`${API_URL}/sections/${sectionId}/pages`, {
                    orderIndex: i,
                    template: `<div class="sheet"><h1>Página ${i}</h1><table>{{#each rows}}<tr><td>{{description}}</td></tr>{{/each}}</table><div style="page-break-after: always;"></div></div>`,
                    data: {}
                });
                // Inyectar componentes (Tabla)
                await axios.post(`${API_URL}/pages/${pRes.data.id}/components`, {
                    componentType: 'table',
                    template: 'generada dinamicamente en pagina', // simplificado para benchmark
                    data: { rows: transactions },
                    orderIndex: 0
                });
            })());
        }
        await Promise.all(pagePromises);

        const setupTime = (performance.now() - startSetup) / 1000;
        console.log(`✅ Setup BD completado en ${setupTime.toFixed(2)}s (Documento ID: ${docId})`);

        // --- MEDICIÓN DE RENDIMIENTO ---

        // A. HTML RENDER
        console.log('\n⏱ Midiendo Generación HTML (Server-Side Rendering)...');
        const startHtml = performance.now();
        await axios.get(`${API_URL}/documents/${docId}/render`);
        const htmlTime = (performance.now() - startHtml);
        console.log(`📄 HTML Generation Time: ${htmlTime.toFixed(2)} ms`);

        // B. PDF GENERATION (Puppeteer)
        console.log('\n⏱ Midiendo Generación PDF (Headless Chrome)...');
        const startPdf = performance.now();
        // Pedimos arraybuffer para que axios no se atragante con binarios, aunque no guardemos el archivo
        const pdfRes = await axios.get(`${API_URL}/documents/${docId}/pdf`, { responseType: 'arraybuffer' });
        const pdfTime = (performance.now() - startPdf);
        const pdfSizeMb = pdfRes.data.length / 1024 / 1024;
        console.log(`📥 PDF Generation Time: ${pdfTime.toFixed(2)} ms`);
        console.log(`📦 PDF Size: ${pdfSizeMb.toFixed(2)} MB`);

        // RESULTADOS
        console.log('\n--- RESUMEN DE MÉTRICAS (1 Documento / 60 Páginas) ---');
        console.log(`🔹 HTML Render: ${(htmlTime / 1000).toFixed(3)} s`);
        console.log(`🔹 PDF Render:  ${(pdfTime / 1000).toFixed(3)} s`);
        console.log(`🔹 Total E2E:   ${((htmlTime + pdfTime) / 1000).toFixed(3)} s`);

    } catch (error) {
        console.error('❌ Error en Benchmark:', error);
    }
};

run();
