import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

async function createFullExample() {
    try {
        console.log('🚀 Creando Documento de Ejemplo Completo...');

        // 1. Crear Documento
        // El Documento ahora solo actúa como contenedor de estilos globales y contexto
        const docTemplate = `
      <html>
        <head>
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
          <style>
            @page { size: A4 landscape; margin: 0; }
            
            /* Estilos Globales */
            * { box-sizing: border-box; }
            body { 
                font-family: 'Helvetica', sans-serif; 
                margin: 0; 
                padding: 0;
                background-color: #333; /* Fondo gris oscuro mesa de trabajo */
                display: flex;
                flex-direction: column;
                align-items: center;
                padding-top: 40px;
                padding-bottom: 40px;
            }

            /* La Hoja A4 ahora es parte de la PÁGINA, no del documento global */
            .sheet {
                background: white;
                width: 297mm; 
                height: 210mm;
                box-shadow: 0 0 30px rgba(0,0,0,0.5);
                border: 1px solid #ccc; /* Límite visual */
                position: relative;
                display: flex;
                flex-direction: column;
                margin-bottom: 40px; /* HUECO ENTRE PÁGINAS */
                overflow: hidden; /* Evitar desborde */
            }

            /* Reset para Impresión/PDF */
            @media print {
                body { background: none; padding: 0; display: block; }
                .sheet { 
                    width: 100%; height: 100%; 
                    box-shadow: none; border: none; margin: 0; 
                    page-break-after: always; /* Importante para el PDF */
                }
            }

            .header { background: #E67E22; color: white; padding: 15px 50px; text-align: center; display: flex; justify-content: space-between; align-items: center; height: 60px;}
            .content { padding: 40px; flex-grow: 1; overflow: hidden; }
            h1 { margin: 0; font-size: 20px; }
            .footer { text-align: center; font-size: 10px; color: #777; padding: 10px; border-top: 1px solid #eee; height: 30px; display: flex; justify-content: center; align-items: center;}
            
            .debug-info { position: fixed; top: 10px; left: 10px; color: white; font-family: monospace; font-size: 12px; z-index: 999; }
          </style>
        </head>
        <body>
          <div class="debug-info">View: Multi-Page A4 Landscape</div>
          {{{sections}}}
        </body>
      </html>
    `;

        const docRes = await axios.post(`${API_URL}/documents`, {
            title: "Informe V15 (Full Data Driven)",
            template: docTemplate,
            data: { author: "Spatial Eclipse Bot" },
            globalContext: { reportTitle: "INFORME ANUAL 2026" },
            metadata: { landscape: true }
        });
        const docId = docRes.data.id;
        console.log(`✅ Documento creado: ${docId}`);

        // 2. Crear Sección Base
        const sectionRes = await axios.post(`${API_URL}/documents/${docId}/sections`, {
            orderIndex: 0,
            template: `{{{pages}}}`,
            data: {}
        });
        const sectionId = sectionRes.data.id;

        // Helper para crear páginas
        const createPage = async (index: number, title: string, contentComponents: any[]) => {
            const pageRes = await axios.post(`${API_URL}/sections/${sectionId}/pages`, {
                orderIndex: index,
                template: `
        <div class="sheet">
           <div class="header">
                <h1>{{reportTitle}}</h1>
                <span>Página ${index + 1}</span>
            </div>
            <div class="content" style="display: flex; flex-direction: column; gap: 20px;">
                <h3 style="color: #333; border-bottom: 2px solid ${index % 2 === 0 ? '#e67e22' : '#2980b9'}; padding-bottom: 10px;">${title}</h3>
                {{{components}}}
            </div>
            <div class="footer">
                Spatial Eclipse Engine | Page ${index + 1} of 7
            </div>
        </div>
      `,
                data: {}
            });
            const pageId = pageRes.data.id;
            console.log(`✅ Página ${index + 1} creada: ${pageId}`);

            for (const comp of contentComponents) {
                await axios.post(`${API_URL}/pages/${pageId}/components`, comp);
            }
        };

        // --- PÁGINA 1: Resumen ---
        await createPage(0, "Resumen Ejecutivo", [
            {
                componentType: "text",
                template: `<div style="font-size: 18px; line-height: 1.6;">Este documento presenta el desglose completo de operaciones. <br><strong>Puntos clave:</strong><ul><li>Crecimiento sostenido.</li><li>Expansión internacional.</li><li>Nuevas oficinas en Tokio.</li></ul></div>`,
                data: {}
            },
            {
                componentType: "chart",
                template: `<div style="display: flex; gap: 10px; height: 150px; align-items: flex-end; justify-content: space-around; background: #fafafa; padding: 20px; border: 1px solid #eee;">
                    <div style="width: 50px; height: 40%; background: #bdc3c7;"></div>
                    <div style="width: 50px; height: 60%; background: #95a5a6;"></div>
                    <div style="width: 50px; height: 80%; background: #7f8c8d;"></div>
                    <div style="width: 50px; height: 100%; background: #2c3e50;"></div>
                </div>`,
                data: {}
            }
        ]);

        // --- PÁGINA 2: Ventas ---
        await createPage(1, "Análisis de Ventas Q1-Q2", [
            {
                componentType: "table",
                template: `<table style="width: 100%; text-align: left; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #2980b9; color: white;">
                            <th style="padding: 10px;">Región</th>
                            <th style="padding: 10px;">Q1</th>
                            <th style="padding: 10px;">Q2</th>
                            <th style="padding: 10px;">Dif</th>
                        </tr>
                    </thead>
                    <tbody>
                        {{#each salesData}}
                        <tr style="border-bottom: 1px solid #eee;">
                            <td style="padding: 8px;">{{region}}</td>
                            <td style="padding: 8px;">{{q1}}</td>
                            <td style="padding: 8px;">{{q2}}</td>
                            <td style="padding: 8px; font-weight: bold; color: {{color}};">{{diff}}</td>
                        </tr>
                        {{/each}}
                    </tbody>
                </table>`,
                data: {
                    salesData: [
                        { region: "EMEA", q1: "$1.2M", q2: "$1.4M", diff: "+16%", color: "green" },
                        { region: "APAC", q1: "$0.8M", q2: "$0.9M", diff: "+12%", color: "green" },
                        { region: "NA", q1: "$2.5M", q2: "$2.8M", diff: "+12%", color: "green" },
                        { region: "LATAM", q1: "$0.6M", q2: "$0.5M", diff: "-16%", color: "red" }
                    ]
                }
            }
        ]);

        // --- PÁGINA 3: Marketing (Nueva) ---
        await createPage(2, "Estrategia de Marketing", [
            {
                componentType: "text",
                template: `<div style="column-count: 2; column-gap: 40px;">
                    <p>La nueva campaña se centra en la <strong>visibilidad digital</strong>. Hemos incrementado el presupuesto en redes sociales un 200%.</p>
                    <p>El retorno de inversión (ROI) estimado es del 4.5x para el final del año fiscal. Los canales principales serán LinkedIn y Twitter.</p>
                </div>`,
                data: {}
            },
            {
                componentType: "image-mock",
                template: `<div style="background: #333; color: white; height: 200px; display: flex; align-items: center; justify-content: center;">Espacio para Banner Publicitario (Placeholder)</div>`,
                data: {}
            }
        ]);

        // --- PÁGINA 4: RRHH (Nueva) ---
        await createPage(3, "Recursos Humanos y Talento", [
            {
                componentType: "cards",
                template: `<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px;">
                    <div style="border: 1px solid #ccc; padding: 15px; text-align: center;"><h4>Nuevas Contrataciones</h4><h1>+45</h1></div>
                    <div style="border: 1px solid #ccc; padding: 15px; text-align: center;"><h4>Retención</h4><h1>98%</h1></div>
                    <div style="border: 1px solid #ccc; padding: 15px; text-align: center;"><h4>Satisfacción</h4><h1>4.8/5</h1></div>
                </div>`,
                data: {}
            }
        ]);

        // --- PÁGINA 5: Conclusiones (Nueva) ---
        await createPage(4, "Conclusiones Finales", [
            {
                componentType: "text",
                template: `<div style="text-align: center; margin-top: 50px;">
                    <h1 style="color: #27ae60; font-size: 3em;">OBJETIVO CUMPLIDO</h1>
                    <p style="font-size: 1.5em; color: #555;">Gracias por un año excelente.</p>
                    <div style="margin-top: 50px; border-top: 2px solid #333; width: 200px; margin-left: auto; margin-right: auto; padding-top: 10px;">Firma del Director</div>
                </div>`,
                data: {}
            }
        ]);

        // --- PÁGINA 6: Chart.js Real (Nueva) ---
        await createPage(5, "Métricas en Tiempo Real (Chart.js)", [
            {
                componentType: "chart-js",
                template: `
                <div style="width: 80%; margin: 0 auto;">
                    <canvas id="chartPage6"></canvas>
                </div>
                <!-- Wrapped in DOMContentLoaded to ensure library is loaded -->
                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        const ctx = document.getElementById('chartPage6');
                        if (ctx && typeof Chart !== 'undefined') {
                            new Chart(ctx, {
                                type: 'bar',
                                data: {
                                    labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
                                    datasets: [{
                                        label: '# of Votes',
                                        data: [12, 19, 3, 5, 2, 3],
                                        borderWidth: 1,
                                        backgroundColor: [
                                            'rgba(255, 99, 132, 0.2)',
                                            'rgba(54, 162, 235, 0.2)',
                                            'rgba(255, 206, 86, 0.2)',
                                            'rgba(75, 192, 192, 0.2)',
                                            'rgba(153, 102, 255, 0.2)',
                                            'rgba(255, 159, 64, 0.2)'
                                        ],
                                        borderColor: [
                                            'rgba(255, 99, 132, 1)',
                                            'rgba(54, 162, 235, 1)',
                                            'rgba(255, 206, 86, 1)',
                                            'rgba(75, 192, 192, 1)',
                                            'rgba(153, 102, 255, 1)',
                                            'rgba(255, 159, 64, 1)'
                                        ]
                                    }]
                                },
                                options: {
                                    animation: false, 
                                    responsive: true,
                                    plugins: {
                                        legend: { position: 'top' },
                                        title: { display: true, text: 'Chart.js Bar Chart Integration' },
                                        datalabels: { display: false } // Desactivar datalabels aquí
                                    },
                                }
                            });
                        }
                    });
                </script>
                `,
                data: {}
            }
        ]);

        // --- PÁGINA 7: Dashboard Inversiones (Tabla + 3 Pies) ---
        await createPage(6, "Portfolio de Inversiones", [
            {
                componentType: "dashboard-split",
                template: `
                <div style="display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 40px; height: 100%;">
                    
                    <!-- Columna Izquierda: Tabla -->
                    <div style="background: #fff; padding: 10px;">
                        <h4 style="color: #555; border-bottom: 2px solid #ddd; padding-bottom: 5px; margin-top: 0;">Desglose de Activos</h4>
                        <table style="width: 100%; border-collapse: collapse; font-size: 14px;">
                            <thead>
                                <tr style="background: #f8f9fa;">
                                    <th style="padding: 12px; text-align: left; border-bottom: 2px solid #ddd;">Activo</th>
                                    <th style="padding: 12px; text-align: right; border-bottom: 2px solid #ddd;">Valor ($)</th>
                                    <th style="padding: 12px; text-align: right; border-bottom: 2px solid #ddd;">Part. %</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{#each assets}}
                                <tr style="{{#if isTotal}}font-weight: bold; background: #eef;{{else}}border-bottom: 1px solid #eee;{{/if}}">
                                    <td style="padding: 10px;">{{name}}</td>
                                    <td style="text-align: right;">{{value}}</td>
                                    <td style="text-align: right;">{{percentage}}</td>
                                </tr>
                                {{/each}}
                            </tbody>
                        </table>
                        
                        <div style="margin-top: 30px; padding: 15px; background: #fdf2e9; border-left: 4px solid #e67e22;">
                            <strong>Nota del Analista:</strong><br>
                            Se recomienda rebalancear la posición en Tecnológicas debido a la alta volatilidad reciente. Aumentar exposición en Bonos.
                        </div>
                    </div>

                    <!-- Columna Derecha: 3 Gráficos de Tarta -->
                    <div style="display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100%; gap: 10px;">
                        
                        <!-- Pie 1 -->
                        <div style="width: 180px; height: 180px; position: relative;">
                            <canvas id="pieRisk"></canvas>
                        </div>

                        <!-- Pie 2 -->
                        <div style="width: 180px; height: 180px; position: relative;">
                            <canvas id="pieSector"></canvas>
                        </div>
                        
                        <!-- Pie 3 -->
                        <div style="width: 180px; height: 180px; position: relative;">
                            <canvas id="pieGeo"></canvas>
                        </div>

                    </div>
                </div>

                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        // Data Injection via Handlebars Helper
                        // 'charts' data comes from the JSON passed to the specific component
                        const chartData = {{{json charts}}};

                        // Registro global del plugin si se cargó vía CDN
                        if (typeof ChartDataLabels !== 'undefined' && typeof Chart !== 'undefined') {
                            Chart.register(ChartDataLabels);
                        }

                        if (typeof Chart === 'undefined') return;

                        const pieOptions = { 
                            animation: false, 
                            responsive: true, 
                            maintainAspectRatio: false,
                            layout: { padding: 5 },
                            plugins: { 
                                legend: { 
                                    display: true, 
                                    position: 'right', // Leyenda mantiene los nombres
                                    labels: { boxWidth: 8, font: { size: 9 } }
                                },
                                datalabels: {
                                    color: '#fff',
                                    font: { weight: 'bold', size: 12 },
                                    formatter: (value, ctx) => {
                                        // SOLO PORCENTAJE dentro del gráfico
                                        return Math.round(value) + '%';
                                    },
                                    textAlign: 'center',
                                    textShadowColor: 'black',
                                    textShadowBlur: 3
                                }
                            } 
                        };

                        // helper para crear charts si existen
                        const createPie = (id, dataset, title, type = 'pie') => {
                            const el = document.getElementById(id);
                            if (el && dataset) {
                                new Chart(el, {
                                    type: type,
                                    data: {
                                        labels: dataset.labels,
                                        datasets: [{
                                            data: dataset.values,
                                            backgroundColor: dataset.colors,
                                            borderWidth: 1,
                                            borderColor: '#fff'
                                        }]
                                    },
                                    options: {
                                        ...pieOptions,
                                        plugins: {
                                            ...pieOptions.plugins,
                                            title: { display: true, text: title }
                                        }
                                    }
                                });
                            }
                        };

                        // Render using injected data
                        createPie('pieRisk', chartData.risk, 'Perfil Riesgo', 'doughnut');
                        createPie('pieSector', chartData.sector, 'Distribución Sectorial');
                        createPie('pieGeo', chartData.geo, 'Geográfico');
                    });
                </script>
                `,
                data: {
                    assets: [
                        { name: "Tech ETF (QQQ)", value: "500,000", percentage: "25%", isTotal: false },
                        { name: "Bonos Tesoro 10Y", value: "400,000", percentage: "20%", isTotal: false },
                        { name: "Real Estate REITs", value: "300,000", percentage: "15%", isTotal: false },
                        { name: "Emerging Markets", value: "200,000", percentage: "10%", isTotal: false },
                        { name: "Commodities (Gold)", value: "200,000", percentage: "10%", isTotal: false },
                        { name: "Cash & Equivalents", value: "200,000", percentage: "10%", isTotal: false },
                        { name: "Crypto Assets", value: "100,000", percentage: "5%", isTotal: false },
                        { name: "TOTAL", value: "$1,900,000", percentage: "100%", isTotal: true }
                    ],
                    charts: {
                        risk: {
                            labels: ['Alto', 'Medio', 'Bajo'],
                            values: [30, 40, 30],
                            colors: ['#e74c3c', '#f39c12', '#2ecc71']
                        },
                        sector: {
                            labels: ['Tech', 'Finanzas', 'Salud', 'Energía'],
                            values: [40, 20, 15, 25],
                            colors: ['#3498db', '#9b59b6', '#1abc9c', '#34495e']
                        },
                        geo: {
                            labels: ['USA', 'Europa', 'Asia'],
                            values: [50, 30, 20],
                            colors: ['#e67e22', '#3498db', '#e74c3c']
                        }
                    }
                }
            }
        ]);


        // 5. Resultado
        console.log('\n🎉 ¡Proceso Finalizado!');
        console.log('-------------------------------------------------------');
        console.log(`📄 Ver HTML: http://localhost:3000/api/documents/${docId}/render`);
        console.log(`📥 Descargar PDF: http://localhost:3000/api/documents/${docId}/pdf`);
        console.log('-------------------------------------------------------');

    } catch (error: any) {
        console.error('❌ Error:', error.response ? error.response.data : error.message);
    }
}

createFullExample();
