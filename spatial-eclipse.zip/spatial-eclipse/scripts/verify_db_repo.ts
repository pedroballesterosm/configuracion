import {
    DatabaseDocumentRepository,
    DatabaseSectionRepository,
    DatabasePageRepository,
    DatabaseComponentRepository
} from '../src/infrastructure/database/DatabaseRepositories';
import { DocumentStatus } from '../src/core/entities/domain';

const run = async () => {
    console.log('🧪 Starting Database Repository Verification...');

    const docRepo = new DatabaseDocumentRepository();
    const sectionRepo = new DatabaseSectionRepository();
    const pageRepo = new DatabasePageRepository();
    const compRepo = new DatabaseComponentRepository();

    try {
        // 1. Create Document
        console.log('1. Creating Document...');
        const doc = await docRepo.create({
            title: "Verification Doc " + Date.now(),
            status: DocumentStatus.DRAFT,
            template: "<html>{{sections}}</html>",
            data: { test: true },
            globalContext: {},
            metadata: { author: "tester" },
            sections: []
        });
        console.log(`✅ Document created: ${doc.id}`);

        // 2. Create Section
        console.log('2. Creating Section...');
        const section = await sectionRepo.create({
            documentId: doc.id,
            orderIndex: 0,
            template: "{{pages}}",
            data: {},
            pages: []
        });
        console.log(`✅ Section created: ${section.id}`);

        // 3. Create Page
        console.log('3. Creating Page...');
        const page = await pageRepo.create({
            sectionId: section.id,
            orderIndex: 0,
            template: "{{components}}",
            data: {},
            components: []
        });
        console.log(`✅ Page created: ${page.id}`);

        // 4. Create Component
        console.log('4. Creating Component...');
        const comp = await compRepo.create({
            pageId: page.id,
            componentType: "text",
            orderIndex: 0,
            template: "<div>Hello DB</div>",
            data: {}
        });
        console.log(`✅ Component created: ${comp.id}`);

        // 5. Verify Hierarchy
        console.log('5. Verifying Hierarchy...');
        const sections = await sectionRepo.findByDocumentId(doc.id);
        if (sections.length !== 1) throw new Error("Section count mismatch");

        const pages = await pageRepo.findBySectionId(sections[0].id);
        if (pages.length !== 1) throw new Error("Page count mismatch");

        const comps = await compRepo.findByPageId(pages[0].id);
        if (comps.length !== 1) throw new Error("Component count mismatch");

        if (comps[0].id !== comp.id) throw new Error("Component ID mismatch");

        console.log('✅ Hierarchy verified.');

        // 6. Cleanup
        console.log('6. Cleaning up...');
        await docRepo.delete(doc.id); // Cascade delete should handle children

        const checkDoc = await docRepo.findById(doc.id);
        if (checkDoc) throw new Error("Document delete failed");

        console.log('✅ Cleanup verified.');
        console.log('🎉 All tests passed!');
        process.exit(0);

    } catch (err) {
        console.error('❌ Verification Failed:', err);
        process.exit(1);
    }
};

run();
