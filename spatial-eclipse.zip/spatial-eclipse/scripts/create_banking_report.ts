import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

// --- DATA GENERATORS ---

const generateTransactions = (count: number) => {
    const types = ['Compra', 'Venta', 'Dividendo', 'Interés', 'Transferencia'];
    const assets = ['Apple Ub', 'Tesla Inc', 'Bonos EEUU 10Y', 'Liquidez', 'ETF S&P 500', 'Bitcoin Trust'];
    const transactions = [];
    let balance = 1500000;

    for (let i = 0; i < count; i++) {
        const type = types[Math.floor(Math.random() * types.length)];
        const asset = assets[Math.floor(Math.random() * assets.length)];
        const amount = Math.floor(Math.random() * 10000) * (Math.random() > 0.5 ? 1 : -1);
        const date = new Date(2025, 0, 1 + i).toISOString().split('T')[0];

        balance += amount;

        transactions.push({
            date,
            type,
            description: `${type} - ${asset} (Op. #${100000 + i})`,
            amount: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount),
            balance: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(balance),
            isNegative: amount < 0
        });
    }
    return transactions.reverse(); // Newest first
};

// --- TEMPLATES ---

const docTemplate = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chartjs-plugin-datalabels@2.0.0"></script>
  <style>
    @page { size: A4 landscape; margin: 0; }
    * { box-sizing: border-box; }
    body { 
        font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; 
        margin: 0; 
        padding: 40px; 
        color: #333; 
        background-color: #555; /* Fondo gris para resaltar hojas */
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 30px; /* Separación entre páginas */
    }
    .sheet { 
        width: 297mm; 
        height: 210mm; 
        position: relative; 
        overflow: hidden; 
        background-color: #fff;
        box-shadow: 0 0 15px rgba(0,0,0,0.5); /* Sombra realista */
    }
    /* El salto de página sigue funcionando para impresión/PDF */
    @media print {
        body { background: none; display: block; padding: 0; margin: 0; gap: 0; }
        .sheet { box-shadow: none; page-break-after: always; margin: 0; }
    }
    .header { position: absolute; top: 0; left: 0; width: 100%; height: 50px; background: #1a2a40; color: white; display: flex; align-items: center; justify-content: space-between; padding: 0 40px; box-sizing: border-box; }
    .footer { position: absolute; bottom: 0; left: 0; width: 100%; height: 30px; border-top: 1px solid #ddd; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #777; background: #f9f9f9; }
    .content { margin-top: 60px; margin-bottom: 40px; padding: 30px 40px; height: calc(210mm - 100px); overflow: hidden; }
    h1 { font-size: 24px; font-weight: 300; text-transform: uppercase; letter-spacing: 1px; }
    h2 { color: #1a2a40; border-bottom: 2px solid #e67e22; padding-bottom: 10px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; font-size: 11px; }
    th { background: #f0f0f5; text-align: left; padding: 6px; color: #555; font-weight: 600; border-bottom: 2px solid #ddd; }
    td { padding: 6px; border-bottom: 1px solid #eee; }
    .negative { color: #e74c3c; }
    .positive { color: #27ae60; }
    .cover-title { margin-top: 300px; font-size: 48px; color: #1a2a40; text-align: right; }
    .cover-subtitle { font-size: 24px; color: #e67e22; text-align: right; }
  </style>
</head>
<body>
  {{{sections}}}
</body>
</html>
`;

// --- MAIN SCRIPT ---

const run = async () => {
    try {
        console.log('🚀 Iniciando Generación de Reporte Bancario (+50 Páginas)...');

        // 1. Crear Documento
        const docRes = await axios.post(`${API_URL}/documents`, {
            title: "Global Wealth Report 2026 (Landscape)",
            template: docTemplate,
            data: {},
            globalContext: {
                clientName: "Familia Ballesteros Office",
                accountNumber: "ES89-XXXX-XXXX-9876",
                reportDate: "Enero 2026"
            },
            metadata: { landscape: true }
        });
        const docId = docRes.data.id;
        console.log(`✅ Documento creado: ${docId}`);

        // 2. Crear Sección Única (para simplificar, todo en una sección)
        const sectionRes = await axios.post(`${API_URL}/documents/${docId}/sections`, {
            orderIndex: 0,
            template: `{{{pages}}}`,
            data: {}
        });
        const sectionId = sectionRes.data.id;

        let pageIndex = 0;

        // HELPER: Crear Página Standard
        const createPage = async (title: string, components: any[], customTemplate?: string) => {
            const defaultTemplate = `
                    <div class="sheet">
                        <div class="header">
                            <div>PRIVATE BANKING</div>
                            <div style="font-size: 12px;">{{clientName}} | {{accountNumber}}</div>
                        </div>
                        <div class="content">
                            ${title ? `<h2>${title}</h2>` : ''}
                            {{{components}}}
                        </div>
                        <div class="footer">
                            Página ${pageIndex} | Confidencial
                        </div>
                    </div>
                `;

            const pageRes = await axios.post(`${API_URL}/sections/${sectionId}/pages`, {
                orderIndex: pageIndex++,
                template: customTemplate || defaultTemplate,
                data: {}
            });
            const pageId = pageRes.data.id;

            // CRITICAL: Actually create the components!
            let compOrder = 0;
            for (const comp of components) {
                await axios.post(`${API_URL}/pages/${pageId}/components`, {
                    ...comp,
                    orderIndex: compOrder++
                });
            }
            process.stdout.write('.'); // Progress dot
        };

        // --- PÁGINA 1: PORTADA ---
        const coverPageTemplate = `{{{components}}}`; // Just render the component(s)

        const coverComponent = {
            componentType: "cover-main",
            template: `
                <div class="sheet" style="background: #f7f9fc;">
                    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; border-left: 120px solid #1a2a40;"></div>
                    <div class="content" style="z-index: 10; padding-left: 160px; display: flex; flex-direction: column; justify-content: center; height: 100%;">
                        <div>
                            <h1 style="font-size: 64px; color: #1a2a40; margin: 0; line-height: 1.1;">{{{title}}}</h1>
                            <h2 style="font-size: 32px; color: #e67e22; border: none; margin-top: 15px;">{{{subtitle}}}</h2>
                        </div>
                        <div style="margin-top: 60px; font-size: 18px; color: #555;">
                            <p style="margin: 5px 0;"><strong>Cliente:</strong> {{clientName}}</p>
                            <p style="margin: 5px 0;"><strong>Cuenta:</strong> {{accountNumber}}</p>
                            <p style="margin: 5px 0;"><strong>Fecha Valuación:</strong> {{valuationDate}}</p>
                            <p style="margin: 5px 0;"><strong>Asesor:</strong> {{advisor}}</p>
                        </div>
                        <div style="position: absolute; bottom: 40px; right: 50px;">
                           <img src="{{logoUrl}}" alt="Logo" />
                        </div>
                    </div>
                </div>
            `,
            data: {
                title: "INFORME<br>INTEGRAL",
                subtitle: "PATRIMONIO 2026",
                valuationDate: "31 Diciembre 2025",
                advisor: "Spatial Eclipse AI",
                logoUrl: "https://via.placeholder.com/180x60?text=BANK+LOGO"
            }
        };

        await createPage("", [coverComponent], coverPageTemplate);
        console.log('\n✅ Portada generada');

        // --- PÁGINA 2: RESUMEN EJECUTIVO (Atomic Components) ---
        // Grid Layout Template for the Page (Wrapped in Standard Sheet)
        const page2Template = `
            <div class="sheet">
                <style>
                    .dashboard-grid {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        grid-template-rows: 130px 1fr; /* Fixed height for KPI, rest for Chart */
                        gap: 25px;
                        height: 100%;
                        margin-top: 10px;
                    }
                    /* Component 1: KPI (Top Left) */
                    .dashboard-grid > div:nth-child(1) { grid-column: 1; grid-row: 1; }
                    /* Component 2: Allocation (Bottom Left) */
                    .dashboard-grid > div:nth-child(2) { grid-column: 1; grid-row: 2; height: 100%; overflow: hidden; }
                    /* Component 3: History (Right Column Full Height) */
                    .dashboard-grid > div:nth-child(3) { grid-column: 2; grid-row: 1 / span 2; }
                </style>
                <div class="header">
                    <div>PRIVATE BANKING</div>
                    <div style="font-size: 12px;">{{clientName}} | {{accountNumber}}</div>
                </div>
                <div class="content">
                    <h2>Visión Global del Patrimonio</h2>
                    <div class="dashboard-grid">
                        {{{components}}}
                    </div>
                </div>
                <div class="footer">
                    Página ${pageIndex + 1} | Confidencial
                </div>
            </div>
        `;

        const kpiComponent = {
            componentType: "kpi-card",
            template: `
                <div style="background: #eef2f7; padding: 10px; border-radius: 8px; text-align: center; height: 100%; display: flex; flex-direction: column; justify-content: center;">
                    <h3 style="margin: 0; color: #777; font-size: 12px;">Valor Total</h3>
                    <h1 style="margin: 2px 0; font-size: 24px; color: #1a2a40;">{{totalValue}}</h1>
                    <span style="color: {{ytdColor}}; font-size: 10px;">{{ytdLabel}}</span>
                </div>
            `,
            data: {
                totalValue: "$12,450,000",
                ytdLabel: "▲ +8.4% YTD",
                ytdColor: "green"
            }
        };

        const allocationComponent = {
            componentType: "chart-allocation",
            template: `
                <div style="display: flex; flex-direction: column; height: 100%; justify-content: center;">
                    <h4 style="border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-bottom: 15px; font-size: 12px;">Distribución por Activo</h4>
                    <div style="height: 220px; position: relative;">
                        <canvas id="chartAllocation"></canvas>
                    </div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     if (typeof ChartDataLabels !== 'undefined') Chart.register(ChartDataLabels);

                     const el = document.getElementById('chartAllocation');
                     if (el) {
                         new Chart(el, {
                            type: 'doughnut',
                            data: {{{json chartData}}},
                            options: { 
                                maintainAspectRatio: false,
                                responsive: true,
                                plugins: { 
                                    legend: { position: 'right', labels: { boxWidth: 10, font: { size: 10 } } },
                                    datalabels: { color: '#fff', font: { weight: 'bold', size: 11 }, formatter: (val) => val + '%' }
                                } 
                            }
                         });
                     }
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['Renta Variable', 'Renta Fija', 'Alternativos', 'Liquidez'],
                    datasets: [{
                        data: [55, 30, 10, 5],
                        backgroundColor: ['#1a2a40', '#3498db', '#e67e22', '#bddcff'],
                        borderWidth: 1,
                        borderColor: '#fff'
                    }]
                }
            }
        };

        const historyComponent = {
            componentType: "chart-history",
            template: `
                <div style="display: flex; flex-direction: column; height: 100%;">
                    <h4 style="border-bottom: 1px solid #ccc; padding-bottom: 5px; margin-bottom: 20px; font-size: 12px;">Evolución Histórica (5 Años)</h4>
                    <div style="height: 350px; position: relative;">
                        <canvas id="chartHistory"></canvas>
                    </div>
                    <div style="margin-top: 25px; font-size: 11px; color: #666; text-align: justify; line-height: 1.3;">
                        <p>{{description}}</p>
                    </div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     
                     const el = document.getElementById('chartHistory');
                     if (el) {
                         new Chart(el, {
                            type: 'line',
                            data: {{{json chartData}}},
                            options: { 
                                maintainAspectRatio: false,
                                responsive: true,
                                scales: { y: { beginAtZero: false } },
                                plugins: { datalabels: { display: false } }
                            }
                         });
                     }
                });
                </script>
            `,
            data: {
                description: "La cartera ha mostrado una resiliencia notable frente a la volatilidad del mercado. La sobreponderación en tecnología y renta fija de alta calidad ha amortiguado las caídas recientes.",
                chartData: {
                    labels: ['2021', '2022', '2023', '2024', '2025'],
                    datasets: [{
                        label: 'Valor Cartera (M$)',
                        data: [8.5, 9.2, 10.1, 11.5, 12.45],
                        borderColor: '#e67e22',
                        tension: 0.4,
                        fill: true,
                        backgroundColor: 'rgba(230, 126, 34, 0.1)'
                    }]
                }
            }
        };

        // Create Page with Custom Template and 3 Components
        await createPage("Visión Global del Patrimonio", [kpiComponent, allocationComponent, historyComponent], page2Template);

        // --- PÁGINA 3: RENTA VARIABLE (Atomic Components) ---
        const page3Template = `
            <div class="sheet">
                <style>
                    .equities-grid {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        grid-template-rows: 1fr 1fr;
                        gap: 20px;
                        height: 100%;
                        margin-top: 20px;
                    }
                    /* Left Column: Charts */
                    .equities-grid > div:nth-child(1) { grid-column: 1; grid-row: 1; }
                    .equities-grid > div:nth-child(2) { grid-column: 1; grid-row: 2; }
                    
                    /* Right Column: Table and Text */
                    .equities-grid > div:nth-child(3) { grid-column: 2; grid-row: 1; }
                    .equities-grid > div:nth-child(4) { grid-column: 2; grid-row: 2; align-self: end; }
                </style>
                <div class="header">
                    <div>PRIVATE BANKING</div>
                    <div style="font-size: 12px;">{{clientName}} | {{accountNumber}}</div>
                </div>
                <div class="content">
                    <h2>Cartera de Renta Variable</h2>
                    <div class="equities-grid">
                        {{{components}}}
                    </div>
                </div>
                <div class="footer">
                    Página ${pageIndex + 1} | Confidencial
                </div>
            </div>
        `;

        const sectorComponent = {
            componentType: "chart-sector",
            template: `
                <div style="background: #fff; border: 1px solid #eee; padding: 15px; height: 100%;">
                    <h4 style="margin: 0 0 10px 0; font-size: 12px; color: #555;">Distribución Sectorial</h4>
                    <div style="height: 180px; position: relative;"><canvas id="chartSector"></canvas></div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     if (typeof ChartDataLabels !== 'undefined') Chart.register(ChartDataLabels);
                     
                     const el = document.getElementById('chartSector');
                     if(el) new Chart(el, {
                        type: 'pie',
                        data: {{{json chartData}}},
                        options: { maintainAspectRatio: false, responsive: true, plugins: { datalabels: { color: '#fff', font: { weight: 'bold' }, formatter: (v) => v + '%' }, legend: { position: 'right', labels: { boxWidth: 10, font: { size: 9 } } } } }
                     });
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['Tecnología', 'Salud', 'Finanzas', 'Consumo', 'Otros'],
                    datasets: [{
                        data: [45, 15, 15, 15, 10],
                        backgroundColor: ['#2980b9', '#27ae60', '#f1c40f', '#e67e22', '#95a5a6'],
                        borderWidth: 1
                    }]
                }
            }
        };

        const geoComponent = {
            componentType: "chart-geo",
            template: `
                <div style="background: #fff; border: 1px solid #eee; padding: 15px; height: 100%;">
                    <h4 style="margin: 0 0 10px 0; font-size: 12px; color: #555;">Distribución Geográfica</h4>
                    <div style="height: 180px; position: relative;"><canvas id="chartGeo"></canvas></div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     
                     const el = document.getElementById('chartGeo');
                     if(el) new Chart(el, {
                        type: 'doughnut',
                        data: {{{json chartData}}},
                        options: { maintainAspectRatio: false, responsive: true, plugins: { datalabels: { color: '#fff', font: { weight: 'bold' }, formatter: (v) => v + '%' }, legend: { position: 'right', labels: { boxWidth: 10, font: { size: 9 } } } } }
                     });
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['Norteamérica', 'Europa', 'Asia-Pacífico', 'Emergentes'],
                    datasets: [{
                        data: [60, 25, 10, 5],
                        backgroundColor: ['#34495e', '#ecf0f1', '#e74c3c', '#9b59b6'],
                        borderWidth: 1
                    }]
                }
            }
        };

        const tableComponent = {
            componentType: "equities-table",
            template: `
                <div>
                    <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Principales Posiciones</h4>
                    <table style="width: 100%; font-size: 10px; border-collapse: collapse;">
                        <thead style="background: #f4f6f8;">
                            <tr>
                                <th style="padding: 8px; text-align: left;">Compañía</th>
                                <th style="padding: 8px; text-align: center;">Ticker</th>
                                <th style="padding: 8px; text-align: right;">% Cart.</th>
                                <th style="padding: 8px; text-align: right;">Valor ($)</th>
                                <th style="padding: 8px; text-align: right;">Rent. %</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each rows}}
                            <tr style="border-bottom: 1px solid #eee;">
                                <td>{{name}}</td>
                                <td style="text-align: center;">{{ticker}}</td>
                                <td style="text-align: right; font-weight: bold;">{{weight}}</td>
                                <td style="text-align: right;">{{value}}</td>
                                <td style="text-align: right; {{#if isPositive}}color: green;{{else}}color: red;{{/if}}">{{performance}}</td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>
            `,
            data: {
                rows: [
                    { name: "Apple Inc.", ticker: "AAPL", weight: "8.5%", value: "1,058,250", performance: "+12.4%", isPositive: true },
                    { name: "Microsoft Corp.", ticker: "MSFT", weight: "7.2%", value: "896,400", performance: "+9.1%", isPositive: true },
                    { name: "NVIDIA Corp.", ticker: "NVDA", weight: "6.8%", value: "846,600", performance: "+45.2%", isPositive: true },
                    { name: "Amazon.com Inc.", ticker: "AMZN", weight: "5.1%", value: "634,950", performance: "+5.3%", isPositive: true },
                    { name: "Alphabet Inc.", ticker: "GOOGL", weight: "4.9%", value: "610,050", performance: "-1.2%", isPositive: false }
                ]
            }
        };

        const analysisComponent = {
            componentType: "manager-analysis",
            template: `
                <div style="padding: 15px; background: #e8f5e9; border: 1px solid #c8e6c9; font-size: 11px; color: #388e3c; border-radius: 4px;">
                    <strong>Análisis del Gestor:</strong> {{text}}
                </div>
            `,
            data: {
                text: "La cartera de renta variable mantiene un sesgo de crecimiento (Growth) con fuerte convicción en Inteligencia Artificial y Cloud Computing. Se ha reducido exposición a consumo discrecional."
            }
        };

        await createPage("Cartera de Renta Variable", [sectorComponent, geoComponent, tableComponent, analysisComponent], page3Template);


        // --- PÁGINA 4: RENTA FIJA (Atomic Components) ---
        const page4Template = `
            <div class="sheet">
                <style>
                    .fixed-grid {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        grid-template-rows: 1fr auto; /* Fixed height for bottom row */
                        gap: 20px;
                        height: 100%;
                        margin-top: 20px;
                    }
                    /* Left Column: Charts */
                    .fixed-grid > div:nth-child(1) { grid-column: 1; grid-row: 1; }
                    .fixed-grid > div:nth-child(2) { grid-column: 1; grid-row: 2; }
                    
                    /* Right Column: Table and Text */
                    .fixed-grid > div:nth-child(3) { grid-column: 2; grid-row: 1; }
                    .fixed-grid > div:nth-child(4) { grid-column: 2; grid-row: 2; }
                </style>
                <div class="header">
                    <div>PRIVATE BANKING</div>
                    <div style="font-size: 12px;">{{clientName}} | {{accountNumber}}</div>
                </div>
                <div class="content">
                    <h2>Renta Fija y Crédito</h2>
                    <div class="fixed-grid">
                        {{{components}}}
                    </div>
                </div>
                <div class="footer">
                    Página ${pageIndex + 1} | Confidencial
                </div>
            </div>
        `;

        const ratingComponent = {
            componentType: "chart-rating",
            template: `
                <div style="background: #fff; border: 1px solid #eee; padding: 15px; height: 100%;">
                   <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555;">Distribución por Rating</h4>
                   <div style="height: 180px; position: relative;"><canvas id="chartRating"></canvas></div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     if (typeof ChartDataLabels !== 'undefined') Chart.register(ChartDataLabels);

                     const elRat = document.getElementById('chartRating');
                     if(elRat) new Chart(elRat, {
                        type: 'bar',
                        data: {{{json chartData}}},
                        options: { maintainAspectRatio: false, responsive: true, plugins: { legend: { display: false }, datalabels: { color: 'white', anchor: 'center', align: 'center' } }, scales: { y: { beginAtZero: true, grid: { display: false } } } }
                     });
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['AAA', 'AA', 'A', 'BBB', 'HY'],
                    datasets: [{
                        label: '% Cartera',
                        data: [40, 25, 20, 10, 5],
                        backgroundColor: ['#2ecc71', '#3498db', '#9b59b6', '#f1c40f', '#e74c3c']
                    }]
                }
            }
        };

        const maturityComponent = {
            componentType: "chart-maturity",
            template: `
                <div style="background: #fff; border: 1px solid #eee; padding: 15px; height: 100%;">
                   <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555;">Vencimientos (Maturity)</h4>
                   <div style="height: 180px; position: relative;"><canvas id="chartMaturity"></canvas></div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     
                     const elMat = document.getElementById('chartMaturity');
                     if(elMat) new Chart(elMat, {
                        type: 'bar',
                        data: {{{json chartData}}},
                        options: { maintainAspectRatio: false, responsive: true, plugins: { legend: { display: false }, datalabels: { display: false } } }
                     });
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['<1Y', '1-3Y', '3-5Y', '5-7Y', '7-10Y', '>10Y'],
                    datasets: [{
                        label: 'Exposición',
                        data: [10, 20, 30, 15, 15, 10],
                        backgroundColor: '#1a2a40',
                        borderRadius: 4
                    }]
                }
            }
        };

        const bondsTableComponent = {
            componentType: "fixed-income-table",
            template: `
                <div>
                    <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Bonos Destacados</h4>
                     <table style="width: 100%; font-size: 10px; border-collapse: collapse;">
                        <thead style="background: #f4f6f8;">
                            <tr>
                                <th style="padding: 8px; text-align: left;">Emisor</th>
                                <th style="padding: 8px; text-align: center;">Cupón</th>
                                <th style="padding: 8px; text-align: center;">Vencimiento</th>
                                <th style="padding: 8px; text-align: right;">Rating</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each highlightedBonds}}
                            <tr style="border-bottom: 1px solid #eee;">
                                <td>{{issuer}}</td>
                                <td style="text-align: center;">{{coupon}}</td>
                                <td style="text-align: center;">{{maturity}}</td>
                                <td style="text-align: right;"><span style="background: #eef; padding: 2px 4px;">{{rating}}</span></td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>
            `,
            data: {
                highlightedBonds: [
                    { issuer: "US Treasury Note", coupon: "4.25%", maturity: "2032", rating: "AAA" },
                    { issuer: "Apple Inc Bond", coupon: "3.80%", maturity: "2028", rating: "AA+" },
                    { issuer: "JPMorgan Chase", coupon: "5.10%", maturity: "2030", rating: "A-" },
                    { issuer: "Goldman Sachs Group", coupon: "5.50%", maturity: "2035", rating: "BBB+" }
                ]
            }
        };

        const fixedIncomeAnalysisComponent = {
            componentType: "manager-analysis-fixed",
            template: `
                <div style="padding: 10px; background: #fff8e1; border: 1px solid #ffe0b2; font-size: 10px; color: #f57c00; border-radius: 4px;">
                    <strong>Estrategia de Duración:</strong> {{text}}
                </div>
            `,
            data: {
                text: "Mantenemos una duración media de 4.5 años, sobreponderando crédito corporativo de grado de inversión (IG) frente a gobiernos, aprovechando los diferenciales actuales."
            }
        };

        await createPage("Renta Fija y Crédito", [ratingComponent, maturityComponent, bondsTableComponent, fixedIncomeAnalysisComponent], page4Template);

        // --- PÁGINA 5: RENDIMIENTO (Atomic Components) ---
        const page5Template = `
            <div class="sheet">
                <style>
                    .performance-grid {
                        display: grid;
                        grid-template-columns: 1.2fr 0.8fr; /* Give more space to the chart column if needed, or keeping 1fr 1fr */
                        grid-template-rows: 1fr 1fr;
                        gap: 20px;
                        height: 100%;
                        margin-top: 20px;
                    }
                    /* Top Left: Chart */
                    .performance-grid > div:nth-child(1) { grid-column: 1; grid-row: 1; }
                    /* Top Right: Risk Metrics */
                    .performance-grid > div:nth-child(2) { grid-column: 2; grid-row: 1; }
                    /* Bottom Left: Annualized Returns */
                    .performance-grid > div:nth-child(3) { grid-column: 1; grid-row: 2; }
                     /* Bottom Right: Conclusion */
                    .performance-grid > div:nth-child(4) { grid-column: 2; grid-row: 2; align-self: end; }
                </style>
                <div class="header">
                    <div>PRIVATE BANKING</div>
                    <div style="font-size: 12px;">{{clientName}} | {{accountNumber}}</div>
                </div>
                <div class="content">
                    <h2>Análisis de Rendimiento</h2>
                    <div class="performance-grid">
                        {{{components}}}
                    </div>
                </div>
                <div class="footer">
                    Página ${pageIndex + 1} | Confidencial
                </div>
            </div>
        `;

        const performanceChartComponent = {
            componentType: "chart-performance",
            template: `
                <div style="height: 100%; display: flex; flex-direction: column;">
                    <h4 style="margin: 0 0 10px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Rendimiento vs. Benchmark (12 Meses)</h4>
                    <div style="flex-grow: 1; position: relative; min-height: 200px;">
                        <canvas id="chartPerformance"></canvas>
                    </div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', () => {
                     if (typeof Chart === 'undefined') return;
                     const el = document.getElementById('chartPerformance');
                     if(el) new Chart(el, {
                        type: 'line',
                        data: {{{json chartData}}},
                        options: { 
                            maintainAspectRatio: false,
                            responsive: true,
                            plugins: { 
                                datalabels: { display: false },
                                legend: { display: true, position: 'bottom', labels: { boxWidth: 10, font: { size: 10 } } }
                            },
                            scales: { y: { beginAtZero: true, ticks: { callback: function(value) { return value + '%'; } } } }
                        }
                     });
                });
                </script>
            `,
            data: {
                chartData: {
                    labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
                    datasets: [
                        {
                            label: 'Cartera',
                            data: [0, 0.5, 1.2, 2.0, 1.8, 2.5, 3.1, 4.0, 3.8, 4.5, 5.2, 8.4],
                            borderColor: '#1a2a40',
                            tension: 0.3,
                            fill: false
                        },
                        {
                            label: 'Benchmark',
                            data: [0, 0.3, 0.8, 1.5, 1.3, 2.0, 2.5, 3.2, 3.0, 3.7, 4.3, 7.1],
                            borderColor: '#e67e22',
                            borderDash: [5, 5],
                            tension: 0.3,
                            fill: false
                        }
                    ]
                }
            }
        };

        const riskMetricsComponent = {
            componentType: "table-risk-metrics",
            template: `
                <div>
                     <h4 style="margin: 0 0 10px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Métricas de Riesgo</h4>
                     <table style="width: 100%; font-size: 10px; border-collapse: collapse;">
                        <thead style="background: #f4f6f8;">
                            <tr>
                                <th style="padding: 6px; text-align: left;">Métrica</th>
                                <th style="padding: 6px; text-align: right;">Cartera</th>
                                <th style="padding: 6px; text-align: right;">Benchmark</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each rows}}
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 6px;">{{metric}}</td>
                                <td style="padding: 6px; text-align: right;">{{portfolio}}</td>
                                <td style="padding: 6px; text-align: right;">{{benchmark}}</td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>
            `,
            data: {
                rows: [
                    { metric: "Volatilidad Anualizada", portfolio: "12.5%", benchmark: "13.8%" },
                    { metric: "Ratio de Sharpe", portfolio: "0.85", benchmark: "0.70%" },
                    { metric: "Máximo Drawdown", portfolio: "-15.2%", benchmark: "-18.1%" },
                    { metric: "Beta", portfolio: "0.92", benchmark: "1.00" }
                ]
            }
        };

        const annualizedReturnsComponent = {
            componentType: "table-annualized-returns",
            template: `
                <div>
                    <h4 style="margin: 0 0 10px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Rentabilidad Anualizada</h4>
                    <table style="width: 100%; font-size: 10px; border-collapse: collapse;">
                        <thead style="background: #f4f6f8;">
                            <tr>
                                <th style="padding: 6px; text-align: left;">Periodo</th>
                                <th style="padding: 6px; text-align: right;">Cartera (%)</th>
                                <th style="padding: 6px; text-align: right;">Benchmark (%)</th>
                                <th style="padding: 6px; text-align: right;">Alpha (%)</th>
                            </tr>
                        </thead>
                        <tbody>
                            {{#each rows}}
                            <tr style="border-bottom: 1px solid #eee;">
                                <td style="padding: 6px;">{{period}}</td>
                                <td style="padding: 6px; text-align: right; font-weight: bold; color: green;">{{portfolio}}</td>
                                <td style="padding: 6px; text-align: right;">{{benchmark}}</td>
                                <td style="padding: 6px; text-align: right; color: green;">{{alpha}}</td>
                            </tr>
                            {{/each}}
                        </tbody>
                    </table>
                </div>
            `,
            data: {
                rows: [
                    { period: "1 Año", portfolio: "+8.4%", benchmark: "+7.1%", alpha: "+1.3%" },
                    { period: "3 Años", portfolio: "+6.2%", benchmark: "+5.5%", alpha: "+0.7%" },
                    { period: "5 Años", portfolio: "+7.8%", benchmark: "+7.0%", alpha: "+0.8%" }
                ]
            }
        };

        const analysisConclusionComponent = {
            componentType: "analysis-conclusion",
            template: `
                 <div style="padding: 15px; background: #e0f7fa; border-left: 3px solid #00bcd4; font-size: 11px; border-radius: 4px;">
                    <strong>Conclusión del Gestor:</strong> {{text}}
                </div>
            `,
            data: {
                text: "La cartera ha superado consistentemente a su benchmark con una menor volatilidad, demostrando una gestión eficiente del riesgo y una generación de alpha positiva. Recomendamos mantener la estrategia actual."
            }
        };

        await createPage("Análisis de Rendimiento", [performanceChartComponent, riskMetricsComponent, annualizedReturnsComponent, analysisConclusionComponent], page5Template);

        // --- PÁGINA 6: PRINCIPALES POSICIONES (Multi-Page Logic) ---
        console.log('\n⏳ Generando Tabla Desglosada (Multi-Página)...');

        const generateHoldings = (count: number) => {
            const assets = [
                { name: "Apple Inc.", ticker: "AAPL", type: "Equity", price: 185.50 },
                { name: "Microsoft Corp.", ticker: "MSFT", type: "Equity", price: 420.10 },
                { name: "Alphabet Inc.", ticker: "GOOGL", type: "Equity", price: 175.20 },
                { name: "Amazon.com", ticker: "AMZN", type: "Equity", price: 180.00 },
                { name: "NVIDIA Corp.", ticker: "NVDA", type: "Equity", price: 950.00 },
                { name: "Tesla Inc.", ticker: "TSLA", type: "Equity", price: 170.50 },
                { name: "Meta Platforms", ticker: "META", type: "Equity", price: 480.20 },
                { name: "Berkshire Hathaway", ticker: "BRK.B", type: "Equity", price: 410.30 },
                { name: "JPM Chase", ticker: "JPM", type: "Equity", price: 195.40 },
                { name: "Visa Inc.", ticker: "V", type: "Equity", price: 275.60 }
            ];

            const holdings = [];
            for (let i = 0; i < count; i++) {
                const asset = assets[i % assets.length];
                const quantity = Math.floor(Math.random() * 5000) + 100;
                const value = quantity * asset.price;
                const weight = (Math.random() * 2.5).toFixed(2);

                holdings.push({
                    name: asset.name,
                    ticker: asset.ticker,
                    isin: `US${Math.random().toString(36).substring(2, 11).toUpperCase()}`,
                    quantity: new Intl.NumberFormat('en-US').format(quantity),
                    price: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(asset.price),
                    value: new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value),
                    weight: `${weight}%`
                });
            }
            return holdings;
        };

        const allHoldings = generateHoldings(75); // Data for ~3 pages
        const HOLDINGS_PER_PAGE = 25;
        const totalHoldingPages = Math.ceil(allHoldings.length / HOLDINGS_PER_PAGE);

        for (let i = 0; i < totalHoldingPages; i++) {
            const chunk = allHoldings.slice(i * HOLDINGS_PER_PAGE, (i + 1) * HOLDINGS_PER_PAGE);
            await createPage(`Desglose de Posiciones (${i + 1}/${totalHoldingPages})`, [
                {
                    componentType: "detailed-table",
                    template: `
                         <div style="height: 100%; display: flex; flex-direction: column;">
                            <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555; border-bottom: 2px solid #1a2a40; padding-bottom: 5px;">Detalle de Activos en Cartera</h4>
                            <table style="width: 100%; font-size: 10px; border-collapse: collapse;">
                                <thead style="background: #1a2a40; color: white;">
                                    <tr>
                                        <th style="padding: 10px; text-align: left; background: #1a2a40; color: white;">Activo</th>
                                        <th style="padding: 10px; text-align: center; background: #1a2a40; color: white;">Ticker</th>
                                        <th style="padding: 10px; text-align: center; background: #1a2a40; color: white;">ISIN</th>
                                        <th style="padding: 10px; text-align: right; background: #1a2a40; color: white;">Títulos</th>
                                        <th style="padding: 10px; text-align: right; background: #1a2a40; color: white;">Precio</th>
                                        <th style="padding: 10px; text-align: right; background: #1a2a40; color: white;">Valor Total</th>
                                        <th style="padding: 10px; text-align: right; background: #1a2a40; color: white;">% Peso</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{#each rows}}
                                    <tr style="border-bottom: 1px solid #eee;">
                                        <td style="padding: 8px; font-weight: bold;">{{name}}</td>
                                        <td style="padding: 8px; text-align: center;">{{ticker}}</td>
                                        <td style="padding: 8px; text-align: center; color: #777;">{{isin}}</td>
                                        <td style="padding: 8px; text-align: right;">{{quantity}}</td>
                                        <td style="padding: 8px; text-align: right;">{{price}}</td>
                                        <td style="padding: 8px; text-align: right;">{{value}}</td>
                                        <td style="padding: 8px; text-align: right; font-weight: bold;">{{weight}}</td>
                                    </tr>
                                    {{/each}}
                                </tbody>
                            </table>
                            <div style="margin-top: auto; padding-top: 10px; font-size: 9px; color: #999; text-align: right;">
                                * Precios de cierre al 31/12/2025. Custodio: Global Bank NA.
                            </div>
                         </div>
                    `,
                    data: { rows: chunk }
                }
            ]);
        }


        // --- PÁGINA 7: TABLA COMPLEJA (Geográfica/Sectorial) ---
        const geoTableComponent = {
            componentType: "complex-table",
            template: `
                 <div style="height: 100%; display: flex; flex-direction: column;">
                     <h4 style="margin: 0 0 15px 0; font-size: 12px; color: #555;">Desglose por Región y País (Performance & Riesgo)</h4>
                     
                     <table style="width: 100%; font-size: 10px; border-collapse: collapse; border: 1px solid #ccc;">
                         <thead>
                             <!-- Header Nivel 1: Agrupaciones -->
                             <tr style="background: #1a2a40; color: white;">
                                 <th colspan="2" style="padding: 10px; border-right: 1px solid #555; text-align: center;">Ubicación</th>
                                 <th style="padding: 10px; border-right: 1px solid #555; text-align: center;">Activos</th>
                                 <th colspan="3" style="padding: 10px; border-right: 1px solid #555; text-align: center;">Rentabilidad (TWR)</th>
                                 <th colspan="2" style="padding: 10px; text-align: center;">Métricas Riesgo</th>
                             </tr>
                             <!-- Header Nivel 2: Columnas Específicas -->
                             <tr style="background: #eef2f7; color: #333;">
                                 <th style="padding: 8px; text-align: left; border-bottom: 2px solid #aaa;">Región</th>
                                 <th style="padding: 8px; text-align: left; border-bottom: 2px solid #aaa;">País</th>
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa; border-right: 1px solid #ddd;">Valor Actual ($)</th>
                                 
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa;">YTD</th>
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa;">1 Año</th>
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa; border-right: 1px solid #ddd;">3 Años</th>
                                 
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa;">Volatilidad</th>
                                 <th style="padding: 8px; text-align: right; border-bottom: 2px solid #aaa;">Sharpe</th>
                             </tr>
                         </thead>
                         <tbody>
                             {{#each regions}}
                                 <!-- Fila de Agrupación (Región) -->
                                 <tr style="background: #e8eaec; font-weight: bold;">
                                     <td colspan="8" style="padding: 8px; border-top: 2px solid #aaa; color: #1a2a40;">
                                         {{name}} <span style="font-weight: normal; font-size: 9px; margin-left: 10px;">({{countries.length}} Países)</span>
                                     </td>
                                 </tr>
                                 
                                 <!-- Filas de Detalle (Países) -->
                                 {{#each countries}}
                                 <tr style="border-bottom: 1px solid #eee;">
                                     <td style="padding: 6px 6px 6px 20px; border-right: 1px dashed #ddd;"></td> <!-- Indentación -->
                                     <td style="padding: 6px;">{{name}}</td>
                                     <td style="padding: 6px; text-align: right; border-right: 1px solid #f0f0f0;">{{value}}</td>
                                     
                                     <td style="padding: 6px; text-align: right; {{#if isPositiveYTD}}color: green;{{else}}color: red;{{/if}}">{{ytd}}</td>
                                     <td style="padding: 6px; text-align: right; {{#if isPositive1Y}}color: green;{{else}}color: red;{{/if}}">{{oneYear}}</td>
                                     <td style="padding: 6px; text-align: right; border-right: 1px solid #f0f0f0;">{{threeYear}}</td>
                                     
                                     <td style="padding: 6px; text-align: right;">{{volatility}}</td>
                                     <td style="padding: 6px; text-align: right;">{{sharpe}}</td>
                                 </tr>
                                 {{/each}}
                                 
                                 <!-- Fila de Subtotal Región -->
                                 <tr style="background: #fafbfc; border-top: 1px solid #ddd;">
                                     <td colspan="2" style="padding: 6px 6px 6px 20px; text-align: right; font-weight: bold; font-style: italic;">Total {{name}}</td>
                                     <td style="padding: 6px; text-align: right; font-weight: bold;">{{totalValue}}</td>
                                     <td colspan="5"></td>
                                 </tr>
                             {{/each}}
                         </tbody>
                          <!-- Footer de Tabla (Total Global) -->
                         <tfoot style="background: #1a2a40; color: white; font-weight: bold;">
                             <tr>
                                 <td colspan="2" style="padding: 10px; text-align: right;">TOTAL CARTERA</td>
                                 <td style="padding: 10px; text-align: right;">12,450,000</td>
                                 <td colspan="5"></td>
                             </tr>
                         </tfoot>
                     </table>
                     
                     <div style="margin-top: 20px; font-size: 11px; color: #666;">
                         * La volatilidad se calcula utilizando datos semanales anualizados de los últimos 3 años.
                     </div>
                 </div>
             `,
            data: {
                regions: [
                    {
                        name: "Norteamérica",
                        totalValue: "$8,500,000",
                        countries: [
                            { name: "Estados Unidos", value: "$7,800,000", ytd: "+9.2%", isPositiveYTD: true, oneYear: "+14.5%", isPositive1Y: true, threeYear: "+11.2%", volatility: "14.2%", sharpe: "0.95" },
                            { name: "Canadá", value: "$700,000", ytd: "+4.1%", isPositiveYTD: true, oneYear: "+6.8%", isPositive1Y: true, threeYear: "+5.4%", volatility: "12.1%", sharpe: "0.65" }
                        ]
                    },
                    {
                        name: "Europa",
                        totalValue: "$2,850,000",
                        countries: [
                            { name: "Alemania", value: "$1,200,000", ytd: "+2.5%", isPositiveYTD: true, oneYear: "+4.2%", isPositive1Y: true, threeYear: "+3.1%", volatility: "15.5%", sharpe: "0.45" },
                            { name: "Francia", value: "$950,000", ytd: "+1.8%", isPositiveYTD: true, oneYear: "+5.1%", isPositive1Y: true, threeYear: "+4.8%", volatility: "16.1%", sharpe: "0.50" },
                            { name: "Suiza", value: "$700,000", ytd: "+5.5%", isPositiveYTD: true, oneYear: "+8.2%", isPositive1Y: true, threeYear: "+7.5%", volatility: "10.2%", sharpe: "1.10" }
                        ]
                    },
                    {
                        name: "Asia-Pacífico",
                        totalValue: "$1,100,000",
                        countries: [
                            { name: "Japón", value: "$600,000", ytd: "-1.2%", isPositiveYTD: false, oneYear: "+10.5%", isPositive1Y: true, threeYear: "+2.1%", volatility: "13.5%", sharpe: "0.25" },
                            { name: "China", value: "$500,000", ytd: "-4.5%", isPositiveYTD: false, oneYear: "-8.2%", isPositive1Y: false, threeYear: "-10.5%", volatility: "22.5%", sharpe: "-0.10" }
                        ]
                    }
                ]
            }
        };

        await createPage("Análisis Geográfico Detallado", [geoTableComponent]);


        // --- PÁGINAS 8-10: TRANSACCIONES (Compacto) ---
        console.log('\n⏳ Generando 5 Páginas de Transacciones Recientes...');
        const allTransactions = generateTransactions(100); // Solo 100 movimientos recientes
        const ITEMS_PER_PAGE = 18;
        const totalPages = Math.ceil(allTransactions.length / ITEMS_PER_PAGE);

        for (let i = 0; i < totalPages; i++) {
            const chunk = allTransactions.slice(i * ITEMS_PER_PAGE, (i + 1) * ITEMS_PER_PAGE);
            await createPage(`Movimientos del Trimestre (${i + 1}/${totalPages})`, [
                {
                    componentType: "table-transactions",
                    template: `
                        <table class="transactions">
                            <thead>
                                <tr>
                                    <th style="width: 15%">Fecha</th>
                                    <th style="width: 15%">Tipo</th>
                                    <th style="width: 40%">Descripción</th>
                                    <th style="width: 15%; text-align: right;">Importe</th>
                                    <th style="width: 15%; text-align: right;">Saldo</th>
                                </tr>
                            </thead>
                            <tbody>
                                {{#each rows}}
                                <tr>
                                    <td>{{date}}</td>
                                    <td><span style="background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 10px;">{{type}}</span></td>
                                    <td>{{description}}</td>
                                    <td style="text-align: right; font-family: monospace; {{#if isNegative}}color: #c0392b;{{else}}color: #27ae60;{{/if}}">{{amount}}</td>
                                    <td style="text-align: right; font-family: monospace; color: #555;">{{balance}}</td>
                                </tr>
                                {{/each}}
                            </tbody>
                        </table>
                    `,
                    data: { rows: chunk }
                }
            ]);
        }

        // --- PÁGINA FINAL: DISCLAIMER ---
        await createPage("Información Legal", [
            {
                componentType: "text",
                template: `
                    <div style="font-size: 10px; color: #999; text-align: justify; columns: 2;">
                        <p>Este informe ha sido generado automáticamente por sistemas de inteligencia artificial. La información contenida tiene carácter meramente informativo y no constituye una oferta de compra o venta de valores.</p>
                        <p>Rentabilidades pasadas no garantizan rentabilidades futuras. El valor de las inversiones puede subir o bajar y el inversor podría no recuperar el capital invertido.</p>
                        <p>Spatial Eclipse AI no se hace responsable de errores u omisiones en los datos de proveedores externos. Todas las fechas y valores deben ser conciliados con los extractos oficiales del custodio.</p>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                        <p>© 2026 Spatial Eclipse Banking Services. Todos los derechos reservados.</p>
                    </div>
                `,
                data: {}
            }
        ]);


        // 5. Resultado
        console.log('\n🎉 ¡Proceso Finalizado!');
        console.log('-------------------------------------------------------');
        console.log(`📄 Ver HTML: ${API_URL}/documents/${docId}/render`);
        console.log(`📥 Descargar PDF: ${API_URL}/documents/${docId}/pdf`);
        console.log('-------------------------------------------------------');

    } catch (error) {
        console.error('❌ Error:', error);
    }
};

run();
