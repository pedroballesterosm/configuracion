import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';

const pool = new Pool({
    connectionString: 'postgresql://admin:password@localhost:5432/document_engine'
});

const OUTPUT_FILE = path.join(__dirname, '../migrations/seed_data.sql');

const escapeVal = (val: any): string => {
    if (val === null || val === undefined) return 'NULL';
    if (typeof val === 'number') return val.toString();
    if (typeof val === 'boolean') return val ? 'TRUE' : 'FALSE';
    if (typeof val === 'object') return `'${JSON.stringify(val).replace(/'/g, "''")}'`; // JSON
    return `'${val.toString().replace(/'/g, "''")}'`; // String
};

const dumpTable = async (tableName: string, columns: string[], orderBy: string = 'id') => {
    const res = await pool.query(`SELECT ${columns.join(', ')} FROM ${tableName} ORDER BY ${orderBy} ASC`);

    if (res.rows.length === 0) return '';

    const inserts = res.rows.map(row => {
        const values = columns.map(col => escapeVal(row[col]));
        return `INSERT INTO ${tableName} (${columns.join(', ')}) VALUES (${values.join(', ')});`;
    });

    return `\n-- Data for ${tableName} --\n` + inserts.join('\n');
};

const run = async () => {
    try {
        console.log('📦 Iniciando Backup SQL...');

        let sql = '-- Auto-generated Seed Data\n';
        sql += 'BEGIN;\n';

        // 1. Documents (HAS created_at)
        sql += await dumpTable('documents', ['id', 'title', 'status', 'template', 'data', 'data_path', 'global_context', 'metadata', 'created_at', 'updated_at'], 'created_at');

        // 2. Sections (NO created_at)
        sql += await dumpTable('sections', ['id', 'document_id', 'order_index', 'template', 'data', 'data_path'], 'order_index');

        // 3. Pages (NO created_at)
        sql += await dumpTable('pages', ['id', 'section_id', 'order_index', 'width', 'height', 'template', 'data', 'data_path'], 'order_index');

        // 4. Components (NO created_at)
        sql += await dumpTable('components', ['id', 'page_id', 'x', 'y', 'width', 'height', 'z_index', 'component_type', 'template', 'data', 'data_path'], 'id');

        sql += '\nCOMMIT;\n';

        fs.writeFileSync(OUTPUT_FILE, sql);
        console.log(`✅ Backup guardado en: ${OUTPUT_FILE}`);

    } catch (err) {
        console.error('❌ Error:', err);
    } finally {
        await pool.end();
    }
};

run();
