# Spatial Eclipse - Document Engine

Motor de generación de documentos dinámicos (PDF/HTML) basado en Node.js, Fastify y PostgreSQL.

## 🚀 Inicio Rápido

### Requisitos
- Node.js (v18+)
- PostgreSQL
- Docker (Opcional, para levantar DB)

### Instalación
```bash
npm install
```

### Base de Datos
Levantar PostgreSQL con Docker:
```bash
docker-compose up -d
```
Las credenciales por defecto son `admin:password`.

### Ejecutar Servidor
```bash
# Modo desarrollo (con autoreload)
npm run dev

# Compilar y correr
npm run build
npm start
```
El servidor escuchará en `http://localhost:3000`.

---

## 🛠️ Scripts y Herramientas

El proyecto incluye scripts en TypeScript para poblar la base de datos y generar reportes de ejemplo. Ejecútalos con `npx ts-node`.

### 1. Generar Informe Bancario Completo (Demo Principal)
Crea un documento masivo de Wealth Management (+60 páginas) con gráficos, tablas complejas y layout apaisado.
```bash
npx ts-node scripts/create_banking_report.ts
```
**Salida**: Un enlace para ver HTML y descargar PDF.

### 2. Generar Ejemplo Básico
Crea un documento simple de "Informe Trimestral" para probar el motor.
```bash
npx ts-node scripts/create_full_example.ts
```

### 3. Backup de Datos (Exportar SQL)
Exporta todos los documentos y componentes actuales a un archivo SQL portable (`migrations/seed_data.sql`). Útil para mover datos a otra máquina.
```bash
npx ts-node scripts/backup_db.ts
```

---

## 📡 API Reference

### Documentos

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `GET` | `/api/documents` | Lista todos los documentos. |
| `POST` | `/api/documents` | Crea un documento nuevo. <br> **Body**: `{ title, template, data, globalContext, metadata }` |
| `GET` | `/api/documents/:id` | Obtiene metadata y estructura completa de un documento. |
| `GET` | `/api/documents/:id/render` | Renderiza el documento a HTML (Previsualización). |
| `GET` | `/api/documents/:id/pdf` | Genera y descarga el PDF del documento. |

### Estructura (Secciones/Páginas/Componentes)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `POST` | `/api/documents/:id/sections` | Añade una sección al documento. |
| `POST` | `/api/sections/:id/pages` | Añade una página a una sección. |
| `POST` | `/api/pages/:id/components` | Añade un componente a una página. |

### Biblioteca (Library)

| Método | Endpoint | Descripción |
|--------|----------|-------------|
| `POST` | `/api/library/components` | Guarda un componente en la biblioteca para reuso. |
| `POST` | `/api/library/instantiate/document/:libId` | Crea un documento nuevo basado en una plantilla de biblioteca. |
| `POST` | `/api/library/instantiate/component/:libId` | Instancia un componente de biblioteca en una página existente. <br> **Body**: `{ pageId }` |

### Health Check
- `GET /api/health`: Retorna `{ status: 'ok' }`.
